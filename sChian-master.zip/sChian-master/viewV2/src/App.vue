<script setup lang="ts">
import { storeToRefs } from 'pinia'
import useAppStore from '@/stores/modules/app'
import useRouteTransitionNameStore from '@/stores/modules/routeTransitionName'
import { sysConfigGet } from '@/api/sys_config'
import useUserStore from '@/stores/modules/user'
import { getHttpCard } from '@/utils/card'
import { MyArea } from '@/utils/area'
import useRefreshStore from '@/stores/modules/refresh'
import { windowOpen } from '@/utils/window'

useHead({
  title: '查链名片-短链仓库',
  meta: [
    {
      name: 'description',
      content: '查链名片-短链仓库',
    },
    {
      name: 'theme-color',
      content: () => isDark.value ? '#00aba9' : '#ffffff',
    },
  ],
})

const routeObj = useRoute()
const router = useRouter()
const userStore = useUserStore()
const appStore = useAppStore()
const { mode } = storeToRefs(appStore)

const refreshStore = useRefreshStore()

const routeTransitionNameStore = useRouteTransitionNameStore()
const { routeTransitionName } = storeToRefs(routeTransitionNameStore)

const headerActive = ref<string>('suggest')
const searchValue = ref<string>('')
const showArea = ref<boolean>(false)
const searchSelect = ref<string>('id')

const navBar = ref<any>(null)
const tarBar = ref<any>(null)
const tabs = ref<any>(null)
const content = ref<any>(null)

const tabOffset = ref<number>(0)
const tabWidth = ref<number>(0)

const cntTopOffset = ref<number>(0)
const cntBottomOffset = ref<number>(0)

onMounted(() => {
  tabOffset.value = navBar.value.$el.clientHeight
  tabWidth.value = navBar.value.$el.clientWidth
  cntBottomOffset.value = tarBar.value.$el.clientHeight
  cntTopOffset.value = tabs.value.$el.clientHeight + tabOffset.value
})

// useEventListener('resize', () => {
//   cntHeight.value = window.innerHeight - tarBar.value.$el.clientHeight
// })
//
// useResizeObserver(content, () => {
//   cntHeightUse.value = true
//   setTimeout(() => {
//     console.log(content.value.scrollHeight)
//     cntHeightUse.value = content.value.scrollHeight <= window.innerHeight
//   }, 200)
// })

watch(() => router.currentRoute.value, (newValue) => {
  switch (newValue.path) {
    case '/':
      headerActive.value = 'suggest'
      return
    case '/keyword':
      headerActive.value = 'keyword'
      return
    case '/address':
      headerActive.value = 'address'
      return
    case '/star':
      headerActive.value = 'star'
      return
    case '/rank':
      headerActive.value = 'rank'
  }
})

const isShowHeaderOrFooter = computed(() => {
  return routeObj.path !== '/chat'
})

async function clickDbLink(obj: any) {
  let topLink = ''
  let downLink = ''
  let libraryLink = ''
  switch (obj.name) {
    case 'topDbLink':
      topLink = (await sysConfigGet({ key: 'TopDbLink' })).data.value
      if (topLink !== '')
        windowOpen(topLink)
      break
    case 'downDbLink':
      downLink = (await sysConfigGet({ key: 'DownDbLink' })).data.value
      if (downLink !== '')
        windowOpen(downLink)
      break
    case 'library':
      libraryLink = (await sysConfigGet({ key: 'LibraryLink' })).data.value
      if (libraryLink !== '')
        windowOpen(libraryLink)
      break
    case 'address':
      showArea.value = true
  }
}

function clickTitle() {
  if (userStore.isLogin())
    location.href = getHttpCard(userStore.username)
  else
    location.href = 'https://www.115.cn'
}

async function clickAddress({ selectedOptions }) {
  const text = selectedOptions[0].text
  showArea.value = false
  await router.push({ path: '/', query: { addr: [text.replace('省', '').replace('市', '')] } })
}

async function clickSearch() {
  const query = {}
  if (searchValue.value !== '')
    query[searchSelect.value] = searchValue.value
  await router.push({ path: '/', query })
}

// function clickHead() {
//   if (!userStore.isLogin())
//     return
//
//   router.push('/my')
// }

function clickRefresh() {
  refreshStore.addPage()
  window.console.log('change page')
}
</script>

<template>
  <VanConfigProvider :theme="mode">
    <VanNavBar v-show="isShowHeaderOrFooter" id="navBar" ref="navBar" fixed>
      <template #title>
        <VanSearch v-model="searchValue" @clear="clickSearch">
          <template #left-icon>
            <select v-model="searchSelect" class="searchSelect text-5xl text-gray-500">
              <option value="id">
                ID
              </option>
              <option value="title">
                名称
              </option>
              <option value="essay">
                短文
              </option>
              <option value="disk">
                公盘
              </option>
              <option value="mul">
                综合
              </option>
            </select>
          </template>
          <template #right-icon>
            <VanIcon class="cursor-pointer" name="search" @click="clickSearch" />
          </template>
        </VanSearch>
      </template>
      <template #left>
        <div class="logo text-7xl font-semibold" @click="clickTitle">
          <VanSpace>
            <span>查</span>
            <span style="margin-left: 45%">链</span>
          </VanSpace>
        </div>
      </template>
      <!--      <template #right> -->
      <!--        <div style="display: flex;"> -->
      <!--          <VanIcon style="cursor: pointer" :name="userStore.isLogin() ? 'user-circle-o' : 'edit'" class="text-8xl" @click="clickHead" /> -->
      <!--        </div> -->
      <!--      </template> -->
    </VanNavBar>

    <VanTabs
      v-show="isShowHeaderOrFooter"
      id="tabs"
      ref="tabs"
      v-model:active="headerActive"
      style="z-index: 1;position: fixed"
      :style="{ 'margin-top': `${tabOffset - 1}px`, 'width': `${tabWidth}px` }"
      @click-tab="clickDbLink"
    >
      <VanTab title="推荐" to="/" name="suggest" />
      <VanTab title="排行" to="/rank" name="rank" />
      <VanTab title="文库" name="library" />
      <VanTab title="链库" name="topDbLink" />
      <VanTab title="搜词" to="/keyword" name="keyword" />
      <VanTab title="地址" name="address" />
    </VanTabs>

    <VanPopup v-model:show="showArea" position="bottom">
      <VanArea title="选择地址" :area-list="MyArea" columns-num="1" @confirm="clickAddress" @cancel="showArea = false" />
    </VanPopup>

    <router-view v-slot="{ Component, route }">
      <transition :name="routeTransitionName">
        <div ref="content" :key="route.name" class="app-wrapper">
          <div
            v-if="isShowHeaderOrFooter"
            :style="{ 'padding-top': `${cntTopOffset}px`, 'padding-bottom': `${cntBottomOffset + 10}px` }"
          >
            <component :is="Component" />
          </div>
          <div v-else>
            <component :is="Component" />
          </div>
        </div>
      </transition>
    </router-view>

    <VanTabbar v-show="isShowHeaderOrFooter" ref="tarBar" route style="max-width: 600px;">
      <VanTabbarItem name="info" icon="chat-o" to="/chat-list">
        信息
      </VanTabbarItem>
      <VanTabbarItem name="star" icon="star-o" to="/star">
        收藏
      </VanTabbarItem>
      <VanTabbarItem name="refresh" to="/suggest" icon="replay" @click="clickRefresh">
        刷新
      </VanTabbarItem>
      <VanTabbarItem icon="search" @click="clickDbLink({ name: 'downDbLink' })">
        链库
      </VanTabbarItem>
      <VanTabbarItem name="my" icon="contact-o" to="/my">
        我的
      </VanTabbarItem>
    </VanTabbar>
  </VanConfigProvider>
</template>

<style scoped>
.app-wrapper {
  position: relative;
  top: 0;
  left: 0;
  width: 100%;
}

.logo {
  color: rgb(72, 187, 238);
  cursor: pointer;
  display: flex;
}

.searchSelect {
  border: none;
  outline: none;
  background-color: rgba(0, 0, 0, 0);
  list-style-type: disc;
}
</style>
