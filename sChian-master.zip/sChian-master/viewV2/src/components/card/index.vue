<script setup lang="ts">
import { showFailToast } from 'vant'
import { getCard, getHttpCard, getManageHttpCard, replaceCardContent } from '@/utils/card'
import { unixFormat } from '@/utils/date'
import { isMobile } from '@/utils/utils'
import type { CardBody } from '@/components/card/typing'
import useUserStore from '@/stores/modules/user'
import { starAdd, starCancel } from '@/api/card'
import { favAdd, favCancel } from '@/api/favorites'
import { groupAdd, groupCancel, privateAdd, privateFind } from '@/api/chat'
import { notesGet, notesSet } from '@/api/notes'
import { windowOpen } from '@/utils/window'

const props = defineProps<{
  body?: CardBody
  index: number
}>()

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const body = ref<CardBody>(props.body)

const lineSpaceSize = ref<number>(8)
const isCurrentCard = ref<boolean>(userStore.isCurrent(body.value.Uid))
const popActions = ref<Array<any>>([
  { text: '备注', index: 1 },
  { text: '投诉', index: 2 },
])
const popInit = ref<boolean>(false)
const showNotesDialog = ref<boolean>(false)
const addressRedIndex = ref<number>(-1)

onMounted(() => {
  calcAddressIndex()
})

const keywords = computed(() => {
  const items = body.value.Keywords.split('$$')
  const save = []
  for (let i = 0; i < 3; i++) {
    if (i === 0)
      save.push(items[i] || '空缺')
    else if (i === 1)
      save.push(items[i] || '空缺')
    else
      save.push(items[i] || '空缺')
  }
  return save
})

if (isMobile())
  lineSpaceSize.value = 0

const contact = computed(() => {
  return body.value.Contact.split('$')
})

const address = computed(() => {
  const items = body.value.Address.split('>')
  return [
    items[0],
    '>',
    items[1],
    '>',
    items[2],
    '>',
    items[3],
    '>',
    items[4],
  ]
})

const cardBodyClass = computed(() => {
  if (props.index === 0)
    return 'cardBodyRed'

  if (userStore.isCurrent(body.value.Uid))
    return 'cardBodyRed'

  return 'cardBody'
})

const starNumText = computed(() => {
  if (body.value.Star >= 10000)
    return `${(body.value.Star / 10000).toFixed(1)}w`
  else if (body.value.Star >= 1000)
    return `${(body.value.Star / 1000).toFixed(0)}k`

  return body.value.Star
})

function calcAddressIndex() {
  let addr = route.query.addr || []

  if (typeof addr === 'string')
    addr = [addr]

  if (addr.length === 0)
    return

  const addrStr = addr.join('>')
  const addressStr = address.value.join('')
  if (addressStr.startsWith(addrStr))
    addressRedIndex.value = addr.length * 2 - 1
}

async function changeStar() {
  if (body.value.ID === 0)
    return
  if (!userStore.isLogin()) {
    await router.push('/login')
    return
  }

  if (body.value.IsStar) {
    const data = (await starCancel({ id: body.value.Uid })).data
    body.value.Star -= data
    body.value.IsStar = false

    await favCancel({ link: getHttpCard(body.value.Uid), uid: body.value.Uid })
    body.value.IsFavorites = false
  }
  else {
    const data = (await starAdd({ id: body.value.Uid })).data
    body.value.Star += data
    body.value.IsStar = data === 1
    // 没有被收藏才添加
    if (!body.value.IsFavorites) {
      await favAdd({
        name: body.value.Title || getCard(body.value.Uid),
        link: getHttpCard(body.value.Uid),
        uid: body.value.Uid,
      })
      body.value.IsFavorites = true
    }
  }
}

// 私聊
async function chatPrivate() {
  if (!userStore.isLogin()) {
    await router.push('/login')
    return
  }
  if (userStore.isCurrent(body.value.Uid)) {
    showFailToast('无法创建与自己的私聊会话')
    return
  }
  if (!body.value.IsPrivate) {
    await privateAdd({ uid: body.value.Uid })
    body.value.IsPrivate = true
  }
  const sid = (await privateFind({ uid: body.value.Uid })).data
  await router.push({ path: '/chat', query: { sid } })
}

// 群聊
async function chatGroup() {
  if (body.value.IsGroup) {
    await groupCancel({ uid: body.value.Uid })
    body.value.IsGroup = false
    return
  }

  if (!userStore.isLogin()) {
    await router.push('/login')
    return
  }
  if (userStore.isCurrent(body.value.Uid)) {
    showFailToast('无法创建与自己的群聊会话')
    return
  }
  await groupAdd({ uid: body.value.Uid })
  body.value.IsGroup = true
}

async function popOpen() {
  if (!userStore.isLogin() || popInit.value)
    return

  const resp = (await notesGet({ right: body.value.Uid })).data
  popActions.value.push({
    text: resp.Ip ? `IP: ${resp.Ip}` : 'IP: 未知',
    index: 3,
  })
  popActions.value[0].text = resp.Notes || '备注'
  popInit.value = true
}

function popSelect(v: any) {
  if (v.index === 2)
    windowOpen(getManageHttpCard())

  else if (v.index === 1)
    showNotesDialog.value = true
}

async function setNotes(v: string) {
  if (!v)
    return

  if (!userStore.isLogin()) {
    await router.push('/login')
    return
  }

  await notesSet({ right: body.value.Uid, cnt: v })
  popActions.value[0].text = v
  body.value.Title = v
}

function clickSearchKey(key: string) {
  router.push({ path: '/', query: { key } })
}

function clickSearchAddress(index: number) {
  const addr = address.value.slice(0, index)
  const newArr = []
  for (const v of addr) {
    if (v === '>')
      continue
    newArr.push(v)
  }
  router.push({ path: '/', query: { addr: newArr } })
}

function matchKeyClass(key: string) {
  return route.query.key === key ? 'text-red' : ''
}

// 点击入口
function clickInto(id: string) {
  if (userStore.isCurrent(id))
    router.push('/my')
  else
    router.push({ path: '/login', query: { id } })
}
</script>

<template>
  <ConfirmDialog
    v-model:show="showNotesDialog"
    placeholder="请输入备注"
    title="设置备注"
    @confirm="setNotes"
  />

  <div class="card">
    <div :class="cardBodyClass">
      <VanSpace :size="lineSpaceSize" class="w-full" direction="vertical">
        <VanRow justify="space-around">
          <VanCol span="22">
            <VanSpace>
              <span
                :style="{ color: isCurrentCard ? 'red' : '' }"
                class="text-6xl font-normal"
              >
                {{ body.Notes || (body.Title || getCard(body.Uid)) }}
              </span>
              <VanPopover :actions="popActions" @open="popOpen" @select="popSelect">
                <template #reference>
                  <VanIcon size="18" class="cursor-pointer" name="arrow-down" />
                </template>
              </VanPopover>
            </VanSpace>
          </VanCol>
          <VanCol class="text-right" span="2">
            <span class="cursor-pointer text-5xl font-normal">
              <span :style="{ color: isCurrentCard ? 'red' : '#409eff' }" @click="clickInto(body.Uid)">
                {{ isCurrentCard ? '修改' : '入口' }}
              </span>
            </span>
          </VanCol>
        </VanRow>

        <VanRow justify="space-around">
          <VanCol span="14">
            <span class="text-5xl text-gray-500 font-light">
              链号: <Link type="user" :value="body.Uid" />
            </span>
          </VanCol>
          <VanCol span="10">
            <span class="text-5xl font-light">{{ contact[0] || 'Mail' }}: {{ contact[1] || '暂时保密' }}</span>
          </VanCol>
        </VanRow>

        <VanRow>
          <VanCol span="24">
            <span v-for="(item, i) in address" :key="i">
              <span
                v-if="item !== '>'"
                :class="i < addressRedIndex ? 'text-red' : ''"
                class="cursor-pointer text-5xl font-light hover:text-red"
                @click="clickSearchAddress(i + 1)"
              >
                {{ item || `地址${i / 2}` }}
              </span>
              <span v-else class="text-5xl font-light" :class="i < addressRedIndex ? 'text-red' : ''">
                {{ item }}
              </span>
            </span>
          </VanCol>
        </VanRow>

        <VanRow justify="space-around">
          <VanCol span="16">
            <VanSpace>
              <span class="text-5xl font-semibold">搜词:</span>
              <span
                v-for="(key, i) in keywords"
                :key="i"
                :class="matchKeyClass(key)"
                class="searchWord text-5xl text-gray-500 hover:text-red"
                @click="clickSearchKey(key)"
              >
                {{ key }}
              </span>
            </VanSpace>
          </VanCol>
          <VanCol class="text-right" span="8">
            <span class="text-5xl font-light">
              {{ unixFormat('YYYY.mm.dd', body.Updated) }}
            </span>
          </VanCol>
        </VanRow>

        <VanRow>
          <VanCol span="24">
            <span class="text-5xl text-gray-500 font-light leading-12">
              <span v-html="replaceCardContent(body.Essay)" />
            </span>
          </VanCol>
        </VanRow>

        <VanRow class="pb-5" justify="center">
          <VanCol span="3">
            <Link class="item text-5xl text-gray-400 font-light hover:text-blue" to="/disk" :query="{ id: body.Uid }" value="网盘" />
          </VanCol>
          <VanCol span="3">
            <Link class="item text-5xl text-gray-400 font-light hover:text-blue" to="/essay" :query="{ id: body.Uid }" value="短文" />
          </VanCol>
          <VanCol span="3">
            <Link class="item text-5xl text-gray-400 font-light hover:text-blue" to="/favorites" :query="{ id: body.Uid }" value="导航" />
          </VanCol>
          <VanCol span="3">
            <span class="item text-5xl text-gray-400 font-light" @click="changeStar">
              <VanIcon :style="{ color: body.IsStar ? 'red' : '' }" name="star-o" />
              {{ starNumText }}
            </span>
          </VanCol>
          <!--          <VanCol span="2"> -->
          <!--            <span class="item text-5xl text-gray-400 font-light" @click="changeFav"> -->
          <!--              <VanIcon :style="{ color: body.IsFavorites ? 'dodgerblue' : '' }" name="star-o" /> -->
          <!--            </span> -->
          <!--          </VanCol> -->
          <VanCol span="3">
            <span class="item text-5xl text-gray-400 font-light hover:text-blue" :class="body.IsGroup ? 'text-red' : ''" @click="chatGroup">{{ body.IsGroup ? '已群' : '群聊' }}</span>
          </VanCol>
          <VanCol span="3">
            <span class="item text-5xl text-gray-400 font-light hover:text-blue" @click="chatPrivate">私聊</span>
          </VanCol>
          <VanCol span="3">
            <Link class="item text-5xl text-gray-400 font-light hover:text-blue" to="/leave-message" :query="{ id: body.Uid }" value="留言" />
          </VanCol>
        </VanRow>
      </VanSpace>
    </div>
  </div>

  <div v-if="props.index === 0" class="blueBar" />
</template>

<style scoped>
.card{
  padding: 5px;
  background-color: #ffffff;
}

.cardBody{
  padding: 10px 10px 0;
  border: 2px solid #e4e6eb;
  border-radius: 5px;
}

.cardBodyRed{
  padding: 10px 10px 0;
  border: 2px solid red;
  border-radius: 5px;
}

.blueBar{
  border: 1px solid blue;
  width: 90%;
  margin: auto;
}

.searchWord{
  text-decoration: underline;
  cursor: pointer;
}

.item{
  cursor: pointer;
}
</style>
