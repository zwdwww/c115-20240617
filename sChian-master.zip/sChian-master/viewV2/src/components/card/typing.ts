export interface CardBody {
  Address: string
  Contact: string
  Created: number
  Essay: string
  ID: number
  IsFavorites: boolean
  IsGroup: boolean
  IsPrivate: boolean
  IsStar: boolean
  Keywords: string
  Star: number
  Title: string
  Uid: string
  Updated: number
  Weight: number
  Notes: string // 备注
}
