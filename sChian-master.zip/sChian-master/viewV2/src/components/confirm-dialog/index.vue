<script setup lang="ts">
const props = defineProps<{
  placeholder: string
  title: string
  show: boolean
}>()

const emits = defineEmits(['confirm', 'update:show'])

const text = ref<string>('')

function confirm() {
  emits('confirm', text.value)
  emits('update:show', false)
  text.value = ''
}
</script>

<template>
  <VanDialog :show="props.show" :title="props.title" show-cancel-button @confirm="confirm" @cancel="emits('update:show', false)">
    <VanField v-model="text" :placeholder="props.placeholder" />
  </VanDialog>
</template>

<style scoped>

</style>
