<script setup lang="ts">
const props = defineProps<{
  suffix: string
  uid: string
  value?: string
}>()

const emits = defineEmits(['backup'])

const router = useRouter()

function backup() {
  router.back()
}
</script>

<template>
  <div class="bg-white px-10 pt-8 text-4xl text-gray-500">
    <VanIcon class="cursor-pointer" name="arrow-left" @click="backup" />
    <span class="cursor-pointer" @click="backup">上一级</span>
    <VanIcon name="arrow-left" />
    <span v-if="value" class="cursor-pointer" @click="emits('backup')">
      <VanSpace size="3px">
        <Link class="underline" :value="props.uid" type="user" />
        <span style="color: #409eff;">{{ value }}</span>
      </VanSpace>
    </span>
    <span v-else>
      <VanSpace size="3px">
        <Link class="underline" :value="props.uid" type="user" />
        <span style="color: #409eff;">{{ props.suffix }}</span>
      </VanSpace>
    </span>

    <span style="float: right">
      <slot name="right" />
    </span>
  </div>
</template>

<style scoped>

</style>
