<template>
  <main class="h-full w-full p-16 py-60">
    <slot />
  </main>
</template>
