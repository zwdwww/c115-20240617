<script setup lang="ts">
import { getCard, getHttpCard } from '@/utils/card'
import { windowOpen } from '@/utils/window'

const props = defineProps<{
  to?: string
  url?: string
  value?: string
  type?: string
  query?: any
}>()

const router = useRouter()

function click() {
  if (props.to)
    router.push({ path: props.to, query: props.query || {} })
  else if (props.url)
    windowOpen(props.url)
  else if (props.type === 'user')
    windowOpen(getHttpCard(props.value))
}
</script>

<template>
  <span v-if="type === 'user'" class="link" @click="click">
    {{ getCard(props.value) }}
  </span>
  <span v-else @click="click">{{ props.value }}</span>
</template>

<style scoped>
.link{
  color: #409eff;
  cursor: pointer;
}
</style>
