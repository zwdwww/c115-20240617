export const STORAGE_TOKEN_KEY = 'access_token'
export const STORAGE_LANG_KEY = 'app_lang'
