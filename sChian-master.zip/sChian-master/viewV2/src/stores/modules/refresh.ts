import { defineStore } from 'pinia'
import type { RefreshValues } from '@/views/index/typing'

const useRefreshStore = defineStore('refresh', () => {
  const refresh = ref<RefreshValues>({
    page: 1,
    count: 0,
    loading: true,
    items: [],
  })

  const refreshEnd = ref<boolean>(true) // 向后翻页

  const addPage = () => {
    if (refresh.value.count === 0)
      return
    if (refreshEnd.value) {
      refresh.value.page++
      const end = Math.floor(refresh.value.count / 10)
      if (refresh.value.page >= end)
        refreshEnd.value = false
    }
    else {
      refresh.value.page--
      if (refresh.value.page === 1)
        refreshEnd.value = true
    }
  }

  return {
    refresh,
    addPage,
  }
})

export default useRefreshStore
