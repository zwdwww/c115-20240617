import { defineStore } from 'pinia'
import { getInfo, infoSetAllowLeaveMsg } from '@/api/auth'
import { removeToken, setToken } from '@/utils/auth'

const useUserStore = defineStore('user', () => {
  const username = ref<string>('')
  const phone = ref<string>('')
  const token = ref<string>('')
  const allowLeaveMsg = ref<number>(0)

  const initInfo = () => {
    return new Promise((resolve, reject) => {
      getInfo().then((resp) => {
        const data = resp.data
        username.value = data.username || ''
        phone.value = data.phone || ''
        allowLeaveMsg.value = data.allowLeaveMsg || 0
        resolve(resp)
      }).catch((error) => {
        reject(error)
      })
    })
  }

  const setAuthToken = (value: string) => {
    token.value = value
    setToken(value)
  }

  const loginSuccess = (data: any) => {
    username.value = data.username || ''
    token.value = data.token || ''
    phone.value = data.token || ''
    setAuthToken(token.value)
  }

  const reset = () => {
    username.value = ''
    phone.value = ''
    token.value = ''
    allowLeaveMsg.value = 0
    removeToken()
  }

  const setAllowLeaveMsg = (status: number) => {
    return new Promise((resolve, reject) => {
      infoSetAllowLeaveMsg({ status }).then(() => {
        allowLeaveMsg.value = status
        resolve(status)
      }).catch((err) => {
        reject(err)
      })
    })
  }

  const setPhone = (newPhone: string) => {
    phone.value = newPhone
  }

  const isLogin = () => {
    return username.value !== ''
  }

  const isCurrent = (v: string) => {
    if (!v)
      return false

    return v === username.value
  }

  return {
    username,
    phone,
    allowLeaveMsg,
    initInfo,
    loginSuccess,
    reset,
    isLogin,
    isCurrent,
    setAllowLeaveMsg,
    setPhone,
  }
})

export default useUserStore
