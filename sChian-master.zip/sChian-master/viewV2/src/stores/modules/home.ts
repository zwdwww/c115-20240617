import { defineStore } from 'pinia'
import type { HomeValues } from '@/views/index/typing'

// 这个框架用不了keepAlive, 用pinia代替要缓存的界面
const useHomeStore = defineStore('home', () => {
  const home = ref<HomeValues>({
    page: 1,
    count: 0,
    loading: true,
    cardItems: [],
    isFirst: true,
    scrollX: 0,
    scrollY: 0,
    isFirstInto: true,
  })

  const reset = () => {
    home.value.isFirst = true
    home.value.page = 1
    home.value.count = 0
    home.value.scrollX = 0
    home.value.scrollY = 0
    home.value.cardItems = []
  }

  return {
    home,
    reset,
  }
})

export default useHomeStore
