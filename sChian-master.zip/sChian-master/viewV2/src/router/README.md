# `File-based Routing`

Routes will be auto-generated for Vue files in the  **src/views** dir with the same file structure.
Check out [`unplugin-vue-router`](https://github.com/posva/unplugin-vue-router) for more details.

在 **src/views** 目录下的 Vue 文件会自动生成相同结构的路由。

查看[`unplugin-vue-router`](https://github.com/posva/unplugin-vue-router)了解更多细节。
