import { createRouter, createWebHistory } from 'vue-router/auto'
import NProgress from 'nprogress'

import useRouteTransitionNameStore from '@/stores/modules/routeTransitionName'
import 'nprogress/nprogress.css'
import { getToken } from '@/utils/auth'
import useUserStore from '@/stores/modules/user'

NProgress.configure({ showSpinner: true, parent: '#app' })

const router = createRouter({
  history: createWebHistory(import.meta.env.VITE_APP_PUBLIC_PATH),
})

const whiteList = [
  '/',
  '/suggest',
  '/login',
  '/register',
  '/leave-message',
  '/essay',
  '/favorites',
  '/rank',
  '/keyword',
  '/disk',
]

router.beforeEach(async (to, from, next) => {
  NProgress.start()

  const routeTransitionNameStore = useRouteTransitionNameStore()
  if (to.meta.level > from.meta.level)
    routeTransitionNameStore.setName('slide-fadein-left')

  else if (to.meta.level < from.meta.level)
    routeTransitionNameStore.setName('slide-fadein-right')

  else
    routeTransitionNameStore.setName('')

  const hasToken = getToken()
  if (hasToken) {
    const userStore = useUserStore()
    if (userStore.username === '')
      await userStore.initInfo()
    next()
  }
  else {
    if (whiteList.includes(to.path)) {
      console.log(from.path, to.path)
      next()
    }
    else { next('/login') }
  }
})

router.afterEach(() => {
  NProgress.done()
})

export default router
