export function isMobile(): boolean {
  return navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i) != null
}

export function indexArray(array: Array<any>, el: any, getEl: any = null): number {
  for (let i = 0; i < array.length; i++) {
    if (getEl !== null) {
      if (getEl(array[i]) === el)
        return i
      continue
    }
    if (array[i] === el)
      return i
  }
  return -1
}

export function sortOrderArray(array: Array<any>, order: Array<number>) {
  // 构建order
  const save = {}
  for (let i = 0; i < order.length; i++)
    save[order[i]] = i

  array.sort((a, b) => {
    return (save[a.ID] || 0) - (save[b.ID] || 0)
  })
  return array
}

export function getOrderArray(array: Array<any>): Array<number> {
  const order: Array<number> = []
  for (const e of array)
    order.push(e.ID)
  return order
}

export const PhoneRegex = /^1[3456789]\d{9}$/
