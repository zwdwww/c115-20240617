import Cookies from 'js-cookie'

const TokenKey = 'Token'

export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token: string) {
  const domain = import.meta.env.VITE_APP_CARD_DOMAIN || ''
  if (domain === '' || domain === 'localhost')
    return Cookies.set(TokenKey, token)

  return Cookies.set(TokenKey, token, { domain })
}

export function removeToken() {
  const domain = import.meta.env.VITE_APP_CARD_DOMAIN || ''
  if (domain === '' || domain === 'localhost')
    return Cookies.remove(TokenKey)

  return Cookies.remove(TokenKey, { domain })
}
