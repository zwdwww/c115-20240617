// 名片域名
export function getDomain() {
  return import.meta.env.VITE_APP_CARD_DOMAIN
}

// 名片前缀协议: http or https
export function getPrefix() {
  return import.meta.env.VITE_APP_CARD_PREFIX
}

// 拼接[名片ID+域名]
export function getCard(id) {
  return `${id.toString()}.${getDomain()}`
}

// 拼接[协议 + 名片ID + 域名]
export function getHttpCard(id) {
  return `${getPrefix()}${id}.${getDomain()}`
}

// 获取管理员名片ID
export function getManageID() {
  return import.meta.env.VITE_APP_CARD_MANAGE
}

// 获取管理员名片
export function getManageCard() {
  return getCard(getManageID())
}

// 获取带http的管理员名片
export function getManageHttpCard() {
  return getHttpCard(getManageID())
}

// 重域名中取出真实ID
export function getCardByHost(host: string) {
  if (!(host))
    return ''

  host = host.replace('www.', '')
  if (host === import.meta.env.VITE_APP_CARD_DOMAIN)
    return ''

  const item = host.split('.')
  if (item.length === 1)
    return ''
  else
    return item[0]
}

const domainPattern = /\b(?:https?:\/\/)?(?:www\.)?([a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-/?=#]+)+)\b/g

// 替换名片短文内容,将链接标识出来
export function replaceCardContent(content: string) {
  if (typeof content !== 'string')
    return content

  return content.replace(domainPattern, (match) => {
    let url = match
    if (!match.startsWith('http://') && !match.startsWith('https://'))
      url = `http://${match}`
    return `<a style="color: #20a2aa;text-decoration: underline;" href="${url}">${match}</a>`
  })
}
