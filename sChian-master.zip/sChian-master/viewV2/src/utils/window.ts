// 打开网址
export function windowOpen(url: string, mode: string = '') {
  window.console.log(mode)
  const system = navigator.userAgent
  const isAndroid = system.includes('Android') || system.includes('Adr') // android终端
  const isiOS = !!system.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) // ios终端

  // 使用
  if (isAndroid) {
    // android终端
    window.open(url)
  }
  else if (isiOS) {
    // ios终端
    window.location.href = url
  }
  else {
    // 未知 | PC端
    window.open(url)
  }
}
