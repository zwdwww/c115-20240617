import { AudioFile, FileExcel, FilePdf, FilePpt, FileText, FileWord, FileZip, FolderClose, Notes, Pic, VideoTwo } from '@icon-park/vue-next'

// 文件类型对应的组件
export const IconMap = {
  'dir': FolderClose,
  'txt': FileText,
  'docx': FileWord,
  'doc': FileWord,
  'xls': FileExcel,
  'xlsx': FileExcel,
  'xlsm': FileExcel,
  'ppt': FilePpt,
  'pptx': FilePpt,
  'csv': FileText,
  'tsv': FileText,
  'dotm': FileText,
  'xlt': FileText,
  'xltm': FileText,
  'dot': FileText,
  'dotx': FileText,
  'xlam': FileText,
  'xla': FileText,
  'pdf': FilePdf,
  'jpg': Pic,
  'jpeg': Pic,
  'png': Pic,
  'gif': Pic,
  'bmp': Pic,
  'ico': Pic,
  'jfif': Pic,
  'webp': Pic,
  'svg': Pic,
  'zip': FileZip,
  'rar': FileZip,
  'jar': FileZip,
  'tar': FileZip,
  'gzip': FileZip,
  '7z': FileZip,
  'mp3': AudioFile,
  'wav': AudioFile,
  'mp4': VideoTwo,
  'flv': VideoTwo,
}

export function GetFileIcon(fileType: string) {
  return IconMap[fileType] || Notes
}
