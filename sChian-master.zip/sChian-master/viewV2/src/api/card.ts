import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

// 推荐页
export function cardSuggest(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/suggest', data)
}

// 刷新页
export function cardRefresh(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/refresh', data)
}

// 搜索
export function cardSearch(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/search', data)
}

// 排行
export function cardRank(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/stars/rank', data)
}

// 更新自己的名片
export function cardUpdate(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/update', data)
}

// 获取自己的名片数据
export function cardCurrent(): Promise<ResponseBody> {
  return request.post('/card/current')
}

// 获取自己的关注名片列表
export function starsCard(): Promise<ResponseBody> {
  return request.post('/card/stars')
}

// 关注
export function starAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/star/add', data)
}

// 取消关注
export function starCancel(data: any = {}): Promise<ResponseBody> {
  return request.post('/card/star/cancel', data)
}
