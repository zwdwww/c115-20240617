import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function groupAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/group/add', data)
}

export function groupCount(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/group/count', data)
}

export function groupInfo(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/group/info', data)
}

export function groupCancel(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/group/cancel', data)
}

export function privateAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/private/add', data)
}

export function privateFind(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/private/find', data)
}

export function sessionInfo(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/session/info', data)
}

export function privateCancel(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/private/cancel', data)
}

export function chatList(): Promise<ResponseBody> {
  return request.post('/chat/list')
}

export function register(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/register', data)
}

export function sendMsg(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/sendMsg', data)
}

export function newMsg(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/newMsg', data)
}

export function history(data: any = {}): Promise<ResponseBody> {
  return request.post('/chat/history', data)
}
