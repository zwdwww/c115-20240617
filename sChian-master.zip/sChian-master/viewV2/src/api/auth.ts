import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function login(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/login', data)
}

export function register(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/register', data)
}

export function sendRegisterMsg(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/sendRegMsg', data)
}

export function logout(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/logout', data)
}

export function logoff(): Promise<ResponseBody> {
  return request.post('/auth/logoff')
}

export function checkExists(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/exists', data)
}

export function getInfo(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/info', data)
}

export function resetPassword(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/reset', data)
}

export function sendVerifyCode(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/sendMsg', data)
}

export function sendForgetVerifyCode(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/forget/sendMsg', data)
}

export function phoneForget(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/forget', data)
}

export function questionForget(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/forget/question', data)
}

export function getQuestionForget(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/forget/question/get', data)
}

export function sendInfoVerifyCode(): Promise<ResponseBody> {
  return request.post('/auth/info/sendMsg')
}

export function infoSetPassword(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/set/password', data)
}

export function infoSetPhone(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/set/phone', data)
}

export function infoSetQuestion(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/set/question', data)
}

export function infoSetAllowLeaveMsg(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/set/allow/leaveMsg', data)
}

export function infoAllowLeaveMsgStatus(data: any = {}): Promise<ResponseBody> {
  return request.post('/auth/leaveMsg/status', data)
}
