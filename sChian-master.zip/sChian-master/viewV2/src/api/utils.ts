import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function searchKeys(): Promise<ResponseBody> {
  return request.post('/search/keys')
}
