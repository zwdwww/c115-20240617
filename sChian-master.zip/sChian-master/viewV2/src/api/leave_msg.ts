import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function leaveMsgList(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/list', data)
}

export function leaveMsgAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/add', data)
}

export function leaveMsgDelOther(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/del-other', data)
}

export function leaveMsgDelMy(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/del-my', data)
}

export function leaveMsgMyAll(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/my-all', data)
}

export function leaveMsgAddLike(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/add-like', data)
}

export function leaveMsgRemLike(data: any = {}): Promise<ResponseBody> {
  return request.post('/leave-msg/rem-like', data)
}
