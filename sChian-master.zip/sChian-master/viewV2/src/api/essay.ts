import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function essayList(data: any = {}): Promise<ResponseBody> {
  return request.post('/essay', data)
}

export function essayAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/essay/add', data)
}

export function essayDel(data: any = {}): Promise<ResponseBody> {
  return request.post('/essay/del', data)
}

export function essayUpdate(data: any = {}): Promise<ResponseBody> {
  return request.post('/essay/update', data)
}

export function essayTopping(data: any = {}): Promise<ResponseBody> {
  return request.post('/essay/topping', data)
}
