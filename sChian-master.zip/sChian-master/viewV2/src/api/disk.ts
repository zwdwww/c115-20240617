import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function diskLs(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/ls', data)
}

export function diskSurplus(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/surplus', data)
}

export function diskRename(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/rename', data)
}

export function newFolder(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/new/folder', data)
}

export function diskRm(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/rm', data)
}

export function diskOrder(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/order', data)
}

export function diskMove(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/move', data)
}

export function diskRoot(): Promise<ResponseBody> {
  return request.post('/disk/root')
}

export function diskUpload(file: File, parent: string): Promise<ResponseBody> {
  const formData = new FormData()
  formData.append('File', file)
  formData.append('parent', parent)
  const config = {
    headers: { 'Content-Type': 'multipart/form-data' },
  }
  return request.post('/disk/upload', formData, config)
}

export function diskShowURI(data: any = {}): Promise<ResponseBody> {
  return request.post('/disk/show', data)
}
