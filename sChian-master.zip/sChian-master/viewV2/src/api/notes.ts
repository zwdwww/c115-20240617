import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function notesGet(data: any = {}): Promise<ResponseBody> {
  return request.post('/notes/get', data)
}

export function notesSet(data: any = {}): Promise<ResponseBody> {
  return request.post('/notes/set', data)
}

export function notesAll(): Promise<ResponseBody> {
  return request.post('/notes/all', {})
}

export function notesDelete(data: any = {}): Promise<ResponseBody> {
  return request.post('/notes/delete', data)
}
