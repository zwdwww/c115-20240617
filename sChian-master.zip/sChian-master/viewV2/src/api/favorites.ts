import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function favList(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/list', data)
}

export function favAdd(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/add', data)
}

export function favCancel(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/cancel', data)
}

export function favUpdate(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/update', data)
}

export function favDel(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/del', data)
}

export function favOrder(data: any = {}): Promise<ResponseBody> {
  return request.post('/favorites/order', data)
}
