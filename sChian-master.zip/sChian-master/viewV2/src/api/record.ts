import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function recordAddress(): Promise<ResponseBody> {
  return request.post('/record/address')
}

export function recordAddressPush(data: any = {}): Promise<ResponseBody> {
  return request.post('/record/address/push', data)
}
