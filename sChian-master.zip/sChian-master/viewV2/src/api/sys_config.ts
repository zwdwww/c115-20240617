import request from '@/utils/request'
import type { ResponseBody } from '@/api/typing'

export function sysConfigGet(data: any = {}): Promise<ResponseBody> {
  return request.post('/sys', data)
}
