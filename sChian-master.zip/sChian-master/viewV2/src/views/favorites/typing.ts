export interface FavItem {
  Created: number
  ID: number
  Key: string
  Uid: string
  Value: string
}
