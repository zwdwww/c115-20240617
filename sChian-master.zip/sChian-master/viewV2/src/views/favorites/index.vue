<script setup lang="ts">
import { type DropdownItemInstance, showFailToast, showSuccessToast } from 'vant'
import { favAdd, favDel, favList, favOrder, favUpdate } from '@/api/favorites'
import type { FavItem } from '@/views/favorites/typing'
import useUserStore from '@/stores/modules/user'
import { getOrderArray, sortOrderArray } from '@/utils/utils'

definePage({
  name: 'favorites',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const toClipboard = useClipboard()
const userStore = useUserStore()

const uid: string = (route.query.id || '') as string
const favItems = ref<Array<FavItem>>([])

const menuRef = ref<DropdownItemInstance>(null)
let menuOption = [
  { text: '打开', value: 1 },
  { text: '分享', value: 2 },
  { text: '复制链接', value: 3 },
]
const menuValue = ref<number>(0)
const menuShow = ref<boolean>(false)
const menuCurrent = ref<FavItem>()

const dialogForm = ref<{
  show: boolean
  name: string
  link: string
  isEdit: boolean
  id: number
}>({ show: false, name: '', link: '', isEdit: false, id: 0 })

onMounted(() => {
  initFav()
})

async function initFav() {
  const resp = (await favList({ id: uid })).data
  const items: Array<FavItem> = resp.items
  favItems.value = sortOrderArray(items, resp.order)
}

async function upsertFav() {
  if (!dialogForm.value.link) {
    showFailToast('网址不能为空')
    return
  }
  if (!dialogForm.value.link.startsWith('http://') && !dialogForm.value.link.startsWith('https://'))
    dialogForm.value.link = `https://${dialogForm.value.link}`

  if (dialogForm.value.isEdit) {
    dialogForm.value.id = menuCurrent.value.ID
    await favUpdate(dialogForm.value)
    menuCurrent.value.Value = dialogForm.value.link
    menuCurrent.value.Key = dialogForm.value.name
    dialogForm.value.name = ''
    dialogForm.value.link = ''
    dialogForm.value.show = false
    dialogForm.value.id = 0
    dialogForm.value.isEdit = false
    showSuccessToast('修改成功')
  }
  else {
    dialogForm.value.name = dialogForm.value.name || '查链导航名称'
    await favAdd(dialogForm.value)
    dialogForm.value.name = ''
    dialogForm.value.link = ''
    dialogForm.value.show = false
    await initFav()
    showSuccessToast('添加成功')
  }
}

// function clickRecommend() {
//   window.open('http://hao.bigdata.ren/', '_blank')
// }

function openUrl(event: any, url: string) {
  const checkWidth = event.target.offsetWidth * 0.7
  if (event.clientX > checkWidth && event.target.localName !== 'span')
    return

  window.open(url, '_blank')
}

function openMenu(item: FavItem) {
  menuCurrent.value = item
  menuShow.value = true
  nextTick(() => {
    menuRef.value.toggle(true)
  })
}

function closeMenu() {
  menuValue.value = 0
  nextTick(() => {
    menuShow.value = false
  })
}

async function changeMenu(value: number) {
  const indexes = getOrderArray(favItems.value)
  const index = indexes.indexOf(menuCurrent.value.ID)
  let swap = null

  switch (value) {
    case 1:
      window.open(menuCurrent.value.Value, '_blank')
      return
    case 2:
      toClipboard.copy(menuCurrent.value.Value)
      showSuccessToast('分享成功')
      return
    case 3:
      toClipboard.copy(menuCurrent.value.Value)
      showSuccessToast('复制成功')
      return
    case 4:
      if (index - 1 < 0)
        return

      swap = favItems.value[index - 1]
      favItems.value[index - 1] = favItems.value[index]
      favItems.value[index] = swap
      await favOrder({ order: getOrderArray(favItems.value) })
      showSuccessToast('上移完成')
      return
    case 5:
      if (index + 1 >= favItems.value.length)
        return

      swap = favItems.value[index + 1]
      favItems.value[index + 1] = favItems.value[index]
      favItems.value[index] = swap
      await favOrder({ order: getOrderArray(favItems.value) })
      showSuccessToast('下移完成')
      return
    case 6:
      dialogForm.value.name = menuCurrent.value.Key
      dialogForm.value.link = menuCurrent.value.Value
      dialogForm.value.id = menuCurrent.value.ID
      dialogForm.value.show = true
      dialogForm.value.isEdit = true
      return
    case 7:
      await favDel({ id: menuCurrent.value.ID, order: [] })
      await initFav()
      showSuccessToast('删除成功')
      return
    case 8:
      dialogForm.value.isEdit = false
      dialogForm.value.show = true
  }
}

if (userStore.isCurrent(uid)) {
  menuOption = menuOption.concat([
    { text: '上移一位', value: 4 },
    { text: '下移一位', value: 5 },
    { text: '修改', value: 6 },
    { text: '删除', value: 7 },
    { text: '自定义添加', value: 8 },
  ])
}
</script>

<template>
  <Top :uid="uid" suffix="导航">
    <template v-if="userStore.isCurrent(uid)" #right>
      <VanIcon style="color: #409eff" class="cursor-pointer" name="plus" />
      <span class="cursor-pointer" style="color: #409eff" @click="dialogForm.show = true">新导航</span>
    </template>
  </Top>

  <VanDialog v-model:show="dialogForm.show" title="添加导航" show-cancel-button @confirm="upsertFav">
    <VanCellGroup>
      <VanField v-model="dialogForm.name" label="名称" placeholder="网址别名" />
      <VanField v-model="dialogForm.link" required placeholder="https://" label="网址" />
    </VanCellGroup>
  </VanDialog>

  <div class="bg-white px-15 py-10">
    <VanDropdownMenu v-show="menuShow" class="menuPos" :close-on-click-outside="false">
      <VanDropdownItem
        ref="menuRef"
        v-model="menuValue"
        :options="menuOption"
        @close="closeMenu"
        @closed="closeMenu"
        @change="changeMenu"
      />
    </VanDropdownMenu>
    <VanCellGroup>
      <VanCell v-for="(item, i) in favItems" :key="i" class="cursor-pointer" :title="item.Key" @click="openUrl($event, item.Value)">
        <template #right-icon>
          <VanIcon class="iconCenter" name="ellipsis" @click="openMenu(item)" />
        </template>
      </VanCell>
    </VanCellGroup>
  </div>
</template>

<style scoped>
  .iconCenter{
    display: flex;
    flex-direction: row;
    align-items: center
  }
  .menuPos{
    position: absolute;
    width: 92%
  }
</style>
