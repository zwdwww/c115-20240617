<script setup lang="ts">
import { showSuccessToast } from 'vant'
import { unixFormat } from '@/utils/date'
import {
  leaveMsgAdd,
  leaveMsgAddLike,
  leaveMsgDelMy,
  leaveMsgDelOther,
  leaveMsgList,
  leaveMsgRemLike,
} from '@/api/leave_msg'
import type { MsgArgs, MsgItem } from '@/views/leave-message/typing'
import useUserStore from '@/stores/modules/user'
import { getManageHttpCard, replaceCardContent } from '@/utils/card'
import { infoAllowLeaveMsgStatus } from '@/api/auth'

definePage({
  name: 'leave-message',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const userStore = useUserStore()

const disable = ref<boolean>(false)
const args = ref<MsgArgs>({ id: (route.query.id || '') as string, page: 1, limit: 20 })
const msgCount = ref<number>(0)
const msgItems = ref<Array<MsgItem>>([])
const msgCurrent = ref<MsgItem>(null)

const dialogForm = ref<{
  cnt: string
  show: boolean
}>({ cnt: '', show: false })

onMounted(() => {
  initLeaveMsg()
  initLeaveMsgStatus()
})

async function initLeaveMsgStatus() {
  const status = (await infoAllowLeaveMsgStatus({ uid: args.value.id })).data
  disable.value = status === 1
}

async function initLeaveMsg() {
  const resp = (await leaveMsgList(args.value)).data
  msgCount.value = resp.count
  msgItems.value = resp.items
  msgCurrent.value = resp.current
}

async function upsertMsg() {
  await leaveMsgAdd({ right: args.value.id, content: dialogForm.value.cnt })
  await initLeaveMsg()
  showSuccessToast('留言成功')
}

async function delMy() {
  await leaveMsgDelMy({ id: msgCurrent.value.ID })
  await initLeaveMsg()
  showSuccessToast('删除成功')
}

async function delOther(item: MsgItem) {
  await leaveMsgDelOther({ id: item.ID })
  await initLeaveMsg()
  showSuccessToast('留言已删除')
}

async function like(item: MsgItem) {
  if (!userStore.isLogin())
    return
  if (item.IsLike) {
    await leaveMsgRemLike({ id: item.ID })
    item.IsLike = false
    item.LikeCount--
  }
  else {
    await leaveMsgAddLike({ id: item.ID })
    item.IsLike = true
    item.LikeCount++
  }
}
</script>

<template>
  <Top :uid="args.id" suffix="留言板" />

  <VanDialog v-model:show="dialogForm.show" title="留言" show-cancel-button @confirm="upsertMsg">
    <VanField
      v-model="dialogForm.cnt"
      rows="5"
      autosize
      type="textarea"
      maxlength="80"
      placeholder="请输入留言"
      show-word-limit
    />
  </VanDialog>

  <div class="bg-white px-15 py-10 text-4xl text-gray-500 leading-10">
    <div style="display: flex;justify-content: right">
      <VanSpace>
        <span><span style="color: firebrick">{{ msgCount }}</span>条留言</span>
        <VanButton v-show="userStore.isLogin()" :disabled="disable" size="mini" type="primary" @click="dialogForm.show = true">
          留 言
        </VanButton>
        <VanButton v-show="userStore.isLogin()" size="mini" type="danger" @click="delMy">
          删除我的留言
        </VanButton>
      </VanSpace>
    </div>

    <VanDivider />

    <VanRow v-for="(item, i) in msgItems" :key="i" class="pb-10" :class="i !== 0 ? 'pt-10' : ''" style="border-bottom: 1px solid rgba(0,0,0,.1)" :gutter="[0, 5]">
      <VanCol span="24">
        <Link :value="item.Left" type="user" />
      </VanCol>
      <VanCol span="24">
        <span class="text-4xl text-gray-500 font-light leading-12">
          <span v-html="replaceCardContent(`&nbsp;&nbsp;&nbsp;&nbsp;${item.Content}`)" />
        </span>
        <!-- <VanTextEllipsis rows="3" :content="replaceCardContent(item.Content)" expand-text="展开" collapse-text="收起" /> -->
      </VanCol>
      <VanCol span="24">
        <div class="flex">
          <span class="w-1/5 text-gray-400">{{ unixFormat('YYYY.mm.dd', item.Updated) }}</span>
          <span class="w-1/5 text-blue-800">IP: {{ item.Ip || '未知' }}</span>
          <Link class="w-1/5 cursor-pointer text-blue-800" value="投诉" :url="getManageHttpCard()" />
          <span class="w-1/5 cursor-pointer text-4xl" :class="item.IsLike ? 'color-red' : ''">
            <VanIcon name="good-job-o" @click="like(item)" />{{ item.LikeCount }}
          </span>
          <span v-show="userStore.isCurrent(args.id)" class="w-1/5 cursor-pointer color-red" @click="delOther(item)">删除</span>
        </div>
      </VanCol>
    </VanRow>
    <VanPagination
      v-show="msgCount > 20"
      v-model="args.page"
      items-per-page="20"
      :total-items="msgCount"
      show-page-size="3"
      force-ellipses
      @change="initLeaveMsg"
    />
  </div>
</template>

<style scoped>

</style>
