export interface MsgArgs {
  id?: string
  page: number
  limit: number
}

export interface MsgItem {
  Content: string
  ID: number
  Left: string
  Right: string
  Updated: number
  LikeCount: number
  IsLike: boolean
  Ip: string
}
