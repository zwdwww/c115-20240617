<script setup lang="ts">
import { closeToast, showLoadingToast } from 'vant'
import type { ChatMsgItem, ChatSessItem } from '@/views/chat/typing'
import { groupCount, history, newMsg, register, sendMsg, sessionInfo } from '@/api/chat'
import useUserStore from '@/stores/modules/user'
import { dateFormat } from '@/utils/date'
import { getHttpCard } from '@/utils/card'
import { windowOpen } from '@/utils/window'

definePage({
  name: 'chat',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const headBar = ref<any>(null)
const tabBar = ref<any>(null)
const msgCntE = ref<any>(null)
const msgCntHeight = ref<number>(0)

const session = ref<ChatSessItem>({} as ChatSessItem)
const chatTitle = ref<string>('')
const cntMsg = ref<string>('')
const timeoutId = ref<any>(0)

const historyForm = ref<{
  loading: boolean
  disabled: boolean
  page: number
  limit: number
  items: Array<ChatMsgItem>
}>({
  loading: false,
  disabled: false,
  page: 1,
  limit: 10,
  items: [],
})

onMounted(() => {
  msgCntHeight.value = window.innerHeight - (headBar.value.$el.clientHeight + tabBar.value.$el.clientHeight)

  showLoadingToast({ message: '', duration: 0 })
  initSession()
})

onUnmounted(() => {
  if (timeoutId.value !== 0)
    window.clearTimeout(timeoutId.value)
  window.console.log('onUnmounted', timeoutId.value)
})

useEventListener('resize', () => {
  msgCntHeight.value = window.innerHeight - (headBar.value.$el.clientHeight + tabBar.value.$el.clientHeight)
})

function scrollToMsgCntEnd() {
  nextTick(() => {
    msgCntE.value.scrollTo(0, msgCntHeight.value)
  })
}

async function initSession() {
  session.value = (await sessionInfo({ sid: route.query.sid })).data
  // 1: 私聊, 2: 群聊
  if (session.value.Type === 1) {
    if (userStore.isCurrent(session.value.Promoter))
      chatTitle.value = session.value.Receiver
    else
      chatTitle.value = session.value.Promoter
  }
  else {
    const peoples = (await groupCount({ sid: session.value.Sid })).data || 0
    chatTitle.value = `${session.value.Promoter}的群聊(${peoples})`
  }

  await loadHistory()
  await sessRegister()
  closeToast()
}

// 注册会话才能获取最新消息
async function sessRegister() {
  await register({ sid: session.value.Sid })
  await getNewMsg()
}

// 获取最新信息
async function getNewMsg() {
  const { items, wait } = (await newMsg({ sid: session.value.Sid })).data
  if (items.length > 0) {
    historyForm.value.items = historyForm.value.items.concat(items)
    scrollToMsgCntEnd()
  }
  window.console.log('wait', wait)
  timeoutId.value = setTimeout(getNewMsg, wait)
}

function transMsgTag(item: ChatMsgItem): ChatMsgItem {
  return {
    ID: -1,
    Sid: 'timeTag',
    Mine: false,
    Msg: dateFormat('YYYY年mm月dd日 HH:MM', new Date(item.Created * 1000)),
    Created: -1,
    Uid: '',
  }
}

// 加载历史信息
async function loadHistory() {
  historyForm.value.loading = true
  const items: Array<ChatMsgItem> = (await history({ page: historyForm.value.page, limit: historyForm.value.limit, sid: session.value.Sid })).data
  const newItems = []
  items.reverse()
  if (items.length > 0) {
    newItems.push(transMsgTag(items[0]))
  }
  else {
    historyForm.value.loading = false
    historyForm.value.disabled = true
    return
  }

  for (const item of items) {
    item.Mine = userStore.isCurrent(item.Uid)
    newItems.push(item)
  }

  historyForm.value.items = newItems.concat(historyForm.value.items)
  historyForm.value.loading = false
  historyForm.value.page++
  scrollToMsgCntEnd()
}

// 发送信息
async function clickSendMsg() {
  if (!cntMsg.value)
    return

  await sendMsg({ sid: session.value.Sid, msg: cntMsg.value })
  historyForm.value.items.push({
    ID: -1,
    Sid: session.value.Sid,
    Mine: true,
    Msg: cntMsg.value,
    Created: -1,
    Uid: userStore.username,
  })
  cntMsg.value = ''
}

function getMsgClass(item: ChatMsgItem, index: number) {
  let classTxt = ''

  if (item.Sid === 'timeTag')
    classTxt = 'text-center'

  if (index > 0)
    classTxt = `${classTxt} mt-20`
  else
    classTxt = `${classTxt} mt-5`

  if (index === historyForm.value.items.length - 1)
    classTxt = `${classTxt} mb-10`

  return classTxt
}

function clickEllipsis() {
  if (session.value.Type === 1)
    windowOpen(getHttpCard(chatTitle.value))
  else
    router.push({ path: '/chat-group', query: { sid: session.value.Sid } })
}
</script>

<template>
  <div>
    <VanNavBar
      ref="headBar"
      :title="chatTitle"
      left-arrow
      @click-left="() => $router.push('/chat-list')"
    >
      <template #right>
        <VanIcon size="30px" name="ellipsis" @click="clickEllipsis" />
      </template>
    </VanNavBar>

    <div id="chatCnt" ref="msgCntE" :style="{ height: `${msgCntHeight}px` }">
      <VanPullRefresh v-model="historyForm.loading" :disabled="historyForm.disabled" @refresh="loadHistory">
        <div v-for="(item, i) in historyForm.items" :key="i" :class="getMsgClass(item, i)">
          <span v-if="item.Sid === 'timeTag'" class="msgTag text-4xl text-gray-500">{{ item.Msg }}</span>
          <div v-else>
            <div v-if="!item.Mine" class="flex">
              <VanIcon size="25" name="contact-o" />
              <div>
                <div v-if="session.Type === 2" class="pl-3 text-4xl text-gray-400">
                  {{ item.Uid }}
                </div>
                <div class="msgCnt text-5xl">
                  {{ item.Msg }}
                </div>
              </div>
            </div>
            <div v-else class="flex justify-end">
              <div>
                <div v-if="session.Type === 2" class="pl-3 text-right text-4xl text-gray-400">
                  {{ item.Uid }}
                </div>
                <div class="msgCntSelf text-5xl">
                  {{ item.Msg }}
                </div>
              </div>
              <VanIcon size="25" name="contact-o" />
            </div>
          </div>
        </div>
      </VanPullRefresh>
    </div>

    <VanTabbar ref="tabBar" style="max-width: 600px;">
      <VanField v-model="cntMsg" placeholder="请输入内容...">
        <template #button>
          <VanButton size="small" type="primary" @click="clickSendMsg">
            发 送
          </VanButton>
        </template>
      </VanField>
    </VanTabbar>
  </div>
</template>

<style scoped>
#chatCnt {
  padding: 15px;
  overflow: auto;
}

.msgCntSelf {
  background-color: #94ea68;
  padding: 8px;
  border-radius: 3px;
}

.msgCnt {
  background-color: white;
  padding: 8px;
  border-radius: 3px;
}

.msgTag{
  background-color: #d8d8d8;
  padding: 2px;
  border-radius: 2px;
}
</style>
