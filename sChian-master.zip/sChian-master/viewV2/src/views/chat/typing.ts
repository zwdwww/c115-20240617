export interface ChatSessItem {
  ID: number
  Sid: string
  Promoter: string
  Receiver: string
  Type: number
  Created: number
}

export interface ChatMsgItem {
  ID: number
  Uid: string
  Sid: string
  Msg: string
  Created: number
  Mine?: boolean
}
