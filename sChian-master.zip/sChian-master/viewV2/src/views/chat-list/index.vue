<script setup lang="ts">
import { chatList } from '@/api/chat'
import type { ChatListItem } from '@/views/chat-list/typing'

definePage({
  name: 'chat-list',
  meta: {
    level: 2,
  },
})

const groupMy = ref<Array<ChatListItem>>([])
const groupOther = ref<Array<ChatListItem>>([])
const privateItems = ref<Array<ChatListItem>>([])

onMounted(() => {
  initChatList()
})

async function initChatList() {
  const resp = (await chatList()).data
  groupMy.value = resp.GroupMy || []
  groupOther.value = resp.GroupOther || []
  privateItems.value = resp.Private || []
}
</script>

<template>
  <VanCellGroup v-if="groupMy.length > 0" title="我创建的群聊">
    <VanCell v-for="item in groupMy" :key="item.Uid" :to="`/chat?sid=${item.Sid}`">
      <template #title>
        <span class="cursor-pointer">{{ item.Uid }}</span>
      </template>
    </VanCell>
  </VanCellGroup>
  <VanCellGroup v-if="groupOther.length > 0" title="我加入的群聊">
    <VanCell v-for="item in groupOther" :key="item.Uid" :to="`/chat?sid=${item.Sid}`">
      <template #title>
        <span class="cursor-pointer">{{ item.Uid }}</span>
      </template>
    </VanCell>
  </VanCellGroup>
  <VanCellGroup v-if="privateItems.length > 0" title="私聊">
    <VanCell v-for="item in privateItems" :key="item.Uid" :to="`/chat?sid=${item.Sid}`" is-link>
      <template #title>
        <span class="cursor-pointer">{{ item.Uid }}</span>
      </template>
    </VanCell>
  </VanCellGroup>
</template>

<style scoped>

</style>
