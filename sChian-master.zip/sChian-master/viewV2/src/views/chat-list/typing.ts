export interface ChatListItem {
  Sid: string
  Uid: string
}
