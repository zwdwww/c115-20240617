<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { cardRefresh } from '@/api/card'
import useRefreshStore from '@/stores/modules/refresh'

definePage({
  name: 'home',
  meta: {
    level: 2,
  },
})

const refreshStore = useRefreshStore()
const { refresh } = storeToRefs(refreshStore)

onMounted(() => {
  initCard()
})

watch(() => refresh.value.page, () => {
  initCard()
})

async function initCard() {
  refresh.value.loading = true
  const resp = (await cardRefresh({ page: refresh.value.page })).data
  refresh.value.items = resp.items || []
  refresh.value.count = resp.count
  refresh.value.loading = false
}
</script>

<template>
  <div>
    <VanSkeleton title :row="4" :loading="refresh.loading">
      <Card v-for="(item, i) in refresh.items" :key="i" :body="item" :index="i" />
      <VanPagination
        v-model="refresh.page"
        items-per-page="10"
        :total-items="refresh.count"
        show-page-size="3"
        force-ellipses
        @change="initCard"
      />
    </VanSkeleton>
  </div>
</template>
