export interface HomeValues {
  page: number
  count: number
  loading: boolean
  cardItems: any
  isFirst: boolean // 第一次加载
  scrollX?: number // 记录位置
  scrollY?: number
  isFirstInto: boolean // 第一次加载页面
}

export interface RefreshValues {
  page: number
  count: number
  loading: boolean
  items: any
}
