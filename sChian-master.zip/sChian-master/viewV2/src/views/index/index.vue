<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useEventListener } from '@vant/use'
import { cardSearch, cardSuggest } from '@/api/card'
import useHomeStore from '@/stores/modules/home'
import { getCardByHost } from '@/utils/card'

definePage({
  name: '/',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const homeStore = useHomeStore()
const { home } = storeToRefs(homeStore)

useEventListener(
  'scroll',
  () => {
    home.value.scrollX = window.scrollX
    home.value.scrollY = window.scrollY
  },
)

onMounted(() => {
  if (home.value.isFirst) {
    initCard()
    home.value.isFirst = false
  }
  else {
    window.scrollTo(home.value.scrollX, home.value.scrollY)
  }
})

watch(() => route.query, (query) => {
  home.value.page = 1
  initCard()
  window.console.log('watch query', query)
})

// 获取名片的Index
function findCardsById(items: Array<any>, topCard: any) {
  if (topCard === null)
    return -1

  for (let i = 0; i < items.length; i++) {
    if (items[i].Uid === topCard.Uid)
      return i
  }
  return -1
}

async function initCard() {
  const id = getCardByHost(location.host || '')
  home.value.loading = true
  let resp = null
  if (Object.keys(route.query).length !== 0) {
    const args: any = { ...route.query }
    args.page = home.value.page
    if (typeof args.addr === 'string')
      args.addr = [args.addr]

    resp = (await cardSearch(args)).data
  }
  else {
    window.console.log('isFirstInto', home.value.isFirstInto)
    if (home.value.isFirstInto) {
      resp = (await cardSuggest({ page: home.value.page, id })).data
      home.value.isFirstInto = false
    }
    else {
      resp = (await cardSuggest({ page: home.value.page })).data
    }
  }

  if (resp.card) {
    const findIndex = findCardsById(resp.items || [], resp.card)
    if (findIndex === -1) {
      home.value.cardItems = [resp.card].concat(resp.items || [])
    }
    else {
      const items = resp.items
      const swap = resp.items[findIndex]
      items[findIndex] = items[0]
      items[0] = swap
      home.value.cardItems = items
    }
  }
  else {
    home.value.cardItems = resp.items || []
  }

  home.value.count = resp.count
  home.value.loading = false
  window.scrollTo(0, 0)
}
</script>

<template>
  <div>
    <VanSkeleton title :row="4" :loading="home.loading">
      <Card v-for="(item, i) in home.cardItems" :key="i" :body="item" :index="i" />
      <VanPagination
        v-model="home.page"
        items-per-page="10"
        :total-items="home.count"
        show-page-size="3"
        force-ellipses
        @change="initCard"
      />
    </VanSkeleton>
  </div>
</template>
