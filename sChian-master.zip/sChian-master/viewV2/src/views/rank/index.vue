<script setup lang="ts">
import { cardRank } from '@/api/card'
import type { HomeValues } from '@/views/index/typing'

definePage({
  name: 'rank',
  meta: {
    level: 2,
  },
})

const rank = ref<HomeValues>({
  page: 1,
  count: 0,
  loading: false,
  cardItems: [],
  isFirst: true,
  isFirstInto: false,
})

onMounted(() => {
  initCard()
})

async function initCard() {
  rank.value.loading = true
  const resp = (await cardRank({ page: rank.value.page })).data
  rank.value.count = resp.count
  rank.value.cardItems = resp.items || []
  rank.value.loading = false
  window.scrollTo(0, 0)
}
</script>

<template>
  <div>
    <VanSkeleton title :row="4" :loading="rank.loading">
      <Card v-for="(item, i) in rank.cardItems" :key="i" :body="item" :index="i" />
      <VanPagination
        v-model="rank.page"
        items-per-page="10"
        :total-items="rank.count"
        show-page-size="3"
        force-ellipses
        @change="initCard"
      />
    </VanSkeleton>
  </div>
</template>
