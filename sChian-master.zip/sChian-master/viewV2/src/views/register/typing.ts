export interface RegisterForm {
  username: string
  password: string
  phone: string
  verifyCode: string
}
