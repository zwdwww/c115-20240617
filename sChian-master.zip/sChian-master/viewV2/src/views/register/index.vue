<script setup lang="ts">
import { type FieldRuleValidator, closeToast, showFailToast, showLoadingToast, showSuccessToast } from 'vant'
import type { RegisterForm } from './typing'
import { getDomain, getHttpCard, getManageHttpCard } from '@/utils/card'
import { checkExists, register, sendRegisterMsg } from '@/api/auth'
import useUserStore from '@/stores/modules/user'
import { PhoneRegex } from '@/utils/utils'

definePage({
  name: 'register',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()

const lastAgreeCheck = ref<string>('0')
const agreeCheck = ref<string>('1')
const tabActive = ref<number>(0)
const registerForm = ref<RegisterForm>({} as RegisterForm)
const wait60Seconds = ref<number>(0)
const timeoutId = ref<any>(0)

onUnmounted(() => {
  if (timeoutId.value !== 0)
    window.clearTimeout(timeoutId.value)
  window.console.log('onUnmounted', timeoutId.value)
})

const verifyCodeBtn = computed(() => {
  if (wait60Seconds.value === 0)
    return '获取验证码'
  return `${wait60Seconds.value}秒后重新发送`
})

function validatorAccount(val: string) {
  return new Promise((resolve) => {
    checkExists({ username: val }).then((resp) => {
      if (resp.data)
        return resolve('ID已被注册')
      resolve(true)
    })
  })
}

function validatorPassword(val: string) {
  if (val.length < 8)
    return '密码不能小于8位'
  return true
}

function validatorAccountTwo(val: string) {
  return new Promise((resolve) => {
    if (PhoneRegex.test(val)) {
      resolve('其他数字ID不能为手机号')
    }
    else {
      checkExists({ username: val }).then((resp) => {
        if (resp.data)
          return resolve('ID已被注册')
        resolve(true)
      })
    }
  })
}

function countdown() {
  wait60Seconds.value--
  if (wait60Seconds.value === 0)
    return
  timeoutId.value = setTimeout(countdown, 1000)
}

async function sendVerifyCode() {
  if (wait60Seconds.value !== 0) {
    showFailToast('发送频繁')
    return
  }
  const tmpForm = { username: registerForm.value.username, phone: registerForm.value.phone }
  if (tabActive.value === 0)
    tmpForm.username = registerForm.value.phone

  if (!PhoneRegex.test(registerForm.value.phone)) {
    showFailToast('手机号异常')
    return
  }

  await sendRegisterMsg(tmpForm)
  wait60Seconds.value = 60
  countdown()
}

function registerSubmit() {
  const tmpForm: any = { ...registerForm.value }
  tmpForm.type = tabActive.value.toString()
  if (tabActive.value === 0)
    tmpForm.username = tmpForm.phone

  if (agreeCheck.value !== '1') {
    showFailToast('请勾选同意服务条款')
    return
  }

  showLoadingToast({ message: '注册中...', duration: 0 })
  register(tmpForm).then((resp) => {
    closeToast()
    showSuccessToast('注册成功')
    userStore.loginSuccess(resp.data)
    location.href = getHttpCard(tmpForm.username)
  }).catch(() => {
    closeToast()
    showFailToast('注册失败')
  })
}

function agreeOptionClick(e: any) {
  if (e.target.localName === 'span') {
    window.open(getManageHttpCard())
    return
  }

  if (lastAgreeCheck.value === '1') {
    agreeCheck.value = '0'
    lastAgreeCheck.value = '0'
  }
  else {
    lastAgreeCheck.value = '1'
  }
}
</script>

<template>
  <div class="h-full pt-70">
    <VanTabs v-model:active="tabActive">
      <VanTab title="手机号注册ID">
        <VanForm @submit="registerSubmit">
          <VanCellGroup>
            <VanField
              v-model="registerForm.phone"
              placeholder="请输入手机号"
              :rules="[{ trigger: 'onSubmit', required: true, pattern: PhoneRegex, message: '请输入正确的手机号', validator: validatorAccount as FieldRuleValidator }]"
            >
              <template #button>
                <span>.{{ getDomain() }}</span>
              </template>
            </VanField>
            <VanField
              v-model="registerForm.password"
              :rules="[{ required: true, trigger: 'onSubmit', validator: validatorPassword, message: '请输入密码' }]"
              placeholder="请输入密码"
            />
            <VanField
              v-model="registerForm.verifyCode"
              :rules="[{ required: true, trigger: 'onSubmit', message: '请输入验证码' }]"
              placeholder="请输入验证码"
              clearable
            >
              <template #button>
                <VanButton size="small" type="primary" @click="sendVerifyCode">
                  {{ verifyCodeBtn }}
                </VanButton>
              </template>
            </VanField>
            <VanRow gutter="10" class="py-5">
              <VanCol span="11" offset="1">
                <VanButton type="default" size="normal" plain block to="/login">
                  登 录
                </VanButton>
              </VanCol>
              <VanCol span="11">
                <VanButton native-type="submit" type="primary" size="normal" block>
                  注 册
                </VanButton>
              </VanCol>
            </VanRow>
          </VanCellGroup>
        </VanForm>
      </VanTab>
      <VanTab title="非手机号注册ID">
        <VanForm @submit="registerSubmit">
          <VanCellGroup>
            <VanField
              v-model="registerForm.username"
              maxlength="13"
              :rules="[{ trigger: 'onSubmit', required: true, message: '请输入正确的ID', validator: validatorAccountTwo as FieldRuleValidator }]"
              placeholder="7~13位数字/QQ/座机"
            >
              <template #button>
                <span>.{{ getDomain() }}</span>
              </template>
            </VanField>
            <VanField
              v-model="registerForm.phone"
              :rules="[{ trigger: 'onSubmit', required: true, pattern: PhoneRegex, message: '请输入正确的手机号' }]"
              placeholder="请输入手机号码"
            />
            <VanField
              v-model="registerForm.password"
              :rules="[{ required: true, trigger: 'onSubmit', validator: validatorPassword, message: '请输入密码' }]"
              placeholder="请输入密码"
            />
            <VanField
              v-model="registerForm.verifyCode"
              :rules="[{ required: true, trigger: 'onSubmit', message: '请输入验证码' }]"
              placeholder="请输入验证码"
              clearable
            >
              <template #button>
                <VanButton size="small" type="primary" @click="sendVerifyCode">
                  {{ verifyCodeBtn }}
                </VanButton>
              </template>
            </VanField>
            <VanRow gutter="10" class="py-5">
              <VanCol span="11" offset="1">
                <VanButton type="default" size="normal" plain block to="/login">
                  登 录
                </VanButton>
              </VanCol>
              <VanCol span="11">
                <VanButton native-type="submit" type="primary" size="normal" block>
                  注 册
                </VanButton>
              </VanCol>
            </VanRow>
          </VanCellGroup>
        </VanForm>
      </VanTab>
      <van-radio-group v-model="agreeCheck" icon-size="15px" shape="square" class="flex justify-center py-15">
        <van-radio name="1" @click="agreeOptionClick">
          注册即表示同意
          <span style="color: dodgerblue">《用户协议》</span>
          和
          <span style="color: dodgerblue">《隐私政策》</span>
        </van-radio>
      </van-radio-group>
    </VanTabs>
  </div>
</template>

<style scoped>

</style>
