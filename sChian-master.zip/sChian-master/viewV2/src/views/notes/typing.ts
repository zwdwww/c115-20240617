export interface NoteItem {
  ID: number
  Left: string
  Right: string
  Cnt: string
}
