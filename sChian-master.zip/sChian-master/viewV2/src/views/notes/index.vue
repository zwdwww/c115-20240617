<script setup lang="ts">
import { showSuccessToast } from 'vant'
import useUserStore from '@/stores/modules/user'
import type { NoteItem } from '@/views/notes/typing'
import { notesAll, notesDelete } from '@/api/notes'
import { getCard, getHttpCard } from '@/utils/card'
import { windowOpen } from '@/utils/window'

definePage({
  name: 'notes',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()

const items = ref<Array<NoteItem>>([])
const uid = ref<string>(userStore.username)

onMounted(() => {
  initNotes()
})

async function initNotes() {
  items.value = (await notesAll()).data || []
}

async function remove(right: string) {
  await notesDelete({ right })
  await initNotes()
  showSuccessToast('删除成功')
}

async function clickCell(uid: string) {
  windowOpen(getHttpCard(uid))
}
</script>

<template>
  <Top :uid="uid" suffix="的备注" />
  <VanCellGroup class="pt-8">
    <VanCell
      v-for="item in items"
      :key="item.Right"
      class="hover:text-blue"
      :title="getCard(item.Right)"
      :value="item.Cnt"
      center
      @click="clickCell(item.Right)"
    >
      <template #right-icon>
        <VanIcon class="ml-5 cursor-pointer hover:text-red" name="cross" @click="remove(item.Right)" />
      </template>
    </VanCell>
  </VanCellGroup>
</template>

<style scoped>

</style>
