<script setup lang="ts">
import { closeToast, showFailToast, showLoadingToast, showSuccessToast } from 'vant'
import type { LoginForm } from './typing'
import { getDomain, getHttpCard } from '@/utils/card'
import useUserStore from '@/stores/modules/user'
import { login, sendVerifyCode } from '@/api/auth'

definePage({
  name: 'login',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()
const route = useRoute()
const router = useRouter()

const timeoutId = ref<any>(0)
const wait60Seconds = ref<number>(0)
const loginForm = ref<LoginForm>({
  account: '',
  password: '',
  verifyCode: '',
})

const whitePath = ['/my', '/', '/rank']

onMounted(() => {
  const state = router.options.history.state || {}
  if (userStore.isLogin() && !whitePath.includes(state.back as string)) {
    if (state.back)
      router.back()
    else
      router.push('/my')
    return
  }

  loginForm.value.account = (route.query.id || '') as string
})

function handleLogin(values: any) {
  showLoadingToast({ message: '登录中...', duration: 0 })
  login(values).then((resp) => {
    userStore.loginSuccess(resp.data)
    closeToast()
    showSuccessToast('登录成功')
    location.href = `${getHttpCard(values.username)}`
  }).catch(() => {
    closeToast()
  })
}

function countdown() {
  wait60Seconds.value--
  if (wait60Seconds.value <= 0)
    return
  timeoutId.value = setTimeout(countdown, 1000)
}

const verifyCodeBtn = computed(() => {
  if (wait60Seconds.value <= 0)
    return '获取验证码'
  return `${wait60Seconds.value}秒后重新发送`
})

async function sendMsgCode() {
  if (wait60Seconds.value !== 0) {
    showFailToast('发送频繁')
    return
  }
  if (loginForm.value.account === '') {
    showFailToast('请先输入登录ID')
    return
  }
  await sendVerifyCode({ username: loginForm.value.account })
  wait60Seconds.value = 60
  countdown()
}
</script>

<template>
  <div class="h-full pt-85">
    <VanForm @submit="handleLogin">
      <VanCellGroup inset>
        <VanField
          v-model="loginForm.account"
          name="username"
          :rules="[{ required: true, message: '请输入登录ID' }]"
          placeholder="登录ID(7~13位数字/手机号/QQ)"
        >
          <template #button>
            <span>.{{ getDomain() }}</span>
          </template>
        </VanField>
        <VanField
          v-model="loginForm.password"
          name="password"
          placeholder="请输入密码(可选)"
        />
        <VanField v-model="loginForm.verifyCode" name="verifyCode" placeholder="请输入验证码(可选)" center clearable>
          <template #button>
            <VanButton size="small" type="primary" @click="sendMsgCode">
              {{ verifyCodeBtn }}
            </VanButton>
          </template>
        </VanField>
        <VanRow gutter="10" class="py-5">
          <VanCol span="11" offset="1">
            <VanButton type="default" size="normal" plain block to="/register">
              注 册
            </VanButton>
          </VanCol>
          <VanCol span="11">
            <VanButton native-type="submit" type="primary" size="normal" block>
              登 录
            </VanButton>
          </VanCol>
        </VanRow>
      </VanCellGroup>
    </VanForm>
    <div style="text-align: center" class="py-10 text-5xl text-gray-500 leading-15">
      <VanSpace direction="vertical">
        <div>客服 <Link type="user" value="13017181618" /></div>
        <div>测试 <Link type="user" value="12345678" />（密码8个8）</div>
        <div>
          投诉
          <Link style="color: #409eff;" class="cursor-pointer" url="https://www.12377.cn/" value="www.12377.cn" />
        </div>
        <div>Copyright©2018</div>
      </VanSpace>
    </div>
  </div>
</template>

<style scoped>

</style>
