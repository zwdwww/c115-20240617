<script setup lang="ts">
import { groupInfo } from '@/api/chat'
import { getCard, getHttpCard } from '@/utils/card'

definePage({
  name: 'chat-group',
  meta: {
    level: 2,
  },
})

const route = useRoute()

const title = ref<string>('')
const items = ref<Array<string>>([])
const master = ref<string>('')

onMounted(() => {
  initData()
})

async function initData() {
  const resp = (await groupInfo({ sid: route.query.sid })).data || {}
  if (!resp.Master)
    return
  master.value = resp.Master
  items.value = resp.Peoples
  title.value = `${master.value}的群聊(${items.value.length})`
}
</script>

<template>
  <Top :uid="master" suffix="群聊" />

  <VanCellGroup title="群主">
    <VanCell :title="getCard(master)" is-link :url="getHttpCard(master)" />
  </VanCellGroup>
  <VanCellGroup title="成员">
    <VanCell v-for="item in items" :key="item" :title="getCard(item)" is-link :url="getHttpCard(item)" />
  </VanCellGroup>
</template>

<style scoped>
</style>
