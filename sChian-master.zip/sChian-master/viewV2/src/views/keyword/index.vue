<script setup lang="ts">
import { searchKeys } from '@/api/utils'
import useHomeStore from '@/stores/modules/home'

definePage({
  name: 'keyword',
  meta: {
    level: 2,
  },
})

const router = useRouter()
const homeStore = useHomeStore()

const offsetTop = ref<number>(0)
const indexList = ref<Array<string>>([])
const keysMap = ref<any>({})

onMounted(() => {
  offsetTop.value = document.getElementById('tabs').clientHeight + document.getElementById('navBar').clientHeight
  initKeywords()
})

async function initKeywords() {
  const resp = (await searchKeys()).data
  keysMap.value = resp.keysMap || {}
  indexList.value = Object.keys(keysMap.value)
}

function clickKey(key: string) {
  homeStore.reset()
  router.push({ path: '/', query: { key } })
}
</script>

<template>
  <VanIndexBar :sticky-offset-top="offsetTop" :index-list="indexList">
    <template v-for="key in indexList" :key="key">
      <VanIndexAnchor :index="key" />
      <VanCell v-for="(v, i) in keysMap[key]" :key="i" class="cursor-pointer hover:text-blue" :title="v" @click="clickKey(v)" />
    </template>
  </VanIndexBar>
</template>

<style scoped>
</style>
