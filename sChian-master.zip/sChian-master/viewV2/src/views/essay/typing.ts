export interface EssayItem {
  ID: number
  Essay: string
  Top: number
  Uid: string
  Updated: number
  Checked?: boolean
}
