<script setup lang="ts">
import { type RowJustify, showFailToast, showSuccessToast } from 'vant'
import { unixFormat } from '@/utils/date'
import { indexArray, isMobile } from '@/utils/utils'
import { essayAdd, essayDel, essayList, essayTopping, essayUpdate } from '@/api/essay'
import type { EssayItem } from '@/views/essay/typing'
import useUserStore from '@/stores/modules/user'
import { getCard, getHttpCard, replaceCardContent } from '@/utils/card'

definePage({
  name: 'essay',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const userStore = useUserStore()
const toClipboard = useClipboard()

const showDialog = ref<boolean>(false)
const showDialogEssay = ref<string>('')
const dialogTitle = ref<string>('')
const dialogIsEdit = ref<boolean>(false)
const dialogAlterItem = ref<EssayItem>()

const uid = ref<string>((route.query.id || '') as string)
const isCurrent = userStore.isCurrent(uid.value)
const rowJustify = ref<RowJustify>('center')
const checkBoxiconSize = ref<number>(15)
const items = ref<Array<EssayItem>>([])

onMounted(() => {
  initEssay()
})

async function initEssay() {
  const values: Array<EssayItem> = (await essayList({ id: uid.value })).data
  const list = []
  const tmp = []
  for (const item of values) {
    if (item.Top === 1) {
      item.Checked = true
      list.push(item)
    }
    else {
      item.Checked = false
      tmp.push(item)
    }
  }
  items.value = list.concat(tmp)
}

function copy(text: string) {
  const cnt = `${text}\n名片: ${getCard(uid.value)}\n链接: ${getHttpCard(uid.value)}\n来源: 查链\n著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。`
  toClipboard.copy(cnt)
  showSuccessToast('复制成功')
}

function openAlterEssay(item: EssayItem) {
  dialogTitle.value = '修改短文'
  dialogAlterItem.value = item
  showDialogEssay.value = item.Essay
  showDialog.value = true
  dialogIsEdit.value = true
}

function openAddEssay() {
  dialogTitle.value = '添加短文'
  showDialogEssay.value = ''
  showDialog.value = true
  dialogIsEdit.value = false
}

async function upsertEssay() {
  if (dialogIsEdit.value) {
    await essayUpdate({ id: dialogAlterItem.value.ID, essay: showDialogEssay.value })
    dialogAlterItem.value.Essay = showDialogEssay.value
    showDialog.value = false
    showSuccessToast('修改成功')
  }
  else {
    const item: EssayItem = (await essayAdd({ essay: showDialogEssay.value })).data
    item.Checked = false
    items.value.push(item)
    showDialog.value = false
    showSuccessToast('添加成功')
  }
}

async function removeEssay(item: EssayItem) {
  if (item.Top === 1) {
    showFailToast('必须保留一个置顶短文')
    return
  }
  await essayDel({ id: item.ID })
  items.value.splice(indexArray(items.value, item.ID, item => item.ID))
  showSuccessToast('短文已删除')
}

async function topping(item: EssayItem) {
  item.Checked = item.Top === 1
  if (item.Top === 1)
    return
  await essayTopping({ id: item.ID })
  const newItems = []
  for (const item1 of items.value) {
    if (item1.ID === item.ID)
      continue
    if (item1.Top === 1) {
      item1.Checked = false
      item1.Top = 0
    }
    newItems.push(item1)
  }
  item.Top = 1
  item.Checked = true
  items.value = [item].concat(newItems)
  showSuccessToast('置顶成功')
}

if (isMobile())
  checkBoxiconSize.value = 10

if (!isCurrent)
  rowJustify.value = 'start'
</script>

<template>
  <Top :uid="uid" suffix="短文">
    <template v-if="isCurrent" #right>
      <VanIcon style="color: #409eff" class="cursor-pointer" name="plus" />
      <span class="cursor-pointer" style="color: #409eff" @click="openAddEssay">新增短文</span>
    </template>
  </Top>
  <VanDialog v-model:show="showDialog" :title="dialogTitle" show-cancel-button @confirm="upsertEssay">
    <VanField
      v-model="showDialogEssay"
      rows="5"

      type="textarea"
      maxlength="300"
      placeholder="请输入短文"
      show-word-limit autosize
    />
  </VanDialog>
  <div class="bg-white px-15 pb-5 text-4xl text-gray-500 leading-10">
    <div v-for="(item, i) in items" :key="i" class="cnt pt-8">
      <div v-html="replaceCardContent(`&nbsp;&nbsp;&nbsp;&nbsp;${item.Essay}`)" />
      <VanRow class="pt-5" :justify="rowJustify">
        <VanCol v-show="isCurrent" span="5">
          <VanCheckbox v-model="item.Checked" :icon-size="checkBoxiconSize" @click="topping(item)">
            <span class="text-4xl text-gray-500">置顶</span>
          </VanCheckbox>
        </VanCol>
        <VanCol v-show="isCurrent" class="col" span="4">
          <span class="item" @click="openAlterEssay(item)">修改</span>
        </VanCol>
        <VanCol v-show="isCurrent" class="col" span="4">
          <span class="item" @click="removeEssay(item)">删除</span>
        </VanCol>
        <VanCol class="col" span="4">
          <span class="item" @click="copy(item.Essay)">复制</span>
        </VanCol>
        <VanCol class="col" span="4" offset="1">
          <span class="item text-3xl">{{ unixFormat('YYYY.mm.dd', item.Updated) }}</span>
        </VanCol>
      </VanRow>
    </div>
  </div>
</template>

<style scoped>
.cnt{
  border-bottom: 1px solid rgba(0, 0, 0, .1)
}

.item{
  cursor: pointer;
}

.col{
  display: flex;
  align-items: center;
}
</style>
