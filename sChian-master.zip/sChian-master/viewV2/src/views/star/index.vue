<script setup lang="ts">
import type { CardBody } from '@/components/card/typing'
import { starsCard } from '@/api/card'

definePage({
  name: 'star',
  meta: {
    level: 2,
  },
})

const items = ref<Array<CardBody>>([])
const loading = ref<boolean>(false)

onMounted(() => {
  initCard()
})

async function initCard() {
  loading.value = true
  items.value = (await starsCard()).data
  loading.value = false
}
</script>

<template>
  <VanEmpty v-if="items.length === 0" description="无关注名片" />
  <VanSkeleton v-else title :row="4" :loading="loading">
    <Card v-for="(item, i) in items" :key="i" :body="item" :index="i" />
  </VanSkeleton>
</template>
