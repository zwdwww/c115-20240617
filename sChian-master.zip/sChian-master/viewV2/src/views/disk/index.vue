<script setup lang="ts">
import { type DropdownItemInstance, closeToast, showFailToast, showLoadingToast, showSuccessToast } from 'vant'
import {
  diskLs,
  diskOrder,
  diskRename,
  diskRm,
  diskRoot,
  diskShowURI,
  diskSurplus,
  diskUpload,
  newFolder,
} from '@/api/disk'
import { GetFileIcon } from '@/utils/file-type'
import type { DiskItem } from '@/views/disk/typing'
import useUserStore from '@/stores/modules/user'
import { windowOpen } from '@/utils/window'
import { unixFormat } from '@/utils/date'

definePage({
  name: 'disk',
  meta: {
    level: 2,
  },
})

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const toClipboard = useClipboard()

const uid = ref<string>((route.query.id || '') as string)
const roots = ref<Array<DiskItem>>([])
const currentItems = ref<Array<DiskItem>>([])
const currentAuth = ref<boolean>(true) // 查看权限
const currentPath = ref<string>('')
const topValue = ref<string>('')
const surplus = ref<string>('')
const diskSize = ref<number>(0)

const menuRef = ref<DropdownItemInstance>(null)
const menuOption = ref<any>([])
const menuValue = ref<number>(0)
const menuShow = ref<boolean>(false)
const menuCurrent = ref<DiskItem>()

const dialogForm = ref<any>({
  show: false,
  title: '',
  value: '',
  type: 1, // 1 创建文件夹, 2 文件/文件夹重命名
})

function openAddDirectDialog() {
  if (!userStore.isLogin()) {
    router.push('/login')
    return
  }
  dialogForm.value.show = true
  dialogForm.value.title = '创建文件夹'
  dialogForm.value.value = ''
  dialogForm.value.type = 1
}

function getMenuOptions(type: string) {
  if (userStore.isCurrent(uid.value)) {
    if (type === 'dir') {
      return [
        { text: '打开', value: 1 },
        { text: '上移一位', value: 5 },
        { text: '下移一位', value: 6 },
        { text: '重命名', value: 7 },
        { text: '移动', value: 8 },
        { text: '删除', value: 9 },
      ]
    }
    return [
      { text: '打开', value: 1 },
      { text: '分享', value: 2 },
      { text: '下载', value: 3 },
      { text: '复制链接', value: 4 },
      { text: '上移一位', value: 5 },
      { text: '下移一位', value: 6 },
      { text: '重命名', value: 7 },
      { text: '移动', value: 8 },
      { text: '删除', value: 9 },
    ]
  }
  // 不是本人权限
  if (type === 'dir') {
    return [
      { text: '打开', value: 1 },
    ]
  }
  return [
    { text: '打开', value: 1 },
    { text: '分享', value: 2 },
    { text: '下载', value: 3 },
    { text: '复制链接', value: 4 },
  ]
}

// 是否存在相同的文件夹名
function isSameDirectName(name: string) {
  for (const ele of currentItems.value) {
    if (name === ele.FileName)
      return true
  }
  return false
}

// 检查文件夹名称
function checkFolderName(name: string) {
  if (name === '') {
    showFailToast('文件夹名不能为空')
    return false
  }
  if (name.includes('/')) {
    showFailToast('文件夹名不能包含特殊符号/')
    return false
  }
  if (isSameDirectName(name)) {
    showFailToast('文件夹已存在')
    return false
  }
  return true
}

// 创建文件夹
async function createdFolder() {
  if (!checkFolderName(dialogForm.value.value))
    return

  const data = (await newFolder({ parent: currentPath.value, name: dialogForm.value.value })).data
  currentItems.value.push(data)
  showSuccessToast('创建成功')
}

// Dialog点击确认
async function conformDialog() {
  switch (dialogForm.value.type) {
    case 1:
      await createdFolder()
      return
    case 2:
      if (checkFolderName(dialogForm.value.value)) {
        await diskRename({ id: menuCurrent.value.ID, new: dialogForm.value.value })
        menuCurrent.value.FileName = dialogForm.value.value
        showSuccessToast('重命名成功')
      }
  }
}

watch(() => route.query, (newValue) => {
  if (newValue.path)
    changeDirect(newValue.path as string)
  else
    backupRoot()
})

onMounted(() => {
  initRoots()
  if (userStore.isCurrent(uid.value))
    initSurplus()
})

// 初始化根节点
async function initRoots() {
  roots.value = (await diskRoot()).data || []
  currentItems.value = roots.value

  if (route.query.path)
    await changeDirect(route.query.path as string)

  if (route.query.to)
    await previewFile(route.query.to as string)
}

// 初始化剩余空间
async function initSurplus() {
  const size = (await diskSurplus()).data || 0
  diskSize.value = size
  surplus.value = (size / 1024 / 1024).toFixed(2)
}

function isRootPath(path: string) {
  for (const root of roots.value) {
    if (root.Path === path)
      return true
  }
  return false
}

// 转换网盘Item对象的路径
function getDiskItemPath(item: DiskItem): string {
  if (item.Path)
    return item.Path

  return `/${item.FileName}`
}

// 处理文件夹响应
function handleDiskRespItems(data: any) {
  const items = data.items || []
  const itemsOrder = {}
  const order = data.order || []
  for (let i = 0; i < order.length; i++)
    itemsOrder[order[i]] = i

  items.sort((a: any, b: any) => {
    return (itemsOrder[a.ID] || 0) - (itemsOrder[b.ID] || 0)
  })
  return items
}

// 记录路由路径
function addRouterQuery(k: string, v: string) {
  const query = { ...route.query }
  if ('to' in query)
    delete query.to

  if (v === '') {
    delete query[k]
    router.push({ query })
  }
  else if (query[k] !== v) {
    query[k] = v
    router.push({ query })
  }
}

function indexOfRoots(path: string) {
  for (const root of roots.value) {
    if (path === root.Path)
      return root
  }
  return null
}

// 切换目录
async function changeDirect(path: string) {
  showLoadingToast('加载中...')
  const data = (await diskLs({ path, id: uid.value })).data
  addRouterQuery('path', path)
  topValue.value = isRootPath(path) ? indexOfRoots(path).FileName : path.substring(path.lastIndexOf('/') + 1)
  currentItems.value = handleDiskRespItems(data)
  currentPath.value = path
  currentAuth.value = data.auth || false
  closeToast()
}

// previewFile 预览文件
async function previewFile(md5: string) {
  const respUri = (await diskShowURI({ md5 })).data
  if (respUri) {
    windowOpen(respUri, '_blank')
    addRouterQuery('to', '')
  }
  else {
    showFailToast('无法预览该文件')
  }
}

// 获取子文件夹
async function ls(event: any, item: DiskItem) {
  if (event !== null) {
    const checkWidth = event.target.offsetWidth * 0.7
    if (event.clientX > checkWidth && event.target.localName !== 'span')
      return
  }

  if (item.FileType !== 'dir') {
    await previewFile(item.FileMd5)
    return
  }
  const filePath = getDiskItemPath(item)
  const mergePath = `${currentPath.value}${filePath}`
  await changeDirect(mergePath)
}

function backupRoot() {
  currentPath.value = ''
  currentItems.value = roots.value
  topValue.value = ''
}

// 回退上一级
function backup() {
  if (isRootPath(currentPath.value)) {
    backupRoot()
    addRouterQuery('path', '')
  }
  else {
    const index = currentPath.value.lastIndexOf('/')
    changeDirect(currentPath.value.substring(0, index))
  }
}

// 记录当前目录的文件排序
async function setCurrentItemsOrder() {
  const order = []
  for (const item of currentItems.value)
    order.push(item.ID)

  await diskOrder({ path: currentPath.value, order })
}

// 上传之前检查
function beforeUpload(file: File): any {
  if (!userStore.isLogin()) {
    router.push('/login')
    return
  }
  if (!userStore.isCurrent(uid.value))
    return

  return new Promise((resolve, reject) => {
    if (file.size > diskSize.value) {
      showFailToast('空间不足,请清理多余文件或升级存储空间')
      reject(new Error('false'))
    }
    else {
      showLoadingToast({ message: '上传中,请等待...', duration: 0 })
      diskUpload(file, currentPath.value).then((resp) => {
        const data = resp.data
        currentItems.value.push(data)
        initSurplus()
        setCurrentItemsOrder()
        closeToast()
        resolve(file)
      }).catch((err) => {
        closeToast()
        reject(err)
      })
    }
  })
}

function openMenu(item: DiskItem) {
  menuCurrent.value = item
  menuShow.value = true
  menuOption.value = getMenuOptions(item.FileType)
  menuOption.value.push({ text: unixFormat('上传日期: YYYY.mm.dd', item.Created) })
  nextTick(() => {
    menuRef.value.toggle(true)
  })
}

function closeMenu() {
  menuValue.value = 0
  nextTick(() => {
    menuShow.value = false
  })
}

function indexOfCurrentItemsById(id: number) {
  for (let i = 0; i < currentItems.value.length; i++) {
    if (currentItems.value[i].ID === id)
      return i
  }
  return -1
}

async function changeMenu(value: number) {
  let x = null
  let index = -1
  let swap = null

  switch (value) {
    case 1:
      await ls(null, menuCurrent.value)
      return
    case 2:
      toClipboard.copy(`${location.href}&to=${menuCurrent.value.FileMd5}`)
      showSuccessToast('分享成功')
      return
    case 3:
      x = new window.XMLHttpRequest()
      x.open('GET', `${import.meta.env.VITE_APP_API_BASE_URL}/disk/download?to=${menuCurrent.value.FileMd5}`, true)
      x.responseType = 'blob'
      x.onload = () => {
        const url = window.URL.createObjectURL(x.response)
        const a = document.createElement('a')
        a.href = url
        a.target = '_blank'
        a.download = menuCurrent.value.FileName
        a.style.display = 'none'
        document.body.append(a)
        a.click()
        document.body.removeChild(a)
      }
      x.send()
      return
    case 4:
      toClipboard.copy(`${location.href}&to=${menuCurrent.value.FileMd5}`)
      showSuccessToast('复制成功')
      return
    case 5:
      index = indexOfCurrentItemsById(menuCurrent.value.ID)
      if (index >= 0 && index !== 0) {
        swap = currentItems.value[index - 1]
        currentItems.value[index - 1] = currentItems.value[index]
        currentItems.value[index] = swap
        await setCurrentItemsOrder()
        showSuccessToast('移动成功')
      }
      return
    case 6:
      index = indexOfCurrentItemsById(menuCurrent.value.ID)
      if (index >= 0 && index !== (currentItems.value.length - 1)) {
        swap = currentItems.value[index + 1]
        currentItems.value[index + 1] = currentItems.value[index]
        currentItems.value[index] = swap
        await setCurrentItemsOrder()
        showSuccessToast('移动成功')
      }
      return
    case 7:
      dialogForm.value.show = true
      dialogForm.value.title = '重命名'
      dialogForm.value.value = ''
      dialogForm.value.type = 2
      return
    case 8:
      showFailToast('暂不支持移动!')
      return
    case 9:
      await diskRm({ id: menuCurrent.value.ID })
      currentItems.value.splice(indexOfCurrentItemsById(menuCurrent.value.ID), 1)
      await initSurplus()
      await setCurrentItemsOrder()
      showSuccessToast('删除成功')
  }
}

function emptyDescription() {
  if (currentPath.value === '/public')
    return '文件夹为空'

  if (!userStore.isLogin())
    return '你无权查看'

  if (!currentAuth.value)
    return '你无权查看'

  return '文件夹为空'
}
</script>

<template>
  <Top :uid="uid" suffix="链盘" :value="topValue" @backup="backup">
    <template #right>
      <VanSpace v-if="userStore.isCurrent(uid)">
        <!--        <span class="cursor-pointer">剩余空间({{ surplus }}MB)</span> -->
        <span v-show="currentPath.length !== 0" class="cursor-pointer" @click="openAddDirectDialog">
          <VanIcon style="color: #409eff" class="cursor-pointer" name="plus" />
          <span style="color: #409eff">文件夹</span>
        </span>
        <span v-show="currentPath.length !== 0">
          <VanIcon style="color: #409eff" class="cursor-pointer" name="plus" />
          <VanUploader style="color: #409eff" :before-read="beforeUpload" accept="*">
            上传
          </VanUploader>
        </span>
      </VanSpace>
    </template>
  </Top>

  <VanDialog v-model:show="dialogForm.show" :title="dialogForm.title" show-cancel-button @confirm="conformDialog">
    <VanField v-model="dialogForm.value" placeholder="请输入文件夹名" />
  </VanDialog>

  <div class="bg-white py-20">
    <VanDropdownMenu v-show="menuShow" class="menuPos" :close-on-click-outside="false">
      <VanDropdownItem
        ref="menuRef"
        v-model="menuValue"
        :options="menuOption"
        @close="closeMenu"
        @closed="closeMenu"
        @change="changeMenu"
      />
    </VanDropdownMenu>
    <VanEmpty v-if="currentItems.length === 0" :description="emptyDescription()" />
    <VanCellGroup v-else>
      <VanCell v-for="item in currentItems" :key="`${item.ID}${item.FileName}`" @click="ls($event, item)">
        <template #icon>
          <component :is="GetFileIcon(item.FileType)" theme="outline" size="35" fill="#333" />
        </template>
        <template v-if="currentPath" #right-icon>
          <VanIcon class="iconCenter" name="ellipsis" @click="openMenu(item)" />
        </template>
        <template #title>
          <span class="ml-5 cursor-pointer">{{ item.FileName }}</span>
        </template>
      </VanCell>
    </VanCellGroup>
  </div>
</template>

<style scoped>

</style>
