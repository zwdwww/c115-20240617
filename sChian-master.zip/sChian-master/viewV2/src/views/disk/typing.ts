export interface DiskItem {
  ID: number
  Uid: string
  Parent: string
  FileName: string
  FileMd5: string
  FileByteSize: number
  FileType: string
  Created: number
  IsRoot?: boolean
  Path?: string
}
