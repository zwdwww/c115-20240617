<script setup lang="ts">
import { showConfirmDialog, showFailToast, showSuccessToast } from 'vant'
import { getManageID } from '@/utils/card'
import useUserStore from '@/stores/modules/user'
import { infoSetPassword, infoSetPhone, logoff, logout, sendInfoVerifyCode } from '@/api/auth'
import useHomeStore from '@/stores/modules/home'
import { diskSurplus } from '@/api/disk'
import { PhoneRegex } from '@/utils/utils'

definePage({
  name: 'my',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()
const homeStore = useHomeStore()
const router = useRouter()

const diskSurplusSize = ref<string>('')
const leaveMsgRadio = ref<string>(userStore.allowLeaveMsg.toString())
const timeoutId = ref<any>(0)
const wait60Seconds = ref<number>(0)

const alterDialog = ref<{
  show: boolean
  value: string
  title: string
  type: number
  verifyCode: string
}>({
  show: false,
  value: '',
  title: '',
  type: 0,
  verifyCode: '',
})

onMounted(() => {
  initSurplus()
})

const verifyCodeBtn = computed(() => {
  if (wait60Seconds.value <= 0)
    return '获取验证码'
  return `${wait60Seconds.value}秒后重新发送`
})

async function initSurplus() {
  const size = (await diskSurplus()).data || 0
  diskSurplusSize.value = (size / 1024 / 1024).toFixed(2)
}

async function userLogout() {
  await logout()
  userStore.reset()
  homeStore.reset()
  showSuccessToast('已退出登录')
  await router.push('/')
}

function logoffUid() {
  showConfirmDialog({
    title: '提示',
    message: '请确认是否注销ID? 注销后数据将无法找回',
  }).then(() => {
    logoff().then(() => {
      showSuccessToast('已注销')
      userStore.reset()
      homeStore.reset()
      router.push('/')
    })
  })
}

async function changeLeaveMsg(v: string) {
  await userStore.setAllowLeaveMsg(Number.parseInt(v) || 0)
  leaveMsgRadio.value = userStore.allowLeaveMsg.toString()
  showSuccessToast('设置成功')
}

function openAlterPhoneDialog() {
  alterDialog.value.show = true
  alterDialog.value.title = '变更手机号'
  alterDialog.value.type = 1
  alterDialog.value.value = ''
}

function openAlterPasswordDialog() {
  alterDialog.value.show = true
  alterDialog.value.title = '修改密码'
  alterDialog.value.type = 2
  alterDialog.value.value = ''
}

async function confirmDialog() {
  if (alterDialog.value.verifyCode === '') {
    showFailToast('请获取验证码')
    return
  }
  switch (alterDialog.value.type) {
    case 1:
      if (alterDialog.value.value === '' || !PhoneRegex.test(alterDialog.value.value)) {
        showFailToast('手机号异常')
        return
      }
      await infoSetPhone({ phone: alterDialog.value.value, verifyCode: alterDialog.value.verifyCode })
      wait60Seconds.value = 0
      userStore.setPhone(alterDialog.value.value)
      showSuccessToast('手机号修改成功')
      return
    case 2:
      if (alterDialog.value.value === '') {
        showFailToast('请输入新密码')
        return
      }
      if (alterDialog.value.value.length < 8) {
        showFailToast('密码不能少于8位')
        return
      }
      await infoSetPassword({ password: alterDialog.value.value, verifyCode: alterDialog.value.verifyCode })
      wait60Seconds.value = 0
      showSuccessToast('密码修改成功')
  }
}

function countdown() {
  wait60Seconds.value--
  if (wait60Seconds.value <= 0)
    return
  timeoutId.value = setTimeout(countdown, 1000)
}

async function sendVerifyCode() {
  if (wait60Seconds.value !== 0) {
    showFailToast('发送频繁,请等待')
    return
  }
  await sendInfoVerifyCode()
  wait60Seconds.value = 60
  countdown()
}
</script>

<template>
  <VanDialog v-model:show="alterDialog.show" :title="alterDialog.title" show-cancel-button @confirm="confirmDialog">
    <VanField v-if="alterDialog.type === 1" v-model="alterDialog.value" placeholder="请输入新的手机号" />
    <VanField v-else-if="alterDialog.type === 2" v-model="alterDialog.value" placeholder="请输入新的密码" />
    <VanField v-model="alterDialog.verifyCode" placeholder="请输入验证码" center clearable>
      <template #button>
        <VanButton size="small" type="primary" @click="sendVerifyCode">
          {{ verifyCodeBtn }}
        </VanButton>
      </template>
    </VanField>
  </VanDialog>

  <VanCellGroup>
    <VanCell size="large">
      <template #title>
        <div style="text-align: center">
          <span>我的名片 <Link type="user" :value="userStore.username" /></span>
        </div>
      </template>
    </VanCell>
  </VanCellGroup>
  <VanCellGroup title="个人信息">
    <VanCell class="hover:text-blue" icon="arrow-down" title="修改名片" to="/profile" is-link />
    <VanCell class="hover:text-blue" icon="points" title="修改网盘" :to="`/disk?id=${userStore.username}&path=/public`" is-link />
    <VanCell class="hover:text-blue" icon="comment-o" title="修改短文" :to="`/essay?id=${userStore.username}`" is-link />
    <VanCell class="hover:text-blue" icon="flag-o" title="修改导航" :to="`/favorites?id=${userStore.username}`" is-link />
    <VanCell class="hover:text-blue" icon="star-o" title="修改收藏" to="/star" is-link />
    <VanCell class="hover:text-blue" icon="chat-o" title="修改留言" is-link :to="`/leave-message?id=${userStore.username}`" />
    <VanCell class="hover:text-blue" icon="label-o" title="修改备注" to="/notes" is-link />
  </VanCellGroup>
  <VanCellGroup title="通用">
    <VanCell class="hover:text-blue" icon="chat-o" title="管理我给他人的留言" to="/my-leave-message" is-link />
    <VanCell class="hover:text-blue" is-link icon="chat-o">
      <template #title>
        <div class="flex">
          <div class="mr-15">
            管理留言框
          </div>
          <VanRadioGroup v-model="leaveMsgRadio" direction="horizontal" @change="changeLeaveMsg">
            <VanRadio class="text-4xl" icon-size="15" name="1">
              禁止留言
            </VanRadio>
            <VanRadio class="text-4xl" icon-size="15" name="0">
              允许留言
            </VanRadio>
          </VanRadioGroup>
        </div>
      </template>
    </VanCell>
    <VanCell class="hover:text-blue" icon="points" is-link>
      <template #title>
        购买网盘空间<span class="ml-10 text-4xl color-red">(剩余{{ diskSurplusSize }}MB)</span>
      </template>
    </VanCell>
  </VanCellGroup>
  <VanCellGroup title="账号">
    <VanCell class="hover:text-blue" icon="question-o" title="修改密码" is-link @click="openAlterPasswordDialog" />
    <VanCell class="hover:text-blue" icon="phone-circle-o" title="变更注册手机号" is-link @click="openAlterPhoneDialog" />
    <VanCell class="hover:text-blue" icon="exchange" title="切换账号" to="/login" is-link />
    <VanCell class="hover:text-blue" icon="delete-o" title="注销此id" is-link @click="logoffUid" />
    <VanCell class="hover:text-blue" icon="wap-nav" title="退出登录" is-link @click="userLogout" />
  </VanCellGroup>
  <VanCellGroup title="客服">
    <VanCell icon="manager">
      <template #title>
        <span>联系客服 <Link type="user" :value="getManageID()" /></span>
      </template>
    </VanCell>
  </VanCellGroup>
</template>

<style scoped>

</style>
