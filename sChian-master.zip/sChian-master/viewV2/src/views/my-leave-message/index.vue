<script setup lang="ts">
import { showSuccessToast } from 'vant'
import type { MsgArgs, MsgItem } from '@/views/leave-message/typing'
import useUserStore from '@/stores/modules/user'
import { unixFormat } from '@/utils/date'
import { leaveMsgDelMy, leaveMsgMyAll } from '@/api/leave_msg'

definePage({
  name: 'my-leave-message',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()

const uid = ref<string>(userStore.username)
const msgItems = ref<Array<MsgItem>>([])
const args = ref<MsgArgs>({ page: 1, limit: 20 })
const count = ref<number>(0)

onMounted(() => {
  initMsgItems()
})

async function initMsgItems() {
  const resp = (await leaveMsgMyAll(args.value)).data
  count.value = resp.count || 0
  msgItems.value = resp.items || []
}

async function delMy(id: number) {
  await leaveMsgDelMy({ id })
  await initMsgItems()
  showSuccessToast('删除成功')
}
</script>

<template>
  <Top :uid="uid" suffix="给他人的留言" />
  <div class="bg-white px-15 py-10 text-4xl text-gray-500 leading-10">
    <VanRow v-for="(item, i) in msgItems" :key="i" class="pb-15" :gutter="[0, 5]">
      <VanCol span="24">
        <Link :value="item.Right" type="user" />
      </VanCol>
      <VanCol span="24">
        <VanTextEllipsis rows="3" :content="item.Content" />
      </VanCol>
      <VanCol span="24">
        <VanSpace>
          <span class="text-gray-400">{{ unixFormat('YYYY.mm.dd', item.Updated) }}</span>
          <span class="cursor-pointer color-red" @click="delMy(item.ID)">删除</span>
        </VanSpace>
      </VanCol>
    </VanRow>
    <VanPagination
      v-show="count > 20"
      v-model="args.page"
      items-per-page="20"
      :total-items="count"
      show-page-size="3"
      force-ellipses
      @change="initMsgItems"
    />
  </div>
</template>

<style scoped>

</style>
