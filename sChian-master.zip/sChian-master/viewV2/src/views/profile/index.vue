<script setup lang="ts">
import { showSuccessToast } from 'vant'
import useUserStore from '@/stores/modules/user'
import type { CardBody } from '@/components/card/typing'
import { cardCurrent, cardUpdate } from '@/api/card'
import { getHttpCard } from '@/utils/card'
import type { ProfileDialogForm } from '@/views/profile/typing'
import { MyArea } from '@/utils/area'

definePage({
  name: 'profile',
  meta: {
    level: 2,
  },
})

const userStore = useUserStore()

const contactOptions = [
  { text: 'QQ', value: 'QQ' },
  { text: 'Mail', value: 'Mail' },
]

const form = ref<CardBody>({} as CardBody)
const dialogForm = ref<ProfileDialogForm>({
  type: 0,
  show: false,
  showContact: false,
  showArea: false,
  title: '修改地址',
  contact: ['', ''],
  keyword: ['', '', ''],
  address: ['北京', '地址1', '地址2', '地址3', '地址4'],
})

onMounted(() => {
  syncCurrentCard()
})

async function syncCurrentCard() {
  const resp: CardBody = (await cardCurrent()).data.card
  resp.Keywords = resp.Keywords.replaceAll('$$', '/')
  resp.Contact = resp.Contact.replaceAll('$', '/')
  form.value = resp
}

function areaConfirm(values: any) {
  dialogForm.value.address[0] = values.selectedOptions[0].text
  dialogForm.value.showArea = false
}

function contactConfirm(values: any) {
  dialogForm.value.contact[0] = values.selectedOptions[0].text
  dialogForm.value.showContact = false
}

function confirmDialog() {
  switch (dialogForm.value.type) {
    case 1:
      form.value.Address = dialogForm.value.address.join('>')
      return
    case 2:
      form.value.Keywords = dialogForm.value.keyword.join('/')
      return
    case 3:
      form.value.Contact = dialogForm.value.contact.join('/')
  }
  dialogForm.value.show = false
}

function openAddressDialog() {
  dialogForm.value.type = 1
  dialogForm.value.show = true
  dialogForm.value.title = '修改地址'
  dialogForm.value.address = form.value.Address.split('>')
}

function openKeywordDialog() {
  dialogForm.value.type = 2
  dialogForm.value.show = true
  dialogForm.value.title = '修改搜索词'
  dialogForm.value.keyword = form.value.Keywords.split('/')
}

function openContactDialog() {
  dialogForm.value.type = 3
  dialogForm.value.show = true
  dialogForm.value.title = '修改联系方式'
  if (form.value.Contact)
    dialogForm.value.contact = form.value.Contact.split('/')
}

async function updateData() {
  const tmpForm: any = { ...form.value }
  tmpForm.Address = tmpForm.Address.split('>')
  tmpForm.Keywords = tmpForm.Keywords.split('/')
  tmpForm.Contact = tmpForm.Contact.split('/')
  await cardUpdate(tmpForm)
  showSuccessToast('修改完成')
  location.href = getHttpCard(userStore.username)
}
</script>

<template>
  <VanDialog v-model:show="dialogForm.show" :title="dialogForm.title" show-cancel-button @confirm="confirmDialog">
    <VanCellGroup v-if="dialogForm.type === 1">
      <VanField v-model="dialogForm.address[0]" label="省" is-link readonly @click="dialogForm.showArea = true" />
      <VanField v-model="dialogForm.address[1]" label="市/县" />
      <VanField v-model="dialogForm.address[2]" label="路/乡镇" />
      <VanField v-model="dialogForm.address[3]" label="公交/站村" />
      <VanField v-model="dialogForm.address[4]" label="小区/小组" />
    </VanCellGroup>
    <VanCellGroup v-if="dialogForm.type === 2">
      <VanField v-model="dialogForm.keyword[0]" label="搜词1" />
      <VanField v-model="dialogForm.keyword[1]" label="搜词2" />
      <VanField v-model="dialogForm.keyword[2]" label="搜词3" />
    </VanCellGroup>
    <VanCellGroup v-if="dialogForm.type === 3">
      <VanField v-model="dialogForm.contact[0]" placeholder="请选择联系方式" label="联系方式" is-link readonly @click="dialogForm.showContact = true" />
      <VanField v-model="dialogForm.contact[1]" label="账号" placeholder="请输入账号" />
    </VanCellGroup>
  </VanDialog>

  <VanPopup v-model:show="dialogForm.showArea" position="bottom">
    <VanArea :columns-num="1" :area-list="MyArea" @confirm="areaConfirm" @cancel="dialogForm.showArea = false" />
  </VanPopup>

  <VanPopup v-model:show="dialogForm.showContact" position="bottom">
    <VanPicker title="联系方式" :columns="contactOptions" @cancel="dialogForm.showContact = false" @confirm="contactConfirm" />
  </VanPopup>

  <div class="py-35">
    <VanCellGroup inset>
      <VanCell size="large">
        <template #title>
          <div style="text-align: center">
            <span>ID: <Link type="user" :value="userStore.username" /></span>
          </div>
        </template>
      </VanCell>
      <VanField v-model="form.Title" label-align="center" autosize maxlength="18" type="textarea" show-word-limit placeholder="单位/个人" label="名称" />
      <VanField v-model="form.Contact" label-align="center" label="通讯" placeholder="联系方式/QQ/Mail" readonly @click="openContactDialog" />
      <VanField v-model="form.Address" label-align="center" label="地址" readonly @click="openAddressDialog" />
      <VanField v-model="form.Keywords" label-align="center" label="搜词" readonly @click="openKeywordDialog" />
      <VanField>
        <template #button>
          <VanButton type="success" size="small" @click="updateData">
            修改完成
          </VanButton>
        </template>
      </VanField>
    </VanCellGroup>
  </div>
</template>

<style scoped>
</style>
