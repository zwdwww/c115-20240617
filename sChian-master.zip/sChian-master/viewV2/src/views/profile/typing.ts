export interface ProfileDialogForm {
  type?: number
  show: boolean
  title: string
  showArea: boolean
  contact: Array<string>
  keyword: Array<string>
  address: Array<string>
  showContact: boolean
}
