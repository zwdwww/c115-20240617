import prose from './modules/prose.mock'

export default {
  ...prose,
}
