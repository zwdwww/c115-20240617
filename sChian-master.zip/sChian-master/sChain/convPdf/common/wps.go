package common

import (
	"github.com/go-ole/go-ole"
	"github.com/go-ole/go-ole/oleutil"
)

// WpsWord2pdf 使用Wps转换PDF
func WpsWord2pdf(fileName string, pdfPath string) {
	_ = ole.CoInitialize(0)
	defer ole.CoUninitialize()
	unknown, _ := oleutil.CreateObject("KWPS.Application")
	defer unknown.Release()
	word, _ := unknown.QueryInterface(ole.IID_IDispatch)
	defer word.Release()
	_, _ = oleutil.PutProperty(word, "Visible", false)
	documents := oleutil.MustGetProperty(word, "Documents").ToIDispatch()
	defer documents.Release()
	document := oleutil.MustCallMethod(documents, "Open", fileName).ToIDispatch()
	defer document.Release()
	oleutil.MustCallMethod(document, "SaveAs2", pdfPath, 17).ToIDispatch()
	_, _ = oleutil.CallMethod(document, "Close")
	_, _ = oleutil.CallMethod(word, "Quit")
}
