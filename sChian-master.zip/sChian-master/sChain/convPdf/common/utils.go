package common

import (
	"crypto/md5"
	"fmt"
	"github.com/bwmarrin/snowflake"
	"math/rand"
	"os"
	"strconv"
	"time"
)

var (
	TimeFormat     = "2006-01-02 15:04:05"
	TimeFormatDay2 = "2006-01-02"
)

// PathExists 路径是否存在
func PathExists(path string) (bool, error) {
	fi, err := os.Stat(path)
	if err == nil {
		if fi.IsDir() {
			return true, nil
		}
		return false, fmt.Errorf("存在同名文件")
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

// TimestampSec 秒
func TimestampSec() int64 {
	return time.Now().Unix()
}

// TimestampNaSec 纳秒
func TimestampNaSec() int64 {
	return time.Now().UnixNano()
}

// DefaultInt64 字符转为int64
func DefaultInt64(v string) int64 {
	num, err := strconv.ParseInt(v, 10, 64)
	if err != nil {
		return 0
	}
	return num
}

var sf *snowflake.Node

// InitSnow 初始化雪花ID
func InitSnow(n int64) error {
	node, err := snowflake.NewNode(n)
	if err != nil {
		return err
	}
	sf = node
	return nil
}

// SnowStringID 雪花ID
func SnowStringID() string {
	return sf.Generate().String()
}

// Md5 md5计算
func Md5(data []byte) string {
	hash := md5.New()
	_, err := hash.Write(data)
	if err != nil {
		return ""
	}
	sum := hash.Sum(nil)
	return fmt.Sprintf("%x", sum)
}

// RandVerifyCode  随机生成验证码
func RandVerifyCode() string {
	myRand := rand.NewSource(TimestampNaSec())
	num := fmt.Sprintf("%v", myRand.Int63())
	// 小于6位往后补零(一般不太可能)
	if len(num) < 6 {
		addZero := 6 - len(num)
		for i := 0; i < addZero; i++ {
			num += "0"
		}
		return num
	} else {
		return num[:6]
	}
}
