package common

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"strings"
	"sync"
)

var diskConvertLock sync.Mutex
var PdfConvertApi = Disk{
	queue: make(chan string, 128),
}

type Disk struct {
	queue chan string
	run   bool
}

func (d *Disk) _execCmd(cmd *exec.Cmd) (string, error) {
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return "", fmt.Errorf("convert pdf StdoutPipe err=%v", err)
	}

	defer func() {
		_ = stdout.Close()
	}()

	if err = cmd.Start(); err != nil {
		return "", fmt.Errorf("convert pdf start err=%v", err)
	}

	output, err := io.ReadAll(stdout)
	if err != nil {
		return "", fmt.Errorf("convert pdf io.ReadAll err=%v", err)
	}
	return string(output), nil
}

func (d *Disk) _convert() {
	diskConvertLock.Lock()
	defer diskConvertLock.Unlock()

	if d.run {
		return
	}

	d.run = true

	Loggers.Debugf("run convert pdf process.")

	for {
		filename := <-d.queue
		Loggers.Infof("pdf convert queue: length=%v", len(d.queue))
		if Config.Soffice == "" {
			Loggers.Errorf("Soffice 未配置")
			continue
		}

		Loggers.Debugf("start convert pdf: %v", filename)
		arr := strings.Split(filename, ".")

		WpsWord2pdf(
			fmt.Sprintf("%v/%v.docx", Config.FileSavePath, arr[0]),
			fmt.Sprintf("%v/%v.pdf", Config.FileSavePath, arr[0]))

		_, err := os.Stat(fmt.Sprintf("%v/%v.pdf", Config.FileSavePath, arr[0]))
		if os.IsNotExist(err) {
			Loggers.Errorf("convert fail: %v", err)
			continue
		}
		Loggers.Debugf("convert output: %v", arr[0])
	}
}

// ConvertPdf 生成pdf
func (d *Disk) ConvertPdf(filename string) {
	if !d.run {
		go d._convert()
	}
	d.queue <- filename
}
