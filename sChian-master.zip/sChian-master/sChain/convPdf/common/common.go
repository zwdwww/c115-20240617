package common

import (
	"go.uber.org/zap"
	"gopkg.in/yaml.v3"
	"io/ioutil"
)

var (
	Config  *BaseConf
	Logger  *zap.Logger
	Loggers *zap.SugaredLogger
)

// 加载配置
func loadConfig(path string) {
	config := BaseConf{}
	data, err := ioutil.ReadFile(path)
	if err != nil {
		panic(err)
	}
	if err = yaml.Unmarshal(data, &config); err != nil {
		panic(err)
	}
	Config = &config
}

// InitConfig 初始化配置
func InitConfig(path string) {
	loadConfig(path)
	InitLogger()
}
