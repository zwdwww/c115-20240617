package main

import (
	"convPdf/common"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"
)

func readJson(req *http.Request, args interface{}) error {
	body, err := io.ReadAll(req.Body)
	if err != nil {
		return err
	}
	return json.Unmarshal(body, args)
}

func join(parent, filename string) string {
	return fmt.Sprintf("%v/%v", parent, filename)
}

// 接收Docx文档,并转换成PDF
func acceptDocx(res http.ResponseWriter, req *http.Request) {
	common.Loggers.Infof("req path=%v", req.URL.Path)

	var args struct {
		FileMd5  string
		FileBody []byte
	}
	if err := readJson(req, &args); err != nil {
		_, _ = io.WriteString(res, err.Error())
		return
	}

	filename := args.FileMd5 + ".docx"
	_, err := os.Stat(join(common.Config.FileSavePath, filename))
	if err == nil {
		_, _ = io.WriteString(res, "success")
		return
	}

	if err = os.WriteFile(join(common.Config.FileSavePath, filename), args.FileBody, 0666); err != nil {
		common.Loggers.Errorf("WriteFile: %v", err)
		_, _ = io.WriteString(res, err.Error())
		return
	}
	common.PdfConvertApi.ConvertPdf(filename)
	_, _ = io.WriteString(res, "success")
}

// 检查PDF文件是否转换完成
func checkPdf(res http.ResponseWriter, req *http.Request) {
	common.Loggers.Infof("req path=%v", req.URL.Path)
	var args struct {
		FileMd5 string
	}
	if err := readJson(req, &args); err != nil {
		_, _ = io.WriteString(res, err.Error())
		return
	}

	filename := args.FileMd5 + ".pdf"
	_, err := os.Stat(join(common.Config.FileSavePath, filename))
	if err == nil {
		_, _ = io.WriteString(res, "success")
	} else {
		_, _ = io.WriteString(res, "fail")
	}
}

// PDF下载
func downloadPdf(res http.ResponseWriter, req *http.Request) {
	common.Loggers.Infof("req path=%v", req.URL.Path)
	var args struct {
		FileMd5 string
	}
	if err := readJson(req, &args); err != nil {
		_, _ = io.WriteString(res, err.Error())
		return
	}
	filename := args.FileMd5 + ".pdf"
	body, _ := os.ReadFile(join(common.Config.FileSavePath, filename))
	_, _ = res.Write(body)
}

// 删除PDF文件
func removePdf(res http.ResponseWriter, req *http.Request) {
	common.Loggers.Infof("req path=%v", req.URL.Path)
	var args struct {
		FileMd5 string
	}
	if err := readJson(req, &args); err != nil {
		_, _ = io.WriteString(res, err.Error())
		return
	}
	_ = os.Remove(join(common.Config.FileSavePath, args.FileMd5+".docx"))
	_ = os.Remove(join(common.Config.FileSavePath, args.FileMd5+".pdf"))
	_, _ = io.WriteString(res, "success")
}

// pdf恢复转换检查
func pdfRecoverCheck() {
	entries, _ := os.ReadDir(common.Config.FileSavePath)
	count := map[string]int{}
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		arr := strings.Split(entry.Name(), ".")
		count[arr[0]]++
	}
	for k, v := range count {
		if v == 1 {
			common.Loggers.Debugf("重新转换: %v", k)
			common.PdfConvertApi.ConvertPdf(k + ".docx")
		}
	}
}

// 删除过期的文件
func removeExpiredFile() {
	expiredTime := int64(24 * 3600)
	for {
		entries, _ := os.ReadDir(common.Config.FileSavePath)
		var book []string
		now := common.TimestampSec()
		for _, entry := range entries {
			if entry.IsDir() {
				continue
			}
			info, _ := entry.Info()
			if !strings.HasSuffix(info.Name(), ".docx") {
				continue
			}
			arr := strings.Split(info.Name(), ".")
			if now-info.ModTime().Unix() > expiredTime {
				book = append(book, arr[0])
			}
		}

		for _, md5 := range book {
			_ = os.Remove(fmt.Sprintf("%v/%v.docx", common.Config.FileSavePath, md5))
			_ = os.Remove(fmt.Sprintf("%v/%v.pdf", common.Config.FileSavePath, md5))
			common.Loggers.Debugf("remove file: %v", md5)
		}
		time.Sleep(time.Hour)
	}
}

func main() {
	common.InitConfig("config/config.yaml")
	_, err := os.Stat(common.Config.FileSavePath)
	if os.IsNotExist(err) {
		_ = os.Mkdir(common.Config.FileSavePath, 0666)
	}
	pdfRecoverCheck()
	go removeExpiredFile()
	http.HandleFunc("/source/acceptDocx", acceptDocx)
	http.HandleFunc("/source/checkPdf", checkPdf)
	http.HandleFunc("/source/downloadPdf", downloadPdf)
	http.HandleFunc("/source/removePdf", removePdf)
	common.Loggers.Infof("ListenAndServe start,:%v", common.Config.Port)
	if err := http.ListenAndServe(":"+common.Config.Port, nil); err != nil {
		common.Loggers.Errorf("server shutdown: %v", err)
	}
}
