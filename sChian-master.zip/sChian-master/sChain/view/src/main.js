import Vue from 'vue'
import App from './App'
import store from './store'
import router from './router'
import VueClipboard from 'vue-clipboard2'

import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import Clickoutside from 'element-ui/src/utils/clickoutside'
import '@/styles/element.css'
import JwChat from 'jwchat'

import './permission' // permission control

Vue.use(Element)
Vue.use(JwChat)
Vue.use(VueClipboard)
Vue.directive('clickoutside', Clickoutside)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
