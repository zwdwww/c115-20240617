import Vue from 'vue'
import Router from 'vue-router'
import Layout from '../views/layout/Layout'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      component: Layout,
      redirect: '/home',
      children: [
        {
          path: 'login',
          name: 'Login',
          component: () => import('../views/Login.vue'),
          meta: {noCache: true}
        },
        {
          path: 'register',
          name: 'Register',
          component: () => import('../views/Register.vue'),
          meta: { noCache: true }
        },
        {
          path: 'home',
          name: 'Home',
          component: () => import('../views/Home'),
          meta: {name: '推荐'}
        },
        {
          path: 'star',
          name: 'Star',
          component: () => import('../views/Star'),
          meta: {name: '关注', noCache: true}
        },
        {
          path: 'rank',
          name: 'Rank',
          component: () => import('../views/Rank'),
          meta: {name: '排行'}
        },
        {
          path: 'favorites',
          name: 'Favorites',
          component: () => import('../views/Favorites'),
          meta: { name: '收藏夹', noCache: true }
        },
        {
          path: 'leave-message',
          name: 'LeaveMessage',
          component: () => import('../views/LeaveMessage'),
          meta: { name: '留言板', noCache: true }
        },
        {
          path: 'essay',
          name: 'Essay',
          component: () => import('../views/Essay'),
          meta: { name: '短文', noCache: true }
        },
        {
          path: 'disk',
          name: 'Disk',
          component: () => import('../views/Disk'),
          meta: { name: '链盘', noCache: true }
        },
        {
          path: 'database',
          name: 'Database',
          component: () => import('../views/Database'),
          meta: { name: '数据库', noCache: true }
        },
        {
          path: 'address',
          name: 'Address',
          component: () => import('../views/Address'),
          meta: { name: '地址', noCache: true }
        },
        {
          path: 'keyword',
          name: 'Keyword',
          component: () => import('../views/Keyword'),
          meta: { name: '搜词', noCache: true }
        }
      ]
    },
    {
      path: '/profile',
      component: Layout,
      children: [
        {
          path: '/',
          name: 'Profile',
          component: () => import('../views/profile'),
          meta: {name: '我的'}
        },
        {
          path: 'edit',
          name: 'Edit',
          component: () => import('../views/profile/Edit'),
          meta: {name: '修改名片'}
        },
        {
          path: 'reset',
          name: 'ResetPassword',
          component: () => import('../views/profile/ResetPassword.vue')
        }
      ]
    },
    {
      path: '/chat',
      component: Layout,
      children: [
        {
          path: '/',
          name: 'Chat',
          component: () => import('../views/chat'),
          meta: { name: '信息', noCache: true }
        },
        {
          path: 'msg',
          name: 'Msg',
          component: () => import('../views/chat/Msg'),
          meta: { name: '聊天', noCache: true }
        }
      ]
    }
  ]
})
