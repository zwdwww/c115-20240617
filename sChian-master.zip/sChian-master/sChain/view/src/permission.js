import router from './router'
import store from './store'
import {getToken} from '@/utils/auth'

const whiteList = [
  '/login', '/register', '/home', '/rank', '/favorites', '/leave-message',
  '/essay', '/disk', '/database', '/address',
  '/keyword'
]

router.beforeEach(async (to, from, next) => {
  const hasToken = getToken()
  if (hasToken) {
    if (store.getters.username.length === 0) {
      await store.dispatch('user/getInfo')
    }
    next()
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      next(`/login?redirect=${to.path}`)
    }
  }
})
