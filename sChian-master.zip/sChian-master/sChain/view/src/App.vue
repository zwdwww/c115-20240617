<template>
  <div id="app" v-cloak>
      <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}

html {
  font-size: 75px;
}

@media only screen and (max-width: 600px) {
  html {
    font-size: 60px;
  }
}

@media only screen and (max-width: 540px){
  html {
    font-size: 54px;
  }
}

@media only screen and (max-width: 480px){
  html {
    font-size: 50px;
  }
}

@media only screen and (max-width: 450px) {
  html{
    font-size: 43px;
  }
}

@media only screen and (max-width: 420px) {
  html{
    font-size: 41px;
  }
}

@media only screen and (max-width: 410px) {
  html{
    font-size: 40px;
  }
}

@media only screen and (max-width: 390px){
  html {
    font-size: 39px;
  }
}

@media only screen and (max-width: 375px){
  html {
    font-size: 38px;
  }
}

@media only screen and (max-width: 365px){
  html {
    font-size: 36px;
  }
}

@media only screen and (max-width: 320px) {
  html{
    font-size: 28px;
  }
}

body {
    background: #f4f4f4;
    color: #666;
    font-size: .12rem;
    margin: auto;
    max-width: 768px;
}

body,html {
  width: 100%;
  height: 100%;
}

#app {
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
