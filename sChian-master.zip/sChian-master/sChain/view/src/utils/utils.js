// 是否是移动端设备
export function isPhone () {
  if (/Mobi|Android|iPhone/i.test(navigator.userAgent)) {
    return true
  }
  return window.screen.width <= 750
}
