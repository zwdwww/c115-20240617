import Cookies from 'js-cookie'

const TokenKey = 'Token'

export function getToken () {
  return Cookies.get(TokenKey)
}

export function setToken (token) {
  const domain = process.env.VUE_CARD_DOMAIN || ''
  if (domain === '' || domain === 'localhost') {
    return Cookies.set(TokenKey, token)
  }
  return Cookies.set(TokenKey, token, { domain: process.env.VUE_CARD_DOMAIN })
}

export function removeToken () {
  const domain = process.env.VUE_CARD_DOMAIN || ''
  if (domain === '' || domain === 'localhost') {
    return Cookies.remove(TokenKey)
  }
  return Cookies.remove(TokenKey, { domain: process.env.VUE_CARD_DOMAIN })
}
