export class Node {
  constructor (id, path, name, type, md5, init = false, desc = '') {
    this.id = id
    this.path = path
    this.name = name
    this.type = type
    this.desc = desc
    this.md5 = md5

    this.parent = null
    this.showOption = false
    this.img = this.initImg()
    this.init = init
    this.children = []
  }

  initImg () {
    if (this.type === 'docx') {
      return 'docx'
    }
    if (this.type === 'dir') {
      return 'dir'
    }
    return 'unknown'
  }

  _handleAddNode (node) {
    node.parent = this
    if (this.path === '/') {
      node.path = `${this.path}${node.path}`
      node.showOption = false
    } else {
      node.path = `${this.path}/${node.path}`
      node.showOption = true
    }
    return node
  }

  add (node) {
    this.children.push(this._handleAddNode(node))
  }

  addFirst (node) {
    const tmp = [this._handleAddNode(node)]
    this.children = tmp.concat(this.children)
  }

  remove (id) {
    const tmp = []
    for (const child of this.children) {
      if (child.id === id) {
        continue
      }
      tmp.push(child)
    }
    this.children = tmp
  }

  reset () {
    this.init = false
    this.children = []
  }

  // 获取所有字节点的ID
  getChildrenId () {
    const tmp = []
    for (const child of this.children) {
      tmp.push(child.id)
    }
    return tmp
  }

  // 检查是否有同名的文件夹
  checkDirName (name) {
    for (const child of this.children) {
      if (child.name === name) {
        return true
      }
    }
    return false
  }
}

export class Tree {
  constructor () {
    this.root = new Node(0, '/', '/', 'dir', '', true)
  }

  _buildElementTree (list, node) {
    if (node.type !== 'dir') {
      return
    }
    const temp = {
      label: node.name,
      path: node.path,
      node: node,
      children: []
    }
    list.push(temp)
    for (const child of node.children) {
      this._buildElementTree(temp.children, child)
    }
  }

  elementTree () {
    const tree = []
    for (const child of this.root.children) {
      this._buildElementTree(tree, child)
    }
    return tree
  }
}
