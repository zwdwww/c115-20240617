// 手机号验证
export function validatePhone (rule, value, callback) {
  if (value === '') {
    callback(new Error('请输入手机号码'))
    return
  }
  if (value.length !== 11) {
    callback(new Error('手机号码错误'))
    return
  }
  if (!(/^1[3456789]\d{9}$/.test(value))) {
    callback(new Error('手机号码有误,请修改'))
    return
  }
  callback()
}

export function validateNotPhone (rule, value, callback) {
  if (!(/^1[3456789]\d{9}$/.test(value))) {
    callback()
    return
  }
  callback(new Error('其他数字ID不能为手机号'))
}
