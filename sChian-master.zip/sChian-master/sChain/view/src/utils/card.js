// 名片域名

export function getDomain () {
  return process.env.VUE_CARD_DOMAIN
}

// 名片前缀协议: http or https
export function getPrefix () {
  return process.env.VUE_CARD_PREFIX
}

// 拼接[名片ID+域名]
export function getCard (id) {
  return `${id.toString()}.${getDomain()}`
}

// 拼接[协议 + 名片ID + 域名]
export function getHttpCard (id) {
  return `${getPrefix()}${id}.${getDomain()}`
}

// 获取管理员名片ID
export function getManageID () {
  return process.env.VUE_CARD_MANAGE
}

// 获取管理员名片
export function getManageCard () {
  return getCard(getManageID())
}

// 获取带http的管理员名片
export function getManageHttpCard () {
  return getHttpCard(getManageID())
}

// 重域名中取出真实ID
export function getCardByHost (host) {
  if (!(host)) {
    return ''
  }
  host = host.replace('www.', '')
  if (host === process.env.VUE_CARD_DOMAIN) {
    return ''
  }
  const item = host.split('.')
  if (item.length === 1) {
    return ''
  } else {
    return item[0]
  }
}

const hostPattern = /([a-zA-Z0-9-]+\.115\.cn)/g
const urlPattern = /(https?:\/\/|www\.)[a-zA-Z_0-9\-@]+(\.\w[a-zA-Z_0-9\-:]+)+(\/[()~#&\-=?+%/.\w]+)?/g

function getHref (content) {
  if (!content) {
    return ''
  }
  content = content.replace(urlPattern, (match) => {
    const urlHttp = match.indexOf('http://') && match.indexOf('https://')
    if (urlHttp === -1 && match.endsWith('115.cn')) {
      const host = match.replace('www.', '')
      return `<a style="color: #20a2aa;" href="http://${host}">${host}</a>`
    }
    const href = urlHttp === -1 ? `https://${match}` : match
    return `<a style="color: #20a2aa;" href="${href}">${href}</a>`
  })
  return content
}

// 替换名片短文内容,将链接标识出来
export function replaceCardContent (content) {
  if (typeof content !== 'string') {
    return content
  }
  content = content.replace(hostPattern, `www.$1`)
  return getHref(content)
}
