<template>
  <div class="essay">
    <OutLine>
        <span slot="left">
          <my-link style="color: #409eff" :open="getHttpCard(id)">{{ getCard(id) }}</my-link>的短文
        </span>
        <div slot="right" class="outlineRight">
          <span class="el-icon-plus" @click="dialogVisible=true" v-show="isCurrent">
            新增短文
          </span>
        </div>
    </OutLine>

    <EmptyContent content='暂无短文内容' v-if="list.length === 0" />
    <div style="margin-top: .2rem" v-else>
      <div class="essayBody" :key="item.ID" v-for="item in list">
        <div class="essayCnt">{{ item.Essay }}</div>
        <div class="essayOptionBody">
          <div style="width: 25%" class="essayOption" v-show="isCurrent">
            <el-radio v-model="item.Top" :label="1" @input="topping(item.ID)">置顶</el-radio>
          </div>
          <div class="essayOption" @click="openEdit(item)"  v-show="isCurrent">修改</div>
          <div class="essayOption" @click="delEssay(item)"  v-show="isCurrent">删除</div>
          <div class="essayOption" @click="copyEssay(item)">复制</div>
          <div style="font-size: .16rem;width: 25%" class="essayOption">
            {{ unixFormat('YYYY.mm.dd', item.Updated) }}
          </div>
        </div>
      </div>
    </div>

    <el-dialog
      :title="dialogVisibleEdit?'修改短文':'添加短文'"
      :visible.sync="dialogVisible"
      :before-close="handleClose"
      width="8rem">
      <el-input ref="essay" type="textarea" :rows="7" v-model="form.essay"></el-input>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="upsertEssay">{{ dialogVisibleEdit?'修 改': '添 加' }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getCard, getHttpCard} from '@/utils/card'
import {essayAdd, essayDel, essayList, essayTopping, essayUpdate} from '@/api/essay'
import {unixFormat} from '@/utils/date'

export default {
  name: 'Essay',
  components: {
    OutLine: () => import('./components/OutLine'),
    MyLink: () => import('./components/MyLink'),
    EmptyContent: () => import('./components/EmptyContent')
  },
  data () {
    return {
      form: {
        id: 0,
        essay: ''
      },
      id: 0,
      list: [],
      dialogVisible: false,
      dialogVisibleEdit: false
    }
  },
  computed: {
    isCurrent () {
      return this.id === this.$store.getters.username
    }
  },
  created () {
    this.id = this.$route.query.id
    this.getEssay()
  },
  methods: {
    unixFormat,
    getCard,
    getHttpCard,
    handleClose () {
      if (this.dialogVisibleEdit) {
        this.form.id = 0
        this.form.essay = ''
        this.dialogVisibleEdit = false
      }
      this.dialogVisible = false
    },
    // 获取短文
    async getEssay () {
      const items = (await essayList({id: this.id})).data || []
      const list = []
      const tmp = []
      for (const item of items) {
        if (item.Top === 1) {
          list.push(item)
        } else {
          tmp.push(item)
        }
      }
      this.list = list.concat(tmp)
    },
    // 打开修改短文Dialog
    openEdit (item) {
      this.form.id = item.ID
      this.form.essay = item.Essay
      this.dialogVisibleEdit = true
      this.dialogVisible = true
    },
    // 置顶
    async topping (id) {
      const index = this.findIndex(id)
      if (index === 0) {
        return
      }
      await essayTopping({ id: id })
      for (let i = 0; i < this.list.length; i++) {
        if (i === index) {
          this.list[i].Top = 1
        } else {
          this.list[i].Top = 0
        }
      }
      if (index !== 0) {
        let swap = this.list[index]
        this.$set(this.list, index, this.list[0])
        this.$set(this.list, 0, swap)
      }
      this.$message.success('修改成功, 数据生效中, 请等待3~5分钟')
    },
    // list搜索
    findIndex (id) {
      for (let i = 0; i < this.list.length; i++) {
        if (this.list[i].ID === id) {
          return i
        }
      }
      return -1
    },
    // 修改或添加短文
    async upsertEssay () {
      if (this.form.essay === '') {
        this.$refs.essay.focus()
        return
      }
      if (this.form.essay.length > 240) {
        this.$message.warning('短文过长,请修改')
        return
      }
      if (this.dialogVisibleEdit) {
        await essayUpdate(this.form)
        const index = this.findIndex(this.form.id)
        this.$set(this.list[index], 'Essay', this.form.essay)
        if (this.list[index].Top === 1) {
          this.$message.success('修改成功, 数据生效中, 请等待3~5分钟')
        }
      } else {
        const item = (await essayAdd(this.form)).data
        this.form.essay = ''
        this.list.push(item)
      }
      this.handleClose()
    },
    // 删除短文
    async delEssay (item) {
      if (item.Top === 1) {
        this.$message.warning('请保留一个置顶短文')
        return
      }
      await essayDel({id: item.ID})
      this.list.splice(this.findIndex(item.ID), 1)
    },
    // 复制短文
    copyEssay (item) {
      const essay = `${item.Essay}\n名片：${getCard(this.id)}\n链接：${getHttpCard(this.id)}\n来源：查链\n著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。`
      this.$copyText(essay)
      this.$message.success('已复制')
    }

  }
}
</script>

<style scoped>
.essay{
  width: 95%;
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}

.essayBody{
  padding: .1rem;
}

.essayCnt{
  color: #777;
  font-size: .20rem;
  padding: .1rem;
}

.essayOptionBody{
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: end;
}

.essayOption{
  width: 20%;
  text-align: center;
  font-size: .18rem;
  color: rgba(0, 0, 0, 0.6);
  cursor: pointer;
  padding-top: .1rem;
}

.essayOption:hover{
  color: #409eff;
}

.outlineRight{
  width: 60%;
}

.outlineRight>span{
  float: right;
  padding-right: .2rem;
  cursor: pointer;
}

</style>
