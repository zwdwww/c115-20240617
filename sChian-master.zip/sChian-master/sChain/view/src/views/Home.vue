<template>
  <div class="content" v-loading="loading">
    <EmptyContent v-if="cards.length === 0" />
    <div v-else>
      <div>
        <Card @clickKeyword="searchKeyword"
              @clickAddress="searchAddress"
              v-for="(item, i) in cards"
              :key="item.ID"
              :match-address="form.address"
              :match-key="form.key"
              :index="i + 1"
              :data="item"/>
        <el-pagination
          style="margin-bottom: .2rem;"
          :small="isPhone()"
          @current-change="handleCurrentChange"
          :current-page.sync="form.page"
          :page-size="20"
          layout="total, prev, pager, next"
          :total="count"/>
      </div>
    </div>
  </div>
</template>

<script>
import {cardSearch, cardSuggest} from '@/api/card'
import {getCardByHost} from '@/utils/card'
import {isPhone} from '@/utils/utils'

export default {
  name: 'Home',
  components: {
    DynamicsLoad: () => import('@/views/components/DynamicsLoad.vue'),
    EmptyContent: () => import('@/views/components/EmptyContent.vue'),
    Card: () => import('./components/Card')
  },
  data () {
    return {
      cards: [],
      loading: false,
      topCard: null,
      count: 0,
      form: {
        id: '',
        address: '',
        key: '',
        search: '',
        page: 1
      }
    }
  },
  created () {
    if (this.$route.query.address) {
      this.form.address = this.$route.query.address
    }
    if (this.$route.query.key) {
      this.form.key = this.$route.query.key
    }
    if (this.$route.query.s) {
      this.form.search = this.$route.query.s
    }
    this.getCards()
  },
  watch: {
    '$route.query': function (val) {
      const address = val.address || ''
      const key = val.key || ''
      const s = val.s || ''
      let isChange = false
      if (address !== this.form.address) {
        this.form.address = address
        isChange = true
      }
      if (key !== this.form.key) {
        this.form.key = key
        isChange = true
      }
      if (s !== this.form.search) {
        this.form.search = s
        isChange = true
      }
      if (isChange) {
        console.log('getCards query change')
        this.getCards()
      }
    }
  },
  methods: {
    isPhone,
    // 换页
    handleCurrentChange (val) {
      this.form.page = val
      this.getCards()
    },
    // 路由Query修改
    addRouterQuery (k, v) {
      const query = { ...this.$route.query }
      if (v === '') {
        delete query[k]
        this.$router.push({query: query})
      } else if (query[k] !== v) {
        query[k] = v
        this.$router.push({query: query})
      }
    },
    // 地址搜索
    searchAddress (addr) {
      this.addRouterQuery('address', addr)
      this.form.address = addr
      this.form.page = 1
      this.getCards()
    },
    // 关键词搜索
    searchKeyword (word) {
      this.addRouterQuery('key', word)
      this.form.key = word
      this.form.page = 1
      this.getCards()
    },
    // 获取名片的Index
    findCardsById (items, topCard) {
      if (topCard === null) {
        return -1
      }
      for (let i = 0; i < items.length; i++) {
        if (items[i].Uid === topCard.Uid) {
          return i
        }
      }
      return -1
    },
    // 获取推荐名片列表
    async getCards (searchInput = '') {
      if (searchInput !== '') {
        this.form.id = searchInput
      } else if (this.$route.params.id) {
        this.form.id = this.$route.params.id
      } else {
        this.form.id = getCardByHost(location.host || '')
      }

      this.loading = true

      let data = {}
      if (this.form.key !== '' || this.form.address !== '' || this.form.search !== '') {
        data = (await cardSearch(this.form)).data
      } else {
        data = (await cardSuggest(this.form)).data
      }

      // 处理需要被置顶的名片
      if (data.card !== null) {
        const findIndex = this.findCardsById(data.items || [], data.card)
        if (findIndex === -1) {
          this.cards = [data.card].concat(data.items || [])
        } else {
          const items = data.items
          const swap = data.items[findIndex]
          items[findIndex] = items[0]
          items[0] = swap
          this.cards = items
        }
      } else {
        this.cards = data.items || []
      }

      this.topCard = data.card
      this.count = data.count || 0
      this.form.id = ''
      window.scrollTo(0, 0)
      this.loading = false
    }
  }
}
</script>

<style scoped>
.content{
  height: 100%;
  position: relative;
  width: 100%;
  font-size: .2rem;
  background: #fff;
}
</style>
