<template>
  <div class="favorites">
    <OutLine>
        <span slot="left">
          <my-link style="color: #409eff" :open="getHttpCard(id)">{{ getCard(id) }}</my-link>的收藏夹
        </span>
        <div slot="right" v-if="isCurrent" class="outlineRight">
          <span @click="clickRecommend">推荐</span>
          <span @click="dialogVisible=true">自定义</span>
        </div>
    </OutLine>

    <EmptyContent content='暂无收藏内容' v-if="list.length === 0" />

    <div v-else>
      <div  style="display: flex;align-items: center;" class="item" :key="i" v-for="(item, i) in list">
        <div style="display: block;width: 90%">
          <div v-if="item.Key === ''"
               style="text-overflow: ellipsis;overflow: hidden;white-space: nowrap;cursor: pointer"
               @click="openLink(item.Value)">
            <span style="color: rgba(0, 0, 0, 0.6);">{{ item.Value }}</span>
          </div>
          <div v-else
               style="text-overflow: ellipsis;overflow: hidden;white-space: nowrap;cursor: pointer"
               @click="openLink(item.Value)">
            <span style="color: rgba(0, 0, 0, 0.6);">{{ item.Key }}</span>
          </div>
        </div>
        <FavDropDown :options="options" @click="optionEvent($event, item)">
          <i class="el-icon-more-outline itemMore"></i>
        </FavDropDown>
      </div>
      <div style="border-top: 1px solid rgba(0, 0, 0, 0.1);margin-top: .1rem"></div>
    </div>

    <el-dialog
      :title="dialogVisibleEdit?'修改':'添加'"
      :visible.sync="dialogVisible"
      :before-close="handleClose"
      width="5rem">
      <el-form ref="form" :rules="rule" :model="form" label-width="1rem">
        <el-form-item label="名称" prop="name">
          <el-input ref="name" size="mini" v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="网址" prop="link">
          <el-input ref="link" placeholder="https://" size="mini" v-model="form.link"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="upsertFav">{{ dialogVisibleEdit?'修 改': '添 加' }}</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {favAdd, favList, favDel, favOrder, favUpdate} from '@/api/favorites'
import {getCard, getHttpCard} from '@/utils/card'

export default {
  name: 'Favorites',
  components: {
    MyLink: () => import('@/views/components/MyLink.vue'),
    FavDropDown: () => import('./components/FavDropDown'),
    OutLine: () => import('./components/OutLine'),
    EmptyContent: () => import('./components/EmptyContent')
  },
  data () {
    return {
      id: '',
      list: [],
      form: {
        id: 0,
        name: '',
        link: ''
      },
      updateIndex: 0,
      dialogVisible: false,
      dialogVisibleEdit: false,
      rule: {
        name: [
          { max: 64, message: '名称过长', trigger: 'blur' }
        ],
        link: [
          { required: true, message: '请输入链接', trigger: 'blur' },
          { max: 128, message: '链接过长', trigger: 'blur' }
        ]
      }
    }
  },
  created () {
    this.id = this.$route.query.id
    this.getFav()
  },
  computed: {
    isCurrent () {
      return this.id === this.$store.getters.username
    },
    options () {
      if (this.isCurrent) {
        return ['打开', '分享', '复制链接', '上移一位', '下移一位', '修改', '删除', '自定义添加']
      }
      return ['打开', '分享', '复制链接']
    }
  },
  methods: {
    getCard,
    getHttpCard,
    openLink (link) {
      window.open(link)
    },
    // 跳转到推荐内容
    clickRecommend () {
      window.open('http://hao.bigdata.ren/', '_blank')
    },
    // Dialog关闭
    handleClose () {
      if (this.dialogVisibleEdit) {
        this.dialogVisibleEdit = false
        this.form.name = ''
        this.form.link = ''
        this.form.id = 0
      }
      this.dialogVisible = false
    },
    // 获取收藏夹排序ID
    getFavOrder () {
      const order = []
      for (const e of this.list) {
        order.push(e.ID)
      }
      return order
    },
    // 获取收藏夹
    async getFav () {
      const data = (await favList({id: this.id})).data
      const order = {}
      const items = data.items

      // 构建order
      for (let i = 0; i < data.order.length; i++) {
        order[data.order[i]] = i
      }

      // 排序收藏夹
      items.sort(function (a, b) {
        return (order[a.ID] || 0) - (order[b.ID] || 0)
      })
      this.list = items
    },
    // 添加/修改收藏夹
    async upsertFav () {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const form = { ...this.form }
          form.order = this.getFavOrder()
          if (!form.link.startsWith('https://') && !form.link.startsWith('http://')) {
            form.link = 'https://' + form.link
          }
          // 修改或新增
          if (this.dialogVisibleEdit) {
            favUpdate(form).then(() => {
              this.list[this.updateIndex].Key = form.name
              this.list[this.updateIndex].Value = form.link
              this.form.link = ''
              this.form.name = ''
              this.dialogVisible = false
            })
          } else {
            favAdd(form).then((resp) => {
              this.list.push(resp.data)
              this.form.link = ''
              this.form.name = ''
              this.dialogVisible = false
            })
          }
        } else {
          return false
        }
      })
    },
    // DropDown选项点击
    async optionEvent (option, item) {
      const indexes = this.getFavOrder()
      const index = indexes.indexOf(item.ID)
      let swap = null

      switch (option) {
        case '打开':
          window.open(item.Value, '_blank')
          return
        case '分享':
          await this.$copyText(item.Value)
          return
        case '复制链接':
          await this.$copyText(item.Value)
          this.$message.success('复制成功')
          return
        case '上移一位':
          if (index - 1 < 0) {
            return
          }
          swap = this.list[index - 1]
          this.$set(this.list, index - 1, this.list[index])
          this.$set(this.list, index, swap)
          await favOrder({ order: this.getFavOrder() })
          return
        case '下移一位':
          if (index + 1 >= this.list.length) {
            return
          }
          swap = this.list[index + 1]
          this.$set(this.list, index + 1, this.list[index])
          this.$set(this.list, index, swap)
          await favOrder({ order: this.getFavOrder() })
          return
        case '删除':
          indexes.splice(index, 1)
          await favDel({id: item.ID, order: indexes})
          this.list.splice(index, 1)
          return
        case '修改':
          this.form.id = item.ID
          this.form.name = item.Key
          this.form.link = item.Value
          this.updateIndex = index
          this.dialogVisibleEdit = true
          this.dialogVisible = true
          return
        case '自定义添加':
          this.dialogVisible = true
      }
    }
  }
}
</script>

<style scoped>
.favorites{
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}

.outlineRight{
  width: 60%;
}

.outlineRight>span{
  float: right;
  padding-right: .2rem;
  color: rgba(0, 0, 0, 0.8);
  cursor: pointer;
}

.item{
  margin-top: .1rem;
  padding-top: .1rem;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
}

.itemMore{
  font-size: .3rem;
  margin-top: 7px;
  padding-right: .1rem;
  color: rgba(0, 0, 0, 0.4);
  transform: rotate(90deg);
  cursor: pointer;
}
</style>
