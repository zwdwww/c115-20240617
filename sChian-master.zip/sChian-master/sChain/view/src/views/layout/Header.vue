<template>
  <div class="header">
    <div class="search">
      <div @click="jumpMy" class="logo">
        <span>查</span>
        <span style="margin-left: .1rem">链</span>
      </div>
      <div style="width: 70%;margin-top: .08rem">
        <input placeholder="搜索ID/短文/名称" v-model="searchInput">
        <i class="el-icon-search searchIcon" @click="clickSearch"></i>
      </div>
      <div style="width: 15%">
        <div @click="jumpMy">
          <i v-if="!isLogin" class="el-icon-edit usrIcon"></i>
          <i v-else class="el-icon-user usrIcon"></i>
        </div>
      </div>
    </div>
    <div class="slide">
      <div class="lineBox">
        <div id="line" class="line"></div>
      </div>
      <span @click="clickEvent" ref="element">推荐</span>
      <span @click="clickEvent">排行</span>
      <span @click="clickEvent">关注</span>
      <span @click="clickDbLink">链库</span>
      <span @click="clickEvent">搜词</span>
      <span @click="clickEvent">地址</span>
    </div>
  </div>
</template>

<script>

import {getHttpCard} from '@/utils/card'
import {sysConfigGet} from '@/api/sys_config'

export default {
  name: 'Header',
  data () {
    return {
      indexes: {
        '推荐': {num: 0, path: '/home'},
        '排行': {num: 1, path: '/rank'},
        '关注': {num: 2, path: '/star'},
        '链库': {num: 3, path: '/database'},
        '搜词': {num: 4, path: '/keyword'},
        '地址': {num: 5, path: '/address'}
      },
      searchInput: '',
      dbLink: ''
    }
  },
  mounted () {
    this.changePath(this.$route.path)

    const clientWith = this.$refs.element.clientWidth
    document.getElementById('line').style.width = `${clientWith}px`
  },
  watch: {
    $route: function (val) {
      this.changePath(val.path)
    }
  },
  computed: {
    isLogin: function () {
      return this.$store.getters.username !== ''
    }
  },
  methods: {
    // 监听路由变化,header一起切换
    changePath (path) {
      for (const key of Object.keys(this.indexes)) {
        if (this.indexes[key].path === path) {
          this.changeHeader(key)
          break
        }
      }
    },
    async clickSearch () {
      if (this.searchInput === '') {
        return
      }
      await this.$router.push({ name: 'Home', query: { s: this.searchInput } })
      this.searchInput = ''
    },
    // 点击header切换路径
    clickEvent (e) {
      this.changeHeader(e.target.innerText)
    },
    // 点击链库
    async clickDbLink (e) {
      if (this.dbLink === '') {
        const resp = (await sysConfigGet({ key: 'DbLink' })).data
        this.dbLink = resp.value
        if (this.dbLink === '') {
          this.clickEvent(e)
          return
        }
      }
      window.open(this.dbLink)
    },
    // header的下划线位置计算
    changeHeader (text) {
      const clientWith = this.$refs.element.clientWidth
      const index = this.indexes[text]
      document.getElementById('line').style.transform = `translateX(${clientWith * index.num}px)`
      if (index.path !== '' && this.$route.path !== index.path) {
        this.$router.push(index.path)
      }
    },
    // 页面跳转
    jumpMy () {
      if (!this.isLogin) {
        this.$router.push('/login')
      } else {
        location.href = getHttpCard(this.$store.getters.username)
      }
    },
    // 跳转到首页
    jumpHome () {
      if (this.$route.path !== '/home') {
        this.$router.push('/home')
      }
    }
  }
}
</script>

<style scoped>
.header{
  background: #fff;
  height: 1.5rem;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 2px;
  z-index: 100;
  position: sticky;
  top: 0;
}

.search{
  padding: .2rem 0 0 .2rem;
  height: 1.2rem;
  display: flex;
}

.slide {
  display: flex;
  width: 100%;
  height: .2rem;
  font-size: .28rem;
  letter-spacing: .13em;
  align-items: center;
  padding-bottom: .2rem;
}

a{
  text-decoration: none;
  color: #000;
}

span {
  width: 100%;
  cursor: pointer;
}

.lineBox{
  top: 1.5rem;
  position: absolute;
  z-index: 1;
}

.line{
  background-color: #1e90ff;
  height: .03rem;
  transition: .3s;
  transform: translateX(0);
}

input{
  width: 100%;
  height: .5rem;
  background-color: #ebebec;
  border-radius: .2rem;
  padding: 0 .2rem;
}

.usrIcon{
  margin-top: .1rem;
  font-size: .5rem;
  cursor: pointer;
}

.searchIcon{
  font-size: .3rem;
  cursor: pointer;
  position: relative;
  bottom: .4rem;
  left: 45%;
}

.logo{
  width: 15%;
  font-size: .4rem;
  font-weight: bold;
  color: rgb(72, 187, 238);
  margin-top: .05rem;
  cursor: pointer;
}
</style>
