<template>
  <div class="footer">
    <button @click="click('信息')" :class="active==='信息'?'active':''">
      <span class="btnContent">
        <span>信息</span>
        <i class="el-icon-info icon"></i>
      </span>
    </button>
    <button @click="click('关注')" :class="active==='关注'?'active':''">
      <span class="btnContent">
        <span>关注</span>
        <i class="el-icon-user-solid icon"></i>
      </span>
    </button>
    <button @click="click('首页')" :class="active==='首页'?'active':''">
      <span class="btnContent">
        <span>首页</span>
        <i class="el-icon-s-home icon"></i>
      </span>
    </button>
    <button @click="click('搜词')" :class="active==='搜词'?'active':''">
      <span class="btnContent">
        <span>搜词</span>
        <i class="el-icon-search icon"></i>
      </span>
    </button>
    <button @click="click('我的')" :class="active==='我的'?'active':''">
      <span class="btnContent">
        <span>我的</span>
        <i class="el-icon-s-custom icon"></i>
      </span>
    </button>
  </div>
</template>

<script>
import {getToken} from '@/utils/auth'

export default {
  name: 'Footer',
  data () {
    return {
      active: '信息',
      routerMap: {
        '我的': {path: '/profile', auth: true},
        '首页': {path: '/home', auth: false},
        '排行': {path: '/rank', auth: false},
        '关注': {path: '/star', auth: true},
        '信息': {path: '/chat', auth: true},
        '搜词': {path: '/keyword', auth: false}
      }
    }
  },
  mounted () {
    this.findName(this.$route.path)
  },
  watch: {
    $route: function (val) {
      this.findName(val.path)
    }
  },
  methods: {
    findName (path) {
      let have = false
      for (const key of Object.keys(this.routerMap)) {
        if (path.startsWith(this.routerMap[key].path)) {
          have = true
          this.active = key
        }
      }
      if (!have) {
        this.active = ''
      }
    },
    click (name) {
      this.active = name
      if (!(name in this.routerMap)) {
        return
      }
      if (this.$route.path !== this.routerMap[name].path) {
        if (this.routerMap[name].auth) {
          if (getToken()) {
            this.$router.push(this.routerMap[name].path)
          } else {
            this.$router.push(`/login?redirect=${this.routerMap[name].path}`)
          }
        } else {
          this.$router.push(this.routerMap[name].path)
        }
      }
    }
  }
}
</script>

<style scoped>
.footer{
  background: #fff;
  height: 1.2rem;
  display: flex;
  justify-content: center;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  border-radius: 2px;
  z-index: 100 !important;
  position: fixed;
  bottom: 0;
}
button{
  width: 1.8rem;
  font-size: .3rem;
  background-color: rgba(0, 0, 0, 0);
  letter-spacing: .2em;
  color: rgba(0, 0, 0, 0.4);
  cursor: pointer;
}
button:hover{
  background-color: rgba(0, 0, 0, 0.1);
}

.active{
  color: rgb(81, 177, 220);
}

.btnContent{
  display: flex;
  flex-direction: column-reverse;
  width: 100%;
}

.icon{
  width: 100%;
  font-size: .45rem;
}
</style>
