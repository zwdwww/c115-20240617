<template>
  <div ref="home" class="home">
    <Header v-show="hideHeader" />
    <div style="margin-bottom: 1px"></div>
    <div :class="{'pageContent': moreContent, 'pageContentLess': lessContent}">
      <keep-alive :include="cachedViews">
        <router-view :key="key" />
      </keep-alive>
    </div>
    <div style="margin-top: 1px"></div>
    <Footer :style="footerStyle" />
  </div>
</template>

<script>
export default {
  name: 'Layout',
  data () {
    return {
      lessContent: true, // 默认少量内容
      moreContent: false, // 内容超过界面
      footerStyle: ''
    }
  },
  components: {
    Header: () => import('./Header'),
    Footer: () => import('./Footer')
  },
  mounted () {
    this.addTags()

    this.footerStyle = `width:${this.$refs.home.children[0].clientWidth}px`

    // 根据Scroll是否存在切换不同的class样式
    window.addEventListener('scroll', () => {
      const elVal = document.documentElement.scrollTop || document.body.scrollTop || window.pageYOffset
      this.resizeEvent(elVal)
    }, true)
  },
  computed: {
    // 页面缓存
    cachedViews () {
      return this.$store.state.tagsView.cachedViews
    },
    key () {
      return this.$route.path
    },
    hideHeader () {
      const { meta } = this.$route
      return !meta.hideHeader
    }
  },
  watch: {
    $route () {
      this.addTags()
    }
  },
  methods: {
    // 界面尺寸变化事件, 根据界面溢出和不溢出进行CSS的调整
    resizeEvent (height) {
      if (height === 0) {
        this.moreContent = false
        this.lessContent = true
      } else {
        this.lessContent = false
        this.moreContent = true
      }
    },
    // 添加缓存
    addTags () {
      const { name, meta } = this.$route
      const noCache = meta.noCache || false
      if (name && !noCache) {
        this.$store.dispatch('tagsView/addCachedView', this.$route)
      }
      return false
    }
  }
}
</script>

<style>
*, ::after, ::before {
  box-sizing: border-box;
}

* {
  border: 0;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
  margin: 0;
  padding: 0;
}

.home {
    background-color: rgb(244, 244, 244);
    min-height: 100%;
    padding-left: .05rem;
    padding-right: .05rem;
}

.pageContent{
//padding-top: .1rem;
  padding-bottom: 1.2rem;
  width: 99%;
  margin: auto;
  background-color: #fff;
  height: 100%;
}

.pageContentLess{
  height: calc(100vh - 1.65rem);
  //padding-top: .1rem;
  padding-bottom: 1.2rem;
  width: 99%;
  margin: auto;
  background-color: #fff;
}

.elMessage {
  min-width:5rem;
}
</style>
