<template>
  <div class="database">
    <EmptyContent content="暂无内容" />
  </div>
</template>

<script>
export default {
  name: 'Database',
  components: {
    EmptyContent: () => import('@/views/components/EmptyContent')
  }
}
</script>

<style scoped>
.database{
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}
</style>
