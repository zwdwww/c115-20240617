<template>
  <div class="editContent" v-loading="loading">
    <h2 style="margin-bottom: .2rem">编辑或删除名片</h2>
    <div>
      <span class="label">ID:  </span>
      <my-link :open="getHttpCard(form.Uid)" style="color: #20a2aa;">{{ getCard(form.Uid) }}</my-link>
    </div>
    <div>
      <form>
        <div>
          <label>
            <span class="label">名称:</span>
            <input @change="changeTitle" v-model="form.Title" placeholder="单位/个人" class="largeInput">
          </label>
        </div>
        <div>
          <select v-model="form.Contact[0]" class="infoSelect label">
            <option value="QQ">QQ</option>
            <option value="Mail">Mail</option>
          </select>
          <input v-model="form.Contact[1]" placeholder="联系方式" class="largeInput">
        </div>
        <div>
          <span class="label">地址:</span>
          <select v-model="form.Address[0]" class="miniInput">
            <option  :key="i" :value="item" v-for="(item, i) in province" style="font-size: .2rem;">
              {{ item }}
            </option>
          </select>
          >
          <input v-model="form.Address[1]" placeholder="市/县" class="miniInput">
          >
          <input v-model="form.Address[2]" placeholder="路/乡镇" class="miniInput">
          >
          <input v-model="form.Address[3]" placeholder="公交/站村" class="miniInput">
          >
          <input v-model="form.Address[4]" placeholder="小区/小组" class="miniInput">
        </div>
        <div>
          <span class="label">搜词:</span>
          <input v-model="form.Keywords[0]" placeholder="网友" class="miniInput">
          <input v-model="form.Keywords[1]" placeholder="交友" class="miniInput">
          <input v-model="form.Keywords[2]" placeholder="空缺" class="miniInput">
        </div>
        <div>
          <el-button @click="updateData" class="successButton">修改完成</el-button>
          <el-button @click="$router.push('/profile')" class="returnButton">返回</el-button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import {cardCurrent, cardUpdate} from '@/api/card'
import {getCard, getHttpCard} from '@/utils/card'
import MyLink from '@/views/components/MyLink.vue'
import province from '@/utils/province'

export default {
  name: 'Edit',
  components: {MyLink},
  data () {
    return {
      loading: false,
      form: {
        Uid: 0,
        Title: '',
        Contact: [],
        Address: [],
        Keywords: []
      },
      province: province
    }
  },
  created () {
    this.syncCurrentCard()
  },
  methods: {
    getHttpCard,
    getCard,
    changeTitle () {
      if (this.form.Title.length > 21) {
        this.form.Title = this.form.Title.substring(0, 21)
        this.$message.warning('标题长度应控制在21个字符内')
      }
    },
    // 获取名片数据
    async syncCurrentCard () {
      const form = (await cardCurrent()).data.card
      const address = form.Address.split('>')
      const keywords = form.Keywords.split('$$')
      const contact = form.Contact.split('$')
      for (let i = 0; i < (5 - address.length); i++) {
        address.push('')
      }
      for (let i = 0; i < (3 - keywords.length); i++) {
        keywords.push('')
      }
      for (let i = 0; i < (2 - contact.length); i++) {
        contact.push('')
      }

      if (address[0] === '') {
        address[0] = '北京'
      }
      if (contact[0] === '') {
        contact[0] = 'QQ'
      }

      this.form = form
      this.form.Address = address
      this.form.Keywords = keywords
      this.form.Contact = contact
    },
    // 更新名片数据
    async updateData () {
      await cardUpdate(this.form)
      this.$message.success('修改完成')
    }
  }
}
</script>

<style scoped>
.editContent{
  padding: .1rem;
  text-align: left;
  margin: auto;
  width: 70%;
  height: calc(100vh - 2.7rem);
  font-size: .24rem;
  font-weight: 500;
}

.largeInput{
  background: #f9f9f9;
  text-indent: .053rem;
  border: .013rem solid #ebebeb;
  height: .5rem;
  width: 70%;
}

.miniInput{
  background: #f9f9f9;
  text-indent: .053rem;
  border: .013rem solid #ebebeb;
  height: .5rem;
  width: 15%;
}

form>div{
  margin-top: .1rem;
}

.label{
  display: inline-block;
  width: 20%;
}

.infoSelect{
  height: .5rem;
  font-size: .2rem;
  background: #fff;
  border: 1px solid rgba(0, 0, 0, 0.1);
}

textarea{
  border: 1px solid rgba(0, 0, 0, 0.1);
  background: #f9f9f9;
  width: 90%;
  max-width: 90%;
  min-width: 90%;
  height: 1.5rem;
  border-radius: .1rem;
  font-size: .17rem;
}

.successButton{
  background: rgb(98, 188, 122);
  cursor: pointer;
  color: #fff;
  padding: .06rem .14rem;
  border-radius: .05rem;
}

.returnButton{
  background: rgb(187, 187, 102);
  cursor: pointer;
  color: #fff;
  padding: .06rem .14rem;
  border-radius: .05rem;
}

.delButton{
  background: coral;
  cursor: pointer;
  color: #fff;
  padding: .06rem .14rem;
  border-radius: .05rem;
}
</style>
