<template>
  <div class="profile">
    <ul class="myUl">
      <li class="currLi myLi">
        我的名片
        <my-link style="color: #409eff" :open="getHttpCard($store.getters.username)">
          {{ getCard($store.getters.username) }}
        </my-link>
      </li>
      <li @click="$router.push('/profile/edit')" class="myLi">
        <i class="el-icon-arrow-down firstI"></i>
        修改名片
        <i class="el-icon-arrow-right endI"></i>
      </li>
      <li class="myLi" @click="$router.push({path: '/leave-message', query: {id: $store.getters.username}})">
        <i class="el-icon-s-comment firstI"></i>
        删除别人给我的留言
        <i class="el-icon-arrow-right endI"></i>
      </li>
      <li @click="openPhone" class="myLi">
        <i class="el-icon-mobile firstI"></i>
        我的手机号
        <i class="el-icon-arrow-right endI"></i>
      </li>
<!--      <li @click="openQuestion" class="myLi">-->
<!--        <i class="el-icon-s-opportunity firstI"></i>-->
<!--        设置密保问题-->
<!--        <i class="el-icon-arrow-right endI"></i>-->
<!--      </li>-->
      <li @click="openPassword" class="myLi">
        <i class="el-icon-question firstI"></i>
        修改密码
        <i class="el-icon-arrow-right endI"></i>
      </li>
      <li @click="logoffUid" class="myLi">
        <i class="el-icon-delete firstI"></i>
        注销此id
        <i class="el-icon-arrow-right endI"></i>
      </li>
      <li @click="logout" class="myLi">
        <i class="el-icon-s-unfold firstI"></i>
        退出
        <i class="el-icon-arrow-right endI"></i>
      </li>
    </ul>
    <el-dialog width="30%" :title="dialog.title" :visible.sync="dialog.visible" :before-close="handleClose">
      <el-form ref="phone" v-if="dialog.type === 'phone'" :model="form" :rules="phoneRules">
        <el-form-item prop="phone">
          <el-input :size="inputSize" style="width: 100%" v-model="form.phone"></el-input>
        </el-form-item>
        <el-form-item  v-show="showVerifyCode" prop="verifyCode">
          <el-input :size="inputSize" v-model="form.verifyCode" style="width: 100%" placeholder="请输入验证码">
            <el-button type="text" slot="append" @click="sendVerifyCode">{{ verifyCodeBtn }}</el-button>
          </el-input>
        </el-form-item>
      </el-form>
      <el-form ref="question" v-else-if="dialog.type === 'question'" :model="form" :rules="questionRules">
        <el-form-item prop="questionOne">
          <el-select :size="inputSize" placeholder="请选择密保问题1" v-model="form.questionOne" style="width: 100%">
            <el-option :key="item" :label="item" :value="item" v-for="item in filterQuestion" />
          </el-select>
        </el-form-item>
        <el-form-item prop="questionOneAnswer">
          <el-input :size="inputSize" placeholder="请输入密保问题1答案" v-model="form.questionOneAnswer" style="width: 100%"></el-input>
        </el-form-item>
        <el-form-item prop="questionTwo">
          <el-select :size="inputSize" placeholder="请选择密保问题2" v-model="form.questionTwo" style="width: 100%">
            <el-option :key="item" :label="item" :value="item" v-for="item in filterQuestion" />
          </el-select>
        </el-form-item>
        <el-form-item prop="questionTwoAnswer">
          <el-input :size="inputSize" placeholder="请输入密保问题2答案" v-model="form.questionTwoAnswer" style="width: 100%"></el-input>
        </el-form-item>
        <el-form-item prop="questionThree">
          <el-select :size="inputSize" placeholder="请选择密保问题3" v-model="form.questionThree" style="width: 100%">
            <el-option :key="item" :label="item" :value="item" v-for="item in filterQuestion" />
          </el-select>
        </el-form-item>
        <el-form-item prop="questionThreeAnswer">
          <el-input :size="inputSize" placeholder="请输入密保问题3答案" v-model="form.questionThreeAnswer" style="width: 100%"></el-input>
        </el-form-item>
        <el-form-item v-show="showVerifyCode" prop="verifyCode">
          <el-input :size="inputSize" v-model="form.verifyCode" style="width: 100%" placeholder="请输入验证码">
            <el-button type="text" slot="append" @click="sendVerifyCode">{{ verifyCodeBtn }}</el-button>
          </el-input>
        </el-form-item>
      </el-form>
      <el-form ref="password" v-else :model="form" :rules="passwordRules">
        <el-form-item prop="password">
          <el-input :size="inputSize" style="width: 100%" v-model="form.password" type="password" placeholder="请输入新密码"></el-input>
        </el-form-item>
        <el-form-item  v-show="showVerifyCode" prop="verifyCode">
          <el-input :size="inputSize" v-model="form.verifyCode" style="width: 100%" placeholder="请输入验证码">
            <el-button type="text" slot="append" @click="sendVerifyCode">{{ verifyCodeBtn }}</el-button>
          </el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button v-if="!showVerifyCode" @click="showVerifyCode=true">修改</el-button>
        <el-button v-else v-loading="formBtnLoading" @click="handleInfo">确认修改</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>

import MyLink from '@/views/components/MyLink.vue'
import {getCard, getHttpCard} from '@/utils/card'
import {infoSetPassword, infoSetPhone, infoSetQuestion, logoff, sendInfoVerifyCode} from '@/api/auth'
import {validatePhone} from '@/utils/validate'

export default {
  name: 'Profile',
  components: {MyLink},
  data () {
    return {
      formBtnLoading: false,
      wait60Second: 0,
      timeoutId: 0,
      showVerifyCode: false,
      inputSize: '',
      dialog: {
        type: '',
        title: '',
        visible: false
      },
      questions: [
        '您母亲的姓名是?',
        '您父亲的姓名是?',
        '您配偶的姓名是?',
        '您配偶的生日是?',
        '您的出生地是?',
        '您的小学校名是?',
        '您的大学校名是?',
        '您的中学校名是?'
      ],
      form: {
        phone: '',
        password: '',
        questionOne: '',
        questionOneAnswer: '',
        questionTwo: '',
        questionTwoAnswer: '',
        questionThree: '',
        questionThreeAnswer: '',
        verifyCode: ''
      },
      phoneRules: {
        phone: [
          { validator: validatePhone, trigger: 'blur' }
        ],
        verifyCode: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { min: 6, max: 6, message: '请输入验证码', trigger: 'blur' }
        ]
      },
      questionRules: {
        questionOne: [
          { required: true, message: '请选择一个问题', trigger: 'blur' }
        ],
        questionOneAnswer: [
          { required: true, message: '请输入问题1答案', trigger: 'blur' }
        ],
        questionTwo: [
          { required: true, message: '请选择一个问题', trigger: 'blur' }
        ],
        questionTwoAnswer: [
          { required: true, message: '请输入问题2答案', trigger: 'blur' }
        ],
        questionThree: [
          { required: true, message: '请选择一个问题', trigger: 'blur' }
        ],
        questionThreeAnswer: [
          { required: true, message: '请输入问题3答案', trigger: 'blur' }
        ],
        verifyCOde: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { min: 6, max: 6, message: '请输入验证码', trigger: 'blur' }
        ]
      },
      passwordRules: {
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码不能少于6位', trigger: 'blur' }
        ],
        verifyCOde: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { min: 6, max: 6, message: '请输入验证码', trigger: 'blur' }
        ]
      }
    }
  },
  created () {
    if (window.screen.width <= 750) {
      this.inputSize = 'mini'
    }
  },
  destroyed () {
    if (this.timeoutId !== 0) {
      window.clearTimeout(this.timeoutId)
    }
  },
  computed: {
    filterQuestion () {
      let exist = [this.form.questionOne, this.form.questionTwo, this.form.questionThree]
      let items = []
      for (const q of this.questions) {
        if (exist.includes(q)) {
          continue
        }
        items.push(q)
      }
      return items
    },
    verifyCodeBtn () {
      if (this.wait60Second === 0) {
        return '获取验证码'
      }
      return `${this.wait60Second}秒后重新发送`
    }
  },
  methods: {
    getHttpCard,
    getCard,
    // 退出登录
    async logout () {
      await this.$store.dispatch('user/logout')
      await this.$store.dispatch('tagsView/delAllCachedViews')
      await this.$router.push('/')
      this.$message.success('已登出')
      location.reload()
    },
    // 一键注销
    async logoffUid () {
      this.$confirm('请确认是否注销ID? 注销后数据将无法找回', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.loading = true
        logoff().then(() => {
          this.$store.dispatch('user/logout').then(() => {
            this.loading = false
            this.$message.success('已注销')
            this.$router.push('/home')
          })
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '注销取消'
        })
      })
    },
    handleClose () {
      this.showVerifyCode = false
      this.dialog.visible = false
      for (const key of Object.keys(this.form)) {
        this.form[key] = ''
      }
      if (this.timeoutId !== 0) {
        window.clearTimeout(this.timeoutId)
      }
      this.wait60Second = 0
    },
    openPhone () {
      this.dialog.title = '我的手机号'
      this.dialog.visible = true
      this.form.phone = this.$store.getters.phone
      this.dialog.type = 'phone'
    },
    openQuestion () {
      this.dialog.title = '密保问题'
      this.dialog.visible = true
      this.dialog.type = 'question'
      const question = this.$store.getters.question
      const keys = Object.keys(question)
      if (keys.length === 3) {
        this.form.questionOne = keys[0]
        this.form.questionOneAnswer = question[keys[0]]
        this.form.questionTwo = keys[1]
        this.form.questionTwoAnswer = question[keys[1]]
        this.form.questionThree = keys[2]
        this.form.questionThreeAnswer = question[keys[2]]
      }
    },
    getQuestionObj () {
      const obj = {}
      obj[this.form.questionOne] = this.form.questionOneAnswer
      obj[this.form.questionTwo] = this.form.questionTwoAnswer
      obj[this.form.questionThree] = this.form.questionThreeAnswer
      return obj
    },
    openPassword () {
      this.dialog.title = '密码修改'
      this.dialog.visible = true
      this.dialog.type = 'password'
    },
    // 倒计时开始
    countdown () {
      this.wait60Second--
      if (this.wait60Second === 0) {
        return
      }
      this.timeoutId = setTimeout(this.countdown, 1000)
    },
    // 发送验证码
    async sendVerifyCode () {
      await sendInfoVerifyCode()
      this.wait60Second = 60
      this.countdown()
    },
    // 修改数据
    handleInfo () {
      this.formBtnLoading = true
      if (this.dialog.type === 'phone') {
        this.$refs.phone.validate((valid) => {
          if (valid) {
            infoSetPhone(this.form).then(() => {
              this.$store.dispatch('user/setPhone', this.form.phone)
              this.wait60Second = 0
              this.formBtnLoading = false
              this.handleClose()
              this.$message.success('修改成功')
            })
          } else {
            this.formBtnLoading = false
          }
        })
      } else if (this.dialog.type === 'password') {
        this.$refs.password.validate((valid) => {
          if (valid) {
            const id = this.$store.getters.username
            infoSetPassword(this.form).then(() => {
              this.$store.dispatch('user/logout').then(() => {
                this.$router.push(`/login?id=${id}`)
                this.formBtnLoading = false
                this.$message.warning('请重新登录')
                location.reload()
              })
            })
          } else {
            this.formBtnLoading = false
          }
        })
      } else if (this.dialog.type === 'question') {
        this.$refs.question.validate((valid) => {
          if (valid) {
            infoSetQuestion(this.form).then(() => {
              this.$store.dispatch('user/setQuestion', this.getQuestionObj())
              this.wait60Second = 0
              this.formBtnLoading = false
              this.handleClose()
              this.$message.success('修改成功')
            })
          } else {
            this.formBtnLoading = false
          }
        })
      }
    }
  }
}
</script>

<style scoped>
.profile{
  padding: .1rem;
  width: 100%;
  font-size: .28rem;
  text-align: left;
  height: calc(100vh - 2.7rem);
}
.myUl{
  list-style-type: none;
  margin: auto;
  width: 70%;
  color: #000;
  font-weight: 500;
}

.currLi{
  text-align: center;
  background-color: rgb(233, 243, 236);
}

.myLi{
  padding: .15rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.myLi:hover{
  border: 1px solid rgba(0, 0, 0, 0.4);;
}

i{
  font-weight: 600;
}

.firstI{
  color: #17becf;
}

.endI{
  float: right;
  padding-top: .08rem;
  color: rgba(0, 0, 0, 0.4);
}
</style>

<style>
.el-input{
  width: 100%;
}
</style>
