<template>
  <div class="content">
    <el-card v-loading="loading">
      <div class="pwdContent">
        <el-form style="margin-left: .3rem" ref="form" :rules="rules" :model="form" label-width="2rem">
          <el-form-item label="新密码" prop="firstInput">
            <el-input :size="size" placeholder="请输入密码"  type="password"  v-model="form.firstInput"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="secondInput">
            <el-input :size="size"  placeholder="请再次确认密码" type="password" v-model="form.secondInput"></el-input>
          </el-form-item>
          <div style="text-align: center;padding-left: 1rem;margin-top: .4rem">
            <el-button style="width: 4rem" type="primary"  :disabled="!checked" @click="resetPwd">确认修改</el-button>
          </div>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>
import {resetPassword} from '@/api/auth'

export default {
  name: 'ResetPassword',
  data () {
    const secondInputCheck = (rule, value, callback) => {
      if (this.form.firstInput !== value) {
        return callback(new Error('两次密码输入不一致'))
      }
      this.checked = true
      return callback()
    }
    return {
      form: {
        firstInput: '',
        secondInput: ''
      },
      size: '',
      checked: false,
      loading: false,
      rules: {
        firstInput: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码至少需要6位', trigger: 'blur' }
        ],
        secondInput: [
          { required: true, message: '请再次确认密码', trigger: 'blur' },
          { validator: secondInputCheck, trigger: 'blur' }
        ]
      }
    }
  },
  created () {
    if (window.screen.height <= 750) {
      this.size = 'mini'
    }
  },
  methods: {
    resetPwd () {
      if (this.form.firstInput === '') {
        this.$message.success('异常数据')
        return
      }

      if (this.form.firstInput !== this.form.secondInput) {
        this.$message.success('异常数据')
        return
      }

      this.$refs.form.validate((valid) => {
        if (valid) {
          this.loading = true
          const id = this.$store.getters.username
          resetPassword({ password: this.form.firstInput }).then(() => {
            this.loading = false
            this.$store.dispatch('user/logout')
            this.$store.dispatch('tagsView/delAllCachedViews')
            this.$router.push(`/login?id=${id}`)
            this.$message.warning('请重新登录')
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
.content{
  padding: .6rem;
  text-align: left;
}

.pwdContent{
  padding: .2rem 0;
}
</style>
