<template>
  <div class="address">
    <div class="content">
      <h4 style="text-align: left">最近访问</h4>
      <div style="display: flex" :key="i" v-for="(group, i) in last">
        <el-button icon="el-icon-location-outline" class="button" @click="clickBtn(province, false)">
          {{ province }}
        </el-button>
        <el-button class="button" :key="j" v-for="(value, j) in group" @click="clickBtn(value, false)">
          {{ value }}
        </el-button>
      </div>
    </div>

    <div class="content">
      <h4 style="text-align: left">国内地址</h4>
      <div style="display: flex;width: 100%" :key="i" v-for="(group, i) in inner">
        <el-button class="button"
                   :icon="value === '...'?'': 'el-icon-plus'"
                   v-show="value"
                   :key="j"
                   v-for="(value, j) in group"
                   @click="clickBtn(value, true)">
          {{ value }}
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
import province from '@/utils/province'
import {recordAddress, recordAddressPush} from '@/api/record'

export default {
  name: 'Address',
  data () {
    return {
      inner: [],
      last: [],
      province: ''
    }
  },
  created () {
    // 4个一组
    const concatProvince = province.concat(['...', '...'])
    let tmp = []
    const items = []
    for (let i = 1; i <= concatProvince.length; i++) {
      tmp.push(concatProvince[i - 1])
      if (i % 4 === 0) {
        items.push(tmp)
        tmp = []
      }
    }
    this.inner = items

    recordAddress().then((resp) => {
      this.province = resp.data.province || '未知'
      this.last = [resp.data.record || []]
    })
  },
  methods: {
    async clickBtn (address, record) {
      if (record) {
        await recordAddressPush({ address: address })
      }
      await this.$store.dispatch('tagsView/delCachedView', 'Home')
      await this.$router.push({ name: 'Home', query: { address: address } })
    }
  }
}
</script>

<style scoped>
.address{
  padding: .2rem  .5rem;
  font-size: .24rem;
}

.content{
  margin-top: .2rem;
  width: 100%;
}

.button{
  margin-top: .2rem;
  width: 25%;
  height: .8rem;
  background: #F2F6FC;
  color: #303133;
  font-size: .2rem;
}
</style>
