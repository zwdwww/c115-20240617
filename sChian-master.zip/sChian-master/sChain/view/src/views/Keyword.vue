<template>
  <div class="keyword">
    <EmptyContent content="暂无内容" v-if="keys.length === 0" />
    <div>
      <div :key="i" v-for="(key, i) in keys">
        <div class="content">
          <span class="title">{{ key }}.</span>
          <span class="option" :key="j" v-for="(value, j) in keysMap[key].slice(0, 6)" @click="search(value)">{{value}}</span>
          <div class="tail" @click="clickShow($event, key)">
            更多
          </div>
        </div>
        <transition name="fade">
          <div class="moreContent" v-if="showMore[key]">
            <div :key="i"
                 style="display: flex;"
                 :style="{ marginTop: i > 0? '.1rem':'0' }"
                 v-for="(group, i) in arrSplit(6, keysMap[key].slice(6))">
              <span class="option" :key="j" v-for="(word, j) in group" @click="search(word)">{{ word }}</span>
            </div>
          </div>
        </transition>
      </div>
    </div>
  </div>
</template>

<script>

import {searchKeys} from '@/api/utils'
import {KeywordGroup} from '@/utils/keyword'

export default {
  name: 'Keyword',
  components: {
    EmptyContent: () => import('@/views/components/EmptyContent')
  },
  data () {
    return {
      showMore: {},
      keysMap: {},
      keys: []
    }
  },
  created () {
    searchKeys().then((resp) => {
      const data = resp.data.keysMap || {}
      const keys = KeywordGroup
      const showMore = {}
      for (const key of keys) {
        showMore[key] = false
        if (data[key] === undefined) {
          data[key] = []
        }
        if (data[key].length < 6) {
          data[key] = data[key].concat(this.fillKeyword(6 - data[key].length))
        }
        data[key].sort(function (a, b) {
          return a.length - b.length
        })
      }
      this.keys = keys
      this.keysMap = data
      this.showMore = showMore
    })
  },
  methods: {
    fillKeyword (num) {
      const key = []
      for (let i = 0; i < num; i++) {
        key.push('空缺')
      }
      return key
    },
    arrSplit (num, source) {
      const arr = []
      let tmp = []
      for (let i = 0; i < source.length; i++) {
        tmp.push(source[i])
        if (tmp.length === num) {
          arr.push(tmp)
          tmp = []
        }
      }
      if (tmp.length !== 0) {
        arr.push(tmp)
      }
      return arr
    },
    clickShow (e, key) {
      for (const key1 of Object.keys(this.showMore)) {
        if (key1 === key) {
          continue
        }
        this.showMore[key1] = false
      }
      if (!this.showMore[key] && this.keysMap[key].length <= 6) {
        return
      }
      this.showMore[key] = !this.showMore[key]
    },
    async search (key) {
      await this.$store.dispatch('tagsView/delCachedView', 'Home')
      await this.$router.push({ name: 'Home', query: { key: key } })
    }
  }
}
</script>

<style scoped>
.keyword{
  padding-top: .2rem;
  font-size: .34rem;
  font-weight: 510;
}

.content{
  display: flex;
  margin-top: .2rem;
}

.title{
  width: 5%;
  color: #000;
  margin-left: .12rem;
}

.option{
  color: rgba(0, 0, 0, 0.5);
  width: 18%;
  text-decoration: underline;
  cursor: pointer;
}

.option:hover{
  color: red;
}

.tail{
  width: 10%;
  margin-top: .1rem;
  color: red;
  font-size: .23rem;
  font-weight: bold;
  cursor: pointer;
}

.moreContent{
  border-top: 1px solid rgba(0, 0, 0, 0.3);
  border-bottom: 1px solid rgba(0, 0, 0, 0.3);
  margin-top: .1rem;
  margin-bottom: .1rem;
  padding-top: .1rem;
  padding-bottom: .1rem;
}
</style>

<style>
.fade-enter-active, .fade-leave-active {
  transition: all .3s;
  height: 93px;
  opacity: 1;
}
.fade-enter, .fade-leave-to {
  opacity: 0;
  height: 0;
}

</style>
