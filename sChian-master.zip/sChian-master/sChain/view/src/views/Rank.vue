<template>
  <div class="content" v-loading="loading">
    <div>
      <Card v-for="(item, i) in cards"
            :key="item.ID"
            :index="i + 1"
            :data="item"/>
      <el-pagination
        style="margin-bottom: .2rem;"
        :small="isPhone()"
        @current-change="handleCurrentChange"
        :current-page.sync="form.page"
        :page-size="20"
        layout="total, prev, pager, next"
        :total="count"/>
    </div>
  </div>
</template>

<script>
import { cardRank } from '@/api/card'
import {isPhone} from '@/utils/utils'

export default {
  name: 'Rank',
  components: {
    DynamicsLoad: () => import('./components/DynamicsLoad'),
    Card: () => import('./components/Card')
  },
  data () {
    return {
      cards: [],
      loading: false,
      count: 0,
      form: {
        page: 1
      }
    }
  },
  created () {
    this.getCards()
  },
  methods: {
    isPhone,
    load () {
      this.form.page += 1
      this.getCards()
    },
    handleCurrentChange (val) {
      this.form.page = val
      this.getCards()
    },
    async getCards () {
      this.loading = true
      const data = (await cardRank(this.form)).data
      this.cards = this.cards.concat(data.items)
      if (data.count > 200) {
        data.count = 200
      }
      this.count = data.count
      this.loading = false
    }
  }
}
</script>

<style scoped>
.content{
  height: 100%;
  position: relative;
  width: 100%;
  font-size: .2rem;
  background: #fff;
}
</style>
