<template>
  <div class="message">
    <OutLine>
      <span slot="left">
        <my-link style="color: #409eff" :open="getHttpCard(form.id)">{{ getCard(form.id) }}</my-link>
        的留言板
      </span>
    </OutLine>

    <div class="textarea">
      <el-input placeholder="请文明发言、理性评论"
                ref="text"
                v-model="text"
                type="textarea"
                :rows="2"
                v-show="isLogin">
      </el-input>
      <div style="margin-top: .1rem;text-align: right">
        <span style="margin-right: .24rem;font-size: .2rem;">
          <span style="color: firebrick">{{ count }}</span>
          <span style="color: rgba(0, 0, 0, 0.2);">条留言</span>
        </span>
        <el-button type="info"
                   @click="addMsg"
                   v-show="isLogin">
          修改/发布
        </el-button>
        <el-button type="danger"
                   @click="delMy"
                   v-show="isLogin"
                   :disabled="currentMsg.ID === -1">
          删除
        </el-button>
      </div>
    </div>

    <EmptyContent content='暂无留言内容' v-if="list.length === 0" />
    <div class="messageList" v-else>
      <DynamicsLoad :items="list" :per="20" @load="loadMsg">
          <div class="messageItem" slot-scope="scope">
            <div class="messageId">
              <my-link style="text-decoration: none;color: #409eff;"
                       :open="getHttpCard(scope.item.Left)">
                {{ getCard(scope.item.Left) }}
              </my-link>
            </div>
            <div class="messageCnt" v-html="replaceCardContent(scope.item.Content)" v-if="!scope.item.CntShort">
            </div>
            <div v-else>
              <span v-html="replaceCardContent(scope.item.Content.substring(0, 150)) + '...'"></span>
              <span @click="scope.item.CntShort = false" style="color: #409EFF;cursor: pointer">全文</span>
            </div>
            <div style="padding-top: .12rem">
              <span class="messageDate">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.item.Updated) }}</span>
              <span class="messageComplaint" @click="jumpManageCard">投诉</span>
              <span class="messageDel" @click="delOther(scope.item.ID)" v-if="isCurrent">删除</span>
            </div>
          </div>
      </DynamicsLoad>
    </div>
  </div>
</template>

<script>

import {leaveMsgAdd, leaveMsgDelMy, leaveMsgDelOther, leaveMsgList} from '@/api/leave_msg'
import {getCard, getHttpCard, getManageHttpCard, replaceCardContent} from '@/utils/card'
import {unixFormat} from '@/utils/date'
import MyLink from '@/views/components/MyLink.vue'

export default {
  name: 'LeaveMessage',
  components: {
    MyLink,
    EmptyContent: () => import('./components/EmptyContent.vue'),
    OutLine: () => import('./components/OutLine'),
    DynamicsLoad: () => import('./components/DynamicsLoad.vue')
  },
  data () {
    return {
      form: {
        id: 0,
        page: 1,
        limit: 20
      },
      text: '',
      count: 0,
      list: [],
      currentMsg: { ID: -1 }
    }
  },
  computed: {
    isLogin () {
      return this.$store.getters.username !== ''
    },
    isCurrent () {
      return this.$store.getters.username === this.form.id
    }
  },
  created () {
    this.form.id = this.$route.query.id
    this.getMsgList()
  },
  methods: {
    replaceCardContent,
    getHttpCard,
    unixFormat,
    getCard,
    // 加载留言数据
    loadMsg () {
      this.form.page++
      this.getMsgList()
    },
    // 获取留言数据
    async getMsgList () {
      const data = (await leaveMsgList(this.form)).data
      const items = data.items || []
      for (const item of items) {
        item.CntShort = item.Content.length > 150
      }
      this.list = this.list.concat(items)
      this.count = data.count || 0
      if (this.currentMsg.ID === -1) {
        this.currentMsg = data.current || { ID: -1, Content: '' }
      }
    },
    // 根据ID获取下标
    indexOfListById (id) {
      for (let i = 0; i < this.list.length; i++) {
        if (this.list[i].ID === id) {
          return i
        }
      }
      return -1
    },
    // 添加留言
    async addMsg () {
      if (this.text.length === 0) {
        this.$refs.text.focus()
        return
      }
      if (this.text.length > 500) {
        this.$message.warning('留言过长,请删除至500个字符以内')
        return
      }
      const data = (await leaveMsgAdd({right: this.form.id, content: this.text})).data
      if (this.currentMsg.ID === -1) {
        this.currentMsg = data
        if (this.list.length === 0) {
          this.list.push(data)
        } else {
          this.list.push(this.list[0])
          this.$set(this.list, 0, data)
        }
      } else {
        const index = this.indexOfListById(data.ID)
        this.$set(this.list, index, data)
      }
      this.$message.success('留言成功')
    },
    // 删除别人的留言
    async delOther (id) {
      await leaveMsgDelOther({id: id})
      const index = this.indexOfListById(id)
      if (index >= 0) {
        this.list.splice(index, 1)
      }
      this.$message.success('留言已删除')
    },
    // 删除自己的留言
    async delMy () {
      if (this.currentMsg.ID === -1) {
        return
      }
      await leaveMsgDelMy({id: this.currentMsg.ID})
      const index = this.indexOfListById(this.currentMsg.ID)
      if (index >= 0) {
        this.list.splice(index, 1)
      }
      this.$message.success('留言已删除')
    },
    // 跳转至管理员名片
    jumpManageCard () {
      location.href = getManageHttpCard() + '/#/home'
    }
  }
}
</script>

<style scoped>
.message{
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}

.textarea{
  margin-top: .2rem;
  margin-right: .4rem;
}

.messageList{
  width: 95%;
  margin-top: .4rem;
  padding: .2rem;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  font-size: .2rem;
}

.messageItem{
  padding-bottom: .4rem;
}

.messageId{
  padding-bottom: .12rem;
}

.messageDate{
  color: rgba(0, 0, 0, 0.3);
  font-size: .18rem;
}

.messageDel{
  color: red;
  cursor: pointer;
  padding-left: .1rem;
  font-size: .18rem;
}

.messageComplaint {
  color: rgba(0, 0, 0, 0.5);
  cursor: pointer;
  font-size: .18rem;
  padding-left: .1rem;
}

.messageCnt{
}
</style>
