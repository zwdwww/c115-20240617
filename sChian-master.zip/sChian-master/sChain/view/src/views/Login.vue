<template>
  <div>
    <LoginPC v-if="!isPhone()" />
    <LoginPhone v-else />
  </div>
</template>

<script>
import { isPhone } from '@/utils/utils'

export default {
  name: 'Login',
  components: {
    LoginPC: () => import('@/views/components/LoginPC.vue'),
    LoginPhone: () => import('@/views/components/LoginPhone.vue')
  },
  created () {
    console.log(this.isPhone())
  },
  methods: {
    isPhone
  }
}
</script>

<style>
</style>
