<template>
  <div>
    <RegisterPhone v-if="isPhone()" />
    <RegisterPC v-else />
  </div>
</template>

<script>
import { isPhone } from '@/utils/utils'

export default {
  name: 'Register',
  components: {
    RegisterPC: () => import('@/views/components/RegisterPC.vue'),
    RegisterPhone: () => import('@/views/components/RegisterPhone.vue')
  },
  methods: {
    isPhone
  }
}
</script>

<style>
</style>
