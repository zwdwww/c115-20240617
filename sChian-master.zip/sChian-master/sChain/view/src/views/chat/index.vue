<template>
  <div class="content">
    <el-collapse v-model="activeNames">
      <el-collapse-item name="groupMy">
        <template slot="title">
          <div class="title">我创建的群聊（{{ groupMy.length }}）</div>
        </template>
        <div class="item"
             @click="jumpMsg(item, 'my')"
             :key="i" v-for="(item, i) in groupMy">
          {{ item.Uid }}
        </div>
      </el-collapse-item>
      <el-collapse-item name="groupOther">
        <template slot="title">
          <div class="title">我加入的群聊（{{ groupOther.length }}）</div>
        </template>
        <div  class="item"
              @click="jumpMsg(item, 'other')"
              :key="i" v-for="(item, i) in groupOther">
          {{ item.Uid }}
        </div>
      </el-collapse-item>
      <el-collapse-item name="private">
        <template slot="title">
          <div class="title">私聊（{{ privateList.length }}）</div>
        </template>
        <div  class="item"
              @click="jumpMsg(item, 'private')"
              :key="i" v-for="(item, i) in privateList">
          {{ item.Uid }}
        </div>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script>
import {chatList} from '@/api/chat'

export default {
  name: 'Chat',
  data () {
    return {
      activeNames: [],
      groupMy: [],
      groupOther: [],
      privateList: []
    }
  },
  created () {
    chatList().then((data) => {
      this.groupMy = data.data.GroupMy || []
      this.groupOther = data.data.GroupOther || []
      this.privateList = data.data.Private || []
    })
  },
  methods: {
    jumpMsg (item, type) {
      let name = ''
      if (type === 'my') {
        name = this.$store.getters.username.toString()
      } else if (type === 'other') {
        name = item.Uid.toString()
      } else {
        name = item.Uid.toString()
      }
      this.$router.push({ name: 'Msg', params: { id: item.Sid, name: name, type: type } })
    }
  }
}
</script>

<style scoped>
.content{
  width: 95%;
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}

.title{
  font-size: .22rem;
  color: rgba(0, 0, 0, 0.7);
}

.item {
  color: rgba(0, 0, 0, 0.5);
  font-size: .2rem;
  padding-left: .2rem;
  padding-bottom: .1rem;
  border-bottom: 1px solid #EBEEF5;;
  cursor: pointer;
}
</style>
