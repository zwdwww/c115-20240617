<template>
  <div>
    <JwChat-index
      width="100%"
      height="calc(100vh - 1.2rem)"
      ref="jwChat"
      v-model="inputMsg"
      :config="config"
      :taleList="taleList"
      :scrollType="scrollType"
      :toolConfig="tool"
      :showRightBox="false"
      @enter="bindEnter"
      @clickTalk="talkEvent"
    >
      <template slot="downBtn">
        <div></div>
      </template>
      <template slot="header">
        <i style="cursor: pointer;font-size: 14px"
           class="el-icon-arrow-left"
           @click="$router.back()">
        </i>

        <div class="my-header">
          <span>{{ session.name }}</span>
          <span v-if="session.isGroup">的群聊（{{ session.peoples }}）</span>
        </div>
      </template>
    </JwChat-index>
  </div>
</template>

<script>

import {sendMsg, register, newMsg, history, groupCount} from '@/api/chat'
import {getHttpCard} from '@/utils/card'
import {dateFormat, unixFormat} from '@/utils/date'

export default {
  data () {
    return {
      session: {
        name: '',
        peoples: 0,
        id: '',
        isGroup: false
      },
      timeoutId: 0,
      scrollType: 'scroll',
      inputMsg: '',
      taleList: [],
      headSculpture: require('@/assets/user.png'),
      tool: {
        callback: this.toolEvent
      },
      config: {
        historyConfig: {
          show: true,
          callback: this.bindLoadHistory,
          page: 1,
          limit: 20
        }
      }
    }
  },
  created () {
    const params = this.$route.params
    this.session.name = params.name || ''
    this.session.id = params.id || ''
    this.session.peoples = params.peoples || 0
    this.session.isGroup = params.type === 'my' || params.type === 'other'

    if (this.session.id === '') {
      this.$router.back()
      return
    }

    // 获取群人数
    groupCount({ sid: this.session.id }).then((resp) => {
      this.session.peoples = resp.data || 0
    })

    // 加载历史消息
    this.bindLoadHistory()
    // 注册会话,并接收最新信息
    register({ sid: params.id }).then(() => {
      this.getNewMsg()
    })
  },
  mounted () {
    this.setChatMsgCss()
  },
  beforeDestroy () {
    if (this.timeoutId !== 0) {
      window.clearTimeout(this.timeoutId)
    }
    console.log('beforeDestroy', this.timeoutId)
  },
  methods: {
    // 修改聊天框CSS
    setChatMsgCss () {
      let msgBody = document.getElementsByClassName('web__main')[0]
      msgBody.setAttribute('style', 'width:100%;padding:5px')
    },
    async bindLoadHistory () {
      if (!this.config.historyConfig.show) {
        this.$nextTick(() => {
          this.config.historyConfig.show = false
          this.$refs.jwChat.finishPullDown()
        })
        return
      }
      const form = { sid: this.session.id, page: this.config.historyConfig.page, limit: this.config.historyConfig.limit }
      const data = (await history(form)).data || []
      const items = []
      for (const item of data) {
        items.push({
          date: unixFormat('YYYY/mm/dd HH:MM:SS', item.Created),
          text: { text: item.Msg },
          mine: item.Uid === this.$store.getters.username,
          name: item.Uid,
          img: this.headSculpture
        })
      }
      this.taleList = this.taleList.concat(items)
      this.config.historyConfig.page++
      if (items.length < this.config.historyConfig.limit) {
        this.$nextTick(() => {
          this.config.historyConfig.show = false
          this.$refs.jwChat.finishPullDown()
        })
      }
    },
    async bindEnter () {
      const msg = this.inputMsg
      if (!msg) return
      await sendMsg({ sid: this.session.id, msg: msg })
      const msgObj = {
        date: dateFormat('YYYY/mm/dd HH:MM:SS', new Date()),
        'text': { 'text': msg },
        'mine': true,
        'name': this.$store.getters.username.toString(),
        'img': this.headSculpture
      }
      this.taleList.push(msgObj)
    },
    // 获取最新信息
    async getNewMsg () {
      const data = (await newMsg({ sid: this.session.id })).data
      const { items, wait } = data
      for (const item of items) {
        this.taleList.push({
          text: { text: item.Msg },
          mine: item.Uid === this.$store.getters.username,
          name: item.Uid,
          img: this.headSculpture
        })
      }
      console.log('wait', wait)
      this.timeoutId = setTimeout(this.getNewMsg, wait)
    },
    toolEvent (type, obj) {},
    // 点击用户会话框,跳转到主页
    talkEvent (play) {
      if (play.data.name) {
        window.clearTimeout(this.timeoutId)
        location.href = getHttpCard(play.data.name)
      }
    }
  }
}
</script>

<style>
.my-header{
  width: 100%;
  text-align: center;
  font-size: 14px;
}
</style>
