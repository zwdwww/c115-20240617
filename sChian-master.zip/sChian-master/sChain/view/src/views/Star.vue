<template>
  <div class="content">
    <div v-if="cards.length === 0">
      <EmptyContent content="暂无关注的名片" />
    </div>
    <div v-else>
      <Card :key="i" :data="v" v-for="(v, i) in cards"/>
    </div>
  </div>
</template>

<script>
import { starsCard } from '@/api/card'

export default {
  name: 'Star',
  components: {
    EmptyContent: () => import('@/views/components/EmptyContent'),
    Card: () => import('./components/Card')
  },
  data () {
    return {
      domain: '',
      cards: []
    }
  },
  created () {
    this.getCards()
  },
  methods: {
    async getCards () {
      this.cards = (await starsCard()).data
    }
  }
}
</script>

<style scoped>
.content{
  height: 100%;
  position: relative;
  width: 100%;
  font-size: .2rem;
  background: #fff;
}
</style>
