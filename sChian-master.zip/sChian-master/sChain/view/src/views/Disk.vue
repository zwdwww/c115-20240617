<template>
  <div class="disk" v-loading="uploadLoading" element-loading-text="文件上传中...">
    <OutLine path="/home">
      <span slot="left">
        <span  style="cursor: pointer;" @click="backParent" v-if="currentNode.path !== '/'">{{ currentNode.name }}</span>
        <span v-else>
          <my-link style="color: #409eff" :open="getHttpCard(id)">{{ getCard(id) }}</my-link>
          的链盘
        </span>
      </span>
      <div slot="right" class="outlineRight">
        <span v-if="currentNode.path !== '/' && isCurrent">
          <el-upload
            :action="uploadAction"
            :data="uploadData"
            :headers="headers"
            :show-file-list="false"
            :on-success="uploadSuccess"
            :on-error="uploadError"
            :before-upload="beforeUpload"
            name="File"
           >
            上传
          </el-upload>
        </span>
        <span v-if="isCurrent && currentNode.path !== '/'" @click="createFolder">创建文件夹</span>
        <span v-if="isCurrent">剩余空间({{ surplus }}MB)</span>
      </div>
    </OutLine>

    <EmptyContent content='文件夹为空' v-if="currentNode.children.length === 0" />

    <div style="margin-top: .4rem" v-else>
      <div class="lineBody" :key="i" v-for="(item,i) in currentNode.children">
        <div style="width: 92%;"
             @click="clickFileOrDirect(item)"
             class="lineItemLeft">
          <img :src=img[item.img] alt="" />
          <span style="text-overflow: ellipsis;overflow: hidden;white-space: nowrap"
                class="lineName">{{ item.name }}
          </span>
          <span v-if="item.desc" class="lineSpecial">{{ item.desc }}</span>
        </div>
        <div v-if="item.showOption" class="lineItemRight">
          <FavDropDown :options="getOptions(item.type)" @click="optionEvent($event, item)">
            <i class="el-icon-more-outline itemMore"></i>
          </FavDropDown>
        </div>
      </div>
    </div>

    <div ref="pdf" v-if="pdfUrl !== ''" class="modal" @scroll="pdfScrollMove">
      <i style="position: fixed;right: 2%;top: 2%;cursor: pointer;font-size: 0.5rem"
         class="el-icon-close"
         @click="closePdf">
      </i>
      <pdf class="modal-content"
           :src="pdfUrl"
           :page="i"
           :key="i"
           v-loading="pdfProgress[i].loading"
           :element-loading-text="pdfProgress[i].ratio"
           element-loading-background="rgba(0, 0, 0, 0)"
           v-for="i in curPages"
           @progress="pdfLoadProgress(i, $event)"
           @page-loaded="pdfLoading = false"></pdf>
    </div>

    <el-dialog
      title="移动文件或者文件夹"
      :visible.sync="dialogVisible"
      width="5rem">
      <div style="text-align: center;margin-bottom: .2rem;margin-top: .2rem">
        <el-tree :data="elTree"  @node-click="(val) => { moveToNode = val }"></el-tree>
        <el-button type="success" @click="moveFileEvent">确认移动</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getCard, getHttpCard} from '@/utils/card'
import { Tree, Node } from '@/utils/tree'
import {getToken} from '@/utils/auth'
import {diskLs, diskMove, diskOrder, diskPdfPages, diskRename, diskRm, diskSurplus, newFolder} from '@/api/disk'
import pdf from 'vue-pdf'

export default {
  name: 'Disk',
  data () {
    return {
      id: '',
      pdfUrl: '',
      curPages: 0,
      pdfNumPages: 0,
      pdfLoading: false,
      pdfProgress: {1: {loading: false, ratio: ''}, 2: {loading: false, ratio: ''}},
      uploadLoading: false,
      surplus: 0,
      diskSize: 0,
      dialogVisible: false,
      uploadAction: process.env.VUE_APP_BASE_API + '/disk/upload',
      img: {
        dir: require('../assets/dir.png'),
        docx: require('../assets/docs.png'),
        unknown: require('..//assets/unknown.png')
      },
      moveNode: null,
      moveToNode: null,
      tree: new Tree(),
      elTree: [],
      currentNode: {}
    }
  },
  components: {
    pdf,
    OutLine: () => import('./components/OutLine'),
    MyLink: () => import('./components/MyLink'),
    FavDropDown: () => import('./components/FavDropDown'),
    EmptyContent: () => import('./components/EmptyContent')
  },
  created () {
    this.id = this.$route.query.id

    if (this.isCurrent) {
      this.syncSurplus()
    }

    this.tree.root.add(new Node(-1, 'public', '公盘', 'dir', ''))
    this.tree.root.add(new Node(-2, 'private', '私盘', 'dir', ''))
    this.tree.root.add(new Node(-3, 'group', '群盘', 'dir', ''))
    this.currentNode = this.tree.root
  },
  mounted () {
    // 根据query打开指定的目录
    if (this.$route.query.path) {
      this.openCurrentQueryPath(true)
    }
  },
  computed: {
    // 上传文件header
    headers () {
      return { Token: getToken() }
    },
    // 上传文件data
    uploadData () {
      return { parent: this.currentNode.path }
    },
    isCurrent () {
      return this.id === this.$store.getters.username
    }
  },
  methods: {
    getCard,
    getHttpCard,
    getOptions (type) {
      if (this.isCurrent) {
        if (type === 'dir') {
          return ['打开', '上移一位', '下移一位', '重命名', '移动', '删除']
        } else {
          return ['打开', '分享', '下载', '复制链接', '上移一位', '下移一位', '重命名', '移动', '删除']
        }
      } else {
        if (type === 'dir') {
          return ['打开']
        } else {
          return ['打开', '分享', '下载', '复制链接']
        }
      }
    },
    // 打开当前的query路径
    async openCurrentQueryPath (isFirst) {
      for (const node of this.currentNode.children) {
        if (node.type === 'dir' && this.$route.query.path.startsWith(node.path)) {
          console.log('open', node.path)
          await this.clickFileOrDirect(node, false)
          await this.openCurrentQueryPath(false)
          break
        }
      }
      if (isFirst) {
        if (this.$route.query.to) {
          for (const node of this.currentNode.children) {
            if (node.md5 === this.$route.query.to) {
              await this.clickFileOrDirect(node, false)
            }
          }
        }
      }
    },
    // pdf加载进度条
    pdfLoadProgress (page, ratio) {
      if (ratio === 1) {
        this.pdfProgress[page].loading = false
        this.pdfProgress[page].ratio = '100%'
        // Scroll滑动条还没出来, 继续加载出来一页
        if (this.$refs.pdf.scrollTop === 0 && this.curPages < this.pdfNumPages) {
          setTimeout(this.pdfScrollMove, 500)
        }
      } else {
        this.pdfProgress[page].loading = true
        this.pdfProgress[page].ratio = (ratio * 100).toFixed(2) + '%'
      }
    },
    // pdf滚动,动态加载
    pdfScrollMove () {
      if (this.$refs.pdf.children.length <= 1) {
        return
      }
      const clientHeight = this.$refs.pdf.children[1].clientHeight
      const height = clientHeight * (this.curPages - 1)
      const scrollTop = this.$refs.pdf.scrollTop
      if (height - scrollTop < (clientHeight * 1.5) && this.curPages < this.pdfNumPages && !this.pdfLoading) {
        this.pdfLoading = true
        this.curPages += 1
        this.$set(this.pdfProgress, this.curPages, { loading: false, ratio: '' })
      }
    },
    // 排序响应的文件
    handleItems (data) {
      const nodes = []
      const items = data.items || []
      const itemsOrder = {}
      const order = data.order || []
      for (let i = 0; i < order.length; i++) {
        itemsOrder[order[i]] = i
      }

      items.sort(function (a, b) {
        return (itemsOrder[a.ID] || 0) - (itemsOrder[b.ID] || 0)
      })

      for (const item of items) {
        nodes.push(new Node(item.ID, item.FileName, item.FileName, item.FileType, item.FileMd5))
      }
      return nodes
    },
    addRouterQuery (k, v) {
      const query = { ...this.$route.query }
      if (v === '') {
        delete query[k]
        this.$router.push({query: query})
      } else if (query[k] !== v) {
        query[k] = v
        this.$router.push({query: query})
      }
    },
    // 打开文件夹
    async clickOpenDirect (node, addQuery = true) {
      if (!node.init) {
        const data = (await diskLs({ path: node.path, id: this.id })).data
        node.init = true
        const nodes = this.handleItems(data)
        for (const node1 of nodes) {
          node.add(node1)
        }
      }
      this.currentNode = node
      if (addQuery) {
        this.addRouterQuery('path', node.path)
      }
    },
    // 打开文件
    async clickOpenFile (node) {
      const pages = (await diskPdfPages({md5: node.md5})).data
      if (pages === -1) {
        this.$message.warning('正在解析文档中,请稍等')
        return
      } else if (pages === -2) {
        this.$message.error('文档解析异常,无法在线浏览')
        return
      }
      this.curPages = 1
      this.pdfNumPages = pages
      this.pdfUrl = `${process.env.VUE_APP_BASE_API}/disk/pdf?to=${node.md5}`
      this.addRouterQuery('to', node.md5)
    },
    // 点击文件或者文件夹
    async clickFileOrDirect (node, addQuery = true) {
      if (node.type === 'dir') {
        await this.clickOpenDirect(node, addQuery)
      } else if (node.type === 'docx') {
        await this.clickOpenFile(node, addQuery)
      } else {
        this.$message.warning('暂不支持在线浏览该类型文件')
      }
    },
    // 新建文件夹
    createFolder () {
      this.$prompt('请输入文件夹名', '新建文件夹', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value === '') {
          this.$message.warning('文件夹名不能为空')
          return
        }
        if (value.includes('/')) {
          this.$message.warning('文件夹名不能包含 /')
          return
        }
        if (this.currentNode.checkDirName(value)) {
          this.$message.warning('文件夹已存在')
          return
        }

        newFolder({ parent: this.currentNode.path, name: value }).then((resp) => {
          const data = resp.data
          this.currentNode.addFirst(new Node(data.ID, data.FileName, data.FileName, data.FileType, ''))
          this.setCurrentOrder()
        })
      })
    },
    closePdf () {
      this.pdfUrl = ''
      this.addRouterQuery('to', '')
    },
    // 回到上一级
    backParent () {
      this.currentNode = this.currentNode.parent
      if (!this.currentNode.init) {
        this.clickOpenDirect(this.currentNode, false)
      }
      if (this.currentNode.path === '/') {
        this.addRouterQuery('path', '')
      } else {
        this.addRouterQuery('path', this.currentNode.path)
      }
    },
    // 同步剩余空间
    async syncSurplus () {
      const size = (await diskSurplus()).data || 0
      this.diskSize = size
      this.surplus = (size / 1024 / 1024).toFixed(2)
    },
    // 文件上传成功
    uploadSuccess (response) {
      const data = response.data
      this.currentNode.add(new Node(data.ID, data.FileName, data.FileName, data.FileType, data.FileMd5))
      this.syncSurplus()
      this.setCurrentOrder()
      this.uploadLoading = false
      this.$message.success('上传成功')
    },
    // 文件上传失败
    uploadError () {
      this.$message.error('上传失败,请检查文件是否太大,上传的文件应小于100mb')
    },
    // 上传之前检查
    beforeUpload (file) {
      if (file.size > this.diskSize) {
        this.$message.warning('空间不足,请清理多余文件或升级存储空间')
        return false
      }
      this.uploadLoading = true
    },
    // 获取Index
    indexOfListById (id) {
      for (let i = 0; i < this.currentNode.children.length; i++) {
        if (this.currentNode.children[i].id === id) {
          return i
        }
      }
      return -1
    },
    // 设置当前目录Order
    async setCurrentOrder () {
      if (this.currentNode.path === '/') {
        return
      }
      const order = []
      for (const item of this.currentNode.children) {
        order.push(item.id)
      }
      await diskOrder({ path: this.currentNode.path, order: order })
    },
    // 移动文件
    async moveFileEvent () {
      if (this.moveNode.id === this.moveToNode.node.id) {
        this.$message.error('移动异常,请重新选项移动目录')
        return
      }
      if (this.moveToNode.node.checkDirName(this.moveNode.name)) {
        this.$message.error('移动异常,目录已存在同名文件夹')
        return
      }
      await diskMove({id: this.moveNode.id, path: this.moveToNode.node.path})
      this.currentNode.children.splice(this.indexOfListById(this.moveNode.id), 1)

      let moveToOrder = []
      if (this.moveNode.type === 'dir') {
        moveToOrder = [this.moveNode.id].concat(this.moveToNode.node.getChildrenId())
      } else {
        moveToOrder = this.moveToNode.node.getChildrenId()
        moveToOrder.push(this.moveNode.id)
      }
      await diskOrder({
        path: this.moveToNode.node.path,
        order: moveToOrder })
      this.moveToNode.node.reset()

      await this.setCurrentOrder()
      this.dialogVisible = false
      this.$message.success('移动成功')
    },
    // 选项带年纪
    async optionEvent (option, node) {
      let index = -1
      let swap = null

      switch (option) {
        case '打开':
          await this.clickFileOrDirect(node)
          return
        case '分享':
        case '复制链接':
          const href = location.href + `&to=${node.md5}`
          await this.$copyText(href)
          this.$message.success('复制成功')
          return
        case '下载':
          const x = new window.XMLHttpRequest()
          x.open('GET', `${process.env.VUE_APP_BASE_API}/disk/download?to=${node.md5}`, true)
          x.responseType = 'blob'
          x.onload = () => {
            const url = window.URL.createObjectURL(x.response)
            const a = document.createElement('a')
            a.href = url
            a.target = '_blank'
            a.download = node.name
            a.style.display = 'none'
            document.body.append(a)
            a.click()
            document.body.removeChild(a)
          }
          x.send()
          return
        case '上移一位':
          index = this.indexOfListById(node.id)
          if (index >= 0 && index !== 0) {
            swap = this.currentNode.children[index - 1]
            this.$set(this.currentNode.children, index - 1, this.currentNode.children[index])
            this.$set(this.currentNode.children, index, swap)
            await this.setCurrentOrder()
          }
          return
        case '下移一位':
          index = this.indexOfListById(node.id)
          if (index >= 0 && index !== (this.currentNode.children.length - 1)) {
            swap = this.currentNode.children[index + 1]
            this.$set(this.currentNode.children, index + 1, this.currentNode.children[index])
            this.$set(this.currentNode.children, index, swap)
            await this.setCurrentOrder()
          }
          return
        case '重命名':
          this.$prompt('重命名', '提示', {
            confirmButtonText: '确认',
            cancelButtonText: '取消'
          }).then(({ value }) => {
            if (value === '') {
              return
            }
            if (value.includes('/')) {
              this.$message.warning('文件名不能包含 /')
              return
            }
            if (this.currentNode.checkDirName(value)) {
              this.$message.warning('文件夹已存在')
              return
            }
            if (value.length > 64) {
              this.$message.warning('文件名过长')
              return
            }
            diskRename({ id: node.id, new: value }).then(() => {
              node.name = value
              this.$message.success('修改成功')
            })
          })
          return
        case '移动':
          this.elTree = this.tree.elementTree()
          this.moveNode = node
          this.dialogVisible = true
          return
        case '删除':
          diskRm({ id: node.id }).then(() => {
            this.currentNode.children.splice(this.indexOfListById(node.id), 1)
            this.syncSurplus()
            this.setCurrentOrder()
            this.$message.success('删除成功')
          })
      }
    }
  }
}
</script>

<style scoped>
.disk{
  padding: .2rem 0 0 .5rem;
  text-align: left;
  font-size: .24rem;
}

.lineBody{
  display: flex;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}

.lineItemLeft{
  display: flex;
  align-items: center;
  color: #666;
  cursor: pointer;
  width: 92%;
}

.lineItemRight{
  display: flex;
  width:8%;
  align-items: center;
}

.lineName{
  padding-left: .3rem;
}

.lineSpecial{
  padding-left: 1rem;
  color: red;
}

img{
  width: 1rem;
}

.itemMore{
  font-size: .3rem;
  color: rgba(0, 0, 0, 0.4);
  transform: rotate(90deg);
  cursor: pointer;
}

.outlineRight{
  width: 60%;
}

.outlineRight>span{
  float: right;
  padding-right: 0.6rem;
  color: rgba(0, 0, 0, 0.6);
  cursor: pointer;
}

.modal{
  align-items: center;
  justify-content: center;
  opacity: 1;
  position: fixed;
  z-index: 20001;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0,0.9);
  transition: opacity ease 0.3s;
}

.modal-content{
  left: 10%;
  right: 10%;
  width: 80%;
  overflow: hidden;
}

.modal-less{
}
</style>
