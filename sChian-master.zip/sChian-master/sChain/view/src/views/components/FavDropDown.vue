<template>
<!-- 收藏夹下拉菜单 -->
  <span>
    <span @click="showDropDown" v-clickoutside="closeDropDown">
      <slot></slot>
    </span>
    <ul ref="menu" v-if="show">
      <li @click="clickElement(item)"
          @mouseenter="enterOption=true"
          @mouseleave="enterOption=false"
          :key="i"
          v-for="(item, i) in options">
        {{ item }}
      </li>
    </ul>
  </span>
</template>

<script>
export default {
  props: {
    options: {
      type: Array,
      default: () => ([])
    }
  },
  name: 'DropDown',
  data () {
    return {
      show: false,
      enterOption: false
    }
  },
  methods: {
    // 选项点击事件
    clickElement (option) {
      this.show = false
      this.$emit('click', option)
    },
    // 点击其他位置关闭DropDown
    closeDropDown () {
      if (this.show && !this.enterOption) {
        this.show = false
      }
    },
    // 显示DropDown
    showDropDown (e) {
      if (this.show) {
        return
      }
      this.show = true
      const clientX = e.clientX
      const clientY = e.clientY
      this.$nextTick(() => {
        const width = this.$refs.menu.clientWidth
        this.$refs.menu.style.top = clientY + 'px'
        this.$refs.menu.style.left = clientX - width + 'px'
      })
    }
  }
}
</script>

<style scoped>
ul{
  color: #666;
  font-size: .18rem;
  position: absolute;
  z-index: 2029;
  list-style: none;
  text-align: center;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
}

li{
  padding: .02rem .02rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.3);
  cursor: pointer;
}

li:hover{
  color: #409EFF;
}
</style>
