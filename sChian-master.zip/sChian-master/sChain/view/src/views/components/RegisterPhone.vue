<template>
  <div class="content">
    <div>
      <el-button class="changeBtn" @click="form.type = '0'">手机号注册ID</el-button>
    </div>
    <div>
      <el-button class="changeBtn" @click="form.type = '1'">其他数字注册ID（非手机号）</el-button>
    </div>

    <div style="margin-top: .4rem"></div>

    <el-card>
      <div>
        <el-form v-show="form.type === '0'" ref="form1" :rules="rules1" :model="form">
          <el-form-item prop="phone">
            <el-input size="medium" ref="phone1" placeholder="请输入手机号码"  v-model="form.phone">
              <template slot="append">.{{ getDomain() }}</template>
            </el-input>
          </el-form-item>
          <el-form-item prop="verifyCode">
            <el-input size="medium" placeholder="请输入验证码"  v-model="form.verifyCode">
              <el-button type="text" slot="append" @click="sendMsg">{{ verifyCodeBtn }}</el-button>
            </el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input size="medium" placeholder="请输入密码" :type="pwdView.v1" v-model="form.password">
              <i style="cursor: pointer" slot="suffix" class="el-input__icon el-icon-view" @click="changePwdView('v1')"></i>
            </el-input>
          </el-form-item>
          <el-form-item prop="verifyPassword">
            <el-input size="medium" placeholder="请再次确认密码" :type="pwdView.v2" v-model="form.verifyPassword">
              <i style="cursor: pointer" slot="suffix" class="el-input__icon el-icon-view" @click="changePwdView('v2')"></i>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-checkbox style="margin-left: 35%" v-model="checked">
              <span style="font-size: .28rem;">同意服务条款</span>
            </el-checkbox>
            <el-button style="width: 100%;padding: .26rem;font-size: .26rem"
                       type="primary"
                       :disabled="!checked"
                       @click="register">确认注册</el-button>
          </el-form-item>
        </el-form>

        <el-form v-show="form.type === '1'" ref="form2" :rules="rules2" :model="form">
          <el-form-item prop="username">
            <el-input size="medium" placeholder="7-13位数字/QQ/电话(非手机号)"  v-model="form.username">
              <template slot="append">.{{ getDomain() }}</template>
            </el-input>
          </el-form-item>
          <el-form-item prop="phone">
            <el-input size="medium" ref="phone2" placeholder="请输入手机号码"  v-model="form.phone"></el-input>
          </el-form-item>
          <el-form-item prop="verifyCode">
            <el-input size="medium" placeholder="请输入验证码"  v-model="form.verifyCode">
              <el-button type="text" slot="append" @click="sendMsg">{{ verifyCodeBtn }}</el-button>
            </el-input>
          </el-form-item>
          <el-form-item  prop="password">
            <el-input size="medium" placeholder="请输入密码" :type="pwdView.v3" v-model="form.password">
              <i style="cursor: pointer" slot="suffix" class="el-input__icon el-icon-view" @click="changePwdView('v3')"></i>
            </el-input>
          </el-form-item>
          <el-form-item  prop="verifyPassword">
            <el-input size="medium" placeholder="请再次确认密码" :type="pwdView.v4" v-model="form.verifyPassword">
              <i style="cursor: pointer" slot="suffix" class="el-input__icon el-icon-view" @click="changePwdView('v4')"></i>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-checkbox style="margin-left: 35%" v-model="checked">
              <span style="font-size: .28rem;">同意服务条款</span>
            </el-checkbox>
            <el-button style="width: 100%;padding: .26rem;font-size: .26rem"
                       type="primary"
                       :disabled="!checked"
                       @click="register">确认注册</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>
import {getDomain, getHttpCard} from '@/utils/card'
import {checkExists, sendRegisterMsg} from '@/api/auth'
import {validateNotPhone, validatePhone} from '@/utils/validate'

export default {
  name: 'RegisterPhone',
  data () {
    const validateAccount = (rule, value, callback) => {
      checkExists({ username: value }).then((data) => {
        if (data.data) {
          return callback(new Error('ID已被注册'))
        }
        return callback()
      })
    }
    const validateVerifyPassword = (rule, value, callback) => {
      if (value !== this.form.password) {
        callback(new Error('两次密码不一致'))
      } else {
        callback()
      }
    }
    return {
      form: {
        username: '',
        phone: '',
        password: '',
        verifyPassword: '',
        verifyCode: '',
        type: '0'
      },
      wait60Seconds: 0,
      timeoutId: 0,
      checked: true,
      loading: false,
      pwdView: {
        'v1': 'password',
        'v2': 'password',
        'v3': 'password',
        'v4': 'password'
      },
      rules1: {
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: validatePhone, trigger: 'blur' },
          { validator: validateAccount, trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码不能小于6位', trigger: 'blur' }
        ],
        verifyPassword: [
          { required: true, message: '请再次确认密码', trigger: 'blur' },
          { validator: validateVerifyPassword, trigger: 'blur' }
        ],
        verifyCode: [
          { required: true, message: '请输入验证码', trigger: 'blur' }
        ]
      },
      rules2: {
        username: [
          { required: true, message: '请输入ID', trigger: 'blur' },
          { min: 7, max: 13, message: '7-13位数字/QQ(非手机号)', trigger: 'blur' },
          { validator: validateNotPhone, trigger: 'blur' },
          { validator: validateAccount, trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: validatePhone, trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码不能小于6位', trigger: 'blur' }
        ],
        verifyPassword: [
          { required: true, message: '请再次确认密码', trigger: 'blur' },
          { validator: validateVerifyPassword, trigger: 'blur' }
        ],
        verifyCode: [
          { required: true, message: '请输入验证码', trigger: 'blur' }
        ]
      }
    }
  },
  destroyed () {
    if (this.timeoutId !== 0) {
      window.clearTimeout(this.timeoutId)
    }
  },
  computed: {
    verifyCodeBtn () {
      if (this.wait60Seconds === 0) {
        return '获取验证码'
      }
      return `${this.wait60Seconds}秒后重新发送`
    }
  },
  methods: {
    getDomain,
    changePwdView (key) {
      if (this.pwdView[key] === 'password') {
        this.pwdView[key] = 'text'
      } else {
        this.pwdView[key] = 'password'
      }
    },
    async sendMsg () {
      const input = { username: this.form.username, phone: this.form.phone }
      if (this.form.type === '0') {
        input.username = input.phone
      }
      if (this.form.phone === '') {
        let phone = this.$refs.phone1
        if (this.form.type === '1') {
          phone = this.$refs.phone2
        }
        phone.focus()
        return
      }
      await sendRegisterMsg(input)
      this.wait60Seconds = 60
      this.countdown()
    },
    // 倒计时开始
    countdown () {
      this.wait60Seconds--
      if (this.wait60Seconds === 0) {
        return
      }
      this.timeoutId = setTimeout(this.countdown, 1000)
    },
    // 注册
    register () {
      const input = { ...this.form }
      if (input.type === '0') {
        input.username = input.phone
      }

      let form = this.$refs.form1
      if (this.form.type === '1') {
        form = this.$refs.form2
      }

      form.validate((valid) => {
        if (valid) {
          this.$store.dispatch('user/register', input).then(() => {
            this.$store.dispatch('tagsView/delAllCachedViews', this.$route)
            this.loading = false
            location.href = getHttpCard(input.username)
          }).catch(() => {
            this.loading = false
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
.content{
  padding: .6rem .1rem;
  text-align: left;
}

.changeBtn{
  width: 100%;
  font-size: .24rem;
  background-color: #F3F5F8FF;
  margin-top: .1rem;
  padding: .2rem;
  color: rgba(0, 0, 0, 0.5);
}
</style>
