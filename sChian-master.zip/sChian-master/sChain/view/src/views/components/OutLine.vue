<template>
  <div class="outline">
    <div class="outlineLeft">
      <i class="el-icon-arrow-left"
         style="cursor: pointer;"
         @click="clickBack"></i>
      <span style="cursor: pointer;"
            @click="clickBack">
          上一级
        </span>
      <i class="el-icon-arrow-left"></i>
      <slot name="left"></slot>
    </div>
    <slot name="right"></slot>
  </div>
</template>

<script>
export default {
  name: 'OutLine',
  props: {
    content: {
      type: String,
      default: ''
    },
    path: {
      type: String,
      default: ''
    }
  },
  methods: {
    clickBack () {
      if (this.path) {
        this.$router.push({path: this.path})
      } else {
        this.$router.back()
      }
    }
  }
}
</script>

<style scoped>
.outline{
  display: flex;
  align-items: center;
  font-size: .16rem;
  color: #666;
}

.outlineLeft{
  width: 40%;
}
</style>
