<template>
  <div class="empty">
    <el-empty :description="content"></el-empty>
  </div>
</template>

<script>
export default {
  name: 'EmptyContent',
  props: {
    content: {
      type: String,
      default: ''
    }
  }
}
</script>

<style scoped>
.empty {
  font-size: .3rem;
  text-align: center;
  padding-top: 1rem;
  color: rgba(0, 0, 0, 0.5);
}
</style>
