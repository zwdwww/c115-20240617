<template>
  <span style="cursor: pointer;" @click="click">
    <slot></slot>
  </span>
</template>

<script>

export default {
  name: 'MyLink',
  props: {
    to: {
      type: String,
      default: ''
    },
    open: {
      type: String,
      default: ''
    },
    jumpLogin: {
      type: Boolean,
      default: false
    },
    jumpQuery: {
      type: String,
      default: ''
    },
    disable: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    isLogin: function () {
      return this.$store.getters.username !== ''
    }
  },
  methods: {
    // 点击链接
    click () {
      if (this.disable) {
        return
      }
      if (this.jumpLogin && !this.isLogin) {
        let query = []
        if (this.to !== '') {
          query.push(`redirect=${this.to}`)
        }
        if (this.jumpQuery !== '') {
          query.push(this.jumpQuery)
        }
        if (query.length !== 0) {
          this.$router.push(`/login?${query.join('&')}`)
        } else {
          this.$router.push(`/login`)
        }
      } else {
        if (this.to !== '') {
          const query = this.$route.query
          if (this.jumpQuery !== '') {
            const items = this.jumpQuery.split('&')
            for (const item of items) {
              const value = item.split('=')
              query[value[0]] = value[1]
            }
          }
          this.$router.push({path: this.to, query: query, params: this.$route.params})
        } else if (this.open !== '') {
          if (!this.open.startsWith('http')) {
            window.open(`http://${this.open}`, '_blank')
          } else {
            window.open(this.open, '_blank')
          }
        }
        this.$emit('click')
      }
    }
  }
}
</script>

<style scoped>
</style>
