<template>
  <div :class="index===1 || isCurrent?'cardItemActive':'cardItem'">
    <div class="card_title">
      <div style="text-align: left;">
        <span v-if="isCurrent" style="color: red">{{ data.Title || getCard(data.Uid) }}</span>
        <span v-else>{{ data.Title || getCard(data.Uid) }}</span>
        <el-popover
          @show="syncPopover"
          placement="bottom"
          width="2rem"
          trigger="click">
          <div class="popover">IP {{ ip }}</div>
          <div v-if="isLogin" class="popover" @click="setNotes">{{ notes }}</div>
          <i class="el-icon-arrow-down" slot="reference"></i>
        </el-popover>
      </div>
      <my-link class="intoActive" v-if="isCurrent" :jump-login="true" to='/profile/edit'>
        修改
      </my-link>
      <my-link v-else-if="isLogin" class="into" :jump-query="`id=${data.Uid}`" to="/login">
        <span style="color: red">入口</span>
      </my-link>
      <my-link v-else class="into" :jump-query="`id=${data.Uid}`" to="/login">
        入口
      </my-link>
    </div>
    <div class="card_center">
      <div style="width: 65%;text-align: left;">
        链号：<a :href="getHttpCard(data.Uid)">{{ getCard(data.Uid) }}</a>
        <i v-if="isLogin"
           style="margin-left: .2rem;cursor: pointer"
           :class="!data.IsFavorites?'el-icon-star-off': 'el-icon-star-on'"
           @click="addOrCancelFav">
        </i>
      </div>
      <div style="margin-left: 1rem;width: 35%;text-align: left">
        {{data.Contact.split('$')[0] || 'QQ'}}:{{ data.Contact.split('$')[1] || '暂时保密' }}
      </div>
    </div>
    <div class="card_address">
      <span :key="i" v-for="(item, i) in address">
        <span v-if="item === '>'" :style="matchAddressIndex >= i ? 'color:red':''"> > </span>
        <span v-else
              @click="clickAddress(i)"
              :class="matchAddressIndex >= i?'card_address_item_red':'card_address_item'">
          {{ item }}
        </span>
      </span>
    </div>
    <div class="card_keyword">
      <strong>搜词：</strong>
      <span @click="clickKeyword(key)"
            :class="key === matchKey?'card_keyword_item_red': 'card_keyword_item'"
            :key="i"
            v-for="(key, i) in keywords">
        {{ key }}
      </span>
      <span style="position: absolute;right: .4rem">{{ unixFormat('YYYY.mm.dd', data.Created) }}</span>
    </div>
    <div class="card_content">
      &nbsp;&nbsp;&nbsp;&nbsp;<span v-html="replaceCardContent(data.Essay)"></span>
    </div>
    <div class="card_options">
      <my-link :disable="isUnknown" class="card_options_item" to="/disk"  :jump-query="`id=${data.Uid}`">网盘</my-link>
      <my-link :disable="isUnknown" class="card_options_item" to="/essay" :jump-query="`id=${data.Uid}`">短文</my-link>
      <my-link :disable="isUnknown" class="card_options_item" :to="`/favorites?id=${data.Uid}`">收藏夹</my-link>

      <my-link :disable="isUnknown" class="card_options_item"
               style="color: red"
               @click="starCancel(data.Uid)"
               :jump-login="true"
               :to="$route.path"
               v-if="data.IsStar">
        已注({{ convStarNum(data.Star) }})
      </my-link>
      <my-link class="card_options_item"
               @click="starAdd(data.Uid)"
               :disable="isUnknown"
               :jump-login="true"
               :to="$route.path"
               v-else>
        关注({{convStarNum(data.Star)}})
      </my-link>

      <my-link :disable="isUnknown" class="card_options_item"
               style="color: red"
               @click="groupCancel(data)"
               v-if="data.IsGroup">
        已群
      </my-link>
      <my-link :disable="isUnknown"
               :jump-login="true"
               :jump-query="`redirect=${$route.path}`"
               class="card_options_item"
               @click="groupAdd(data)"
               v-else>
        群聊
      </my-link>

      <my-link :disable="isUnknown" class="card_options_item"
               style="color: red"
               @click="privateCancel(data)"
               v-if="data.IsPrivate">
        已私
      </my-link>
      <my-link :disable="isUnknown"
               class="card_options_item"
               :jump-login="true"
               :jump-query="`redirect=${$route.path}`"
               @click="privateAdd(data)"
               v-else>
        私聊
      </my-link>

      <my-link :disable="isUnknown" class="card_options_item" :to="`/leave-message?id=${data.Uid}`">留言</my-link>
    </div>
  </div>
</template>

<script>
import {starAdd, starCancel} from '@/api/card'
import {favAdd, favCancel} from '@/api/favorites'
import {getCard, getHttpCard, replaceCardContent} from '@/utils/card'
import {groupAdd, groupCancel, privateAdd, privateCancel} from '@/api/chat'
import {unixFormat} from '@/utils/date'
import {notesGet, notesSet} from '@/api/notes'

export default {
  name: 'Card',
  components: {
    MyLink: () => import('@/views/components/MyLink.vue')
  },
  props: {
    data: {
      type: Object,
      default: () => ({})
    },
    index: {
      type: Number,
      default: 0
    },
    matchAddress: {
      type: String,
      default: ''
    },
    matchKey: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      ip: '未知',
      notes: '备注'
    }
  },
  computed: {
    // 是否登录
    isLogin: function () {
      return this.$store.getters.username !== ''
    },
    // 该名片是不是当前登录用户
    isCurrent () {
      if (this.isLogin) {
        return this.$store.getters.username === this.data.Uid
      }
      return false
    },
    // 是否是未注册ID
    isUnknown () {
      return this.data.ID === 0
    },
    // 地址
    address () {
      const address = this.data.Address.split('>')
      return [
        address[0],
        '>',
        address[1],
        '>',
        address[2],
        '>',
        address[3],
        '>',
        address[4]
      ]
    },
    // 选项地址匹配中的部分
    matchAddressIndex () {
      if (this.matchAddress === '') {
        return -1
      }
      const match = this.matchAddress.split('>')
      const source = this.data.Address.split('>')
      let matchIndex = -1
      for (let i = 0; i < match.length; i++) {
        if (match[i] === source[i]) {
          matchIndex = i
        }
      }
      if (matchIndex === -1) {
        return -1
      }
      return matchIndex * 2
    },
    // 关键词
    keywords () {
      const keywords = this.data.Keywords.split('$$')
      const tmpKeywords = []
      for (let i = 0; i < 3; i++) {
        if (i === 0) {
          tmpKeywords.push(keywords[i] || '网友')
        } else if (i === 1) {
          tmpKeywords.push(keywords[i] || '交友')
        } else {
          tmpKeywords.push(keywords[i] || '空缺')
        }
      }
      return tmpKeywords
    }
  },
  methods: {
    replaceCardContent,
    unixFormat,
    getCard,
    getHttpCard,
    // 同步名片IP和备注数据
    async syncPopover () {
      if (!this.isLogin) {
        return
      }
      if (this.notes !== '备注') {
        return
      }
      const resp = (await notesGet({ right: this.data.Uid })).data
      this.notes = resp.Cnt || '备注'
    },
    // 设置备注
    setNotes () {
      if (this.isUnknown) {
        return
      }
      this.$prompt('设置备注', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value === '') {
          return
        }
        notesSet({ right: this.data.Uid, cnt: value }).then(() => {
          this.notes = value
        })
      })
    },
    // 转换关注数量
    convStarNum (num) {
      if (num >= 10000) {
        return `${(num / 10000).toFixed(1)}w`
      } else if (num >= 1000) {
        return `${(num / 1000).toFixed(0)}k`
      }
      return num
    },
    // 收藏或取消收藏名片
    async addOrCancelFav () {
      if (this.isUnknown) {
        return
      }
      if (!this.data.IsFavorites) {
        await favAdd({
          name: this.data.Title || getCard(this.data.Uid),
          link: getHttpCard(this.data.Uid),
          uid: this.data.Uid })
        this.data.IsFavorites = true
      } else {
        await favCancel({
          link: getHttpCard(this.data.Uid),
          uid: this.data.Uid })
        this.data.IsFavorites = false
      }
    },
    // 关注
    async starAdd (id) {
      const data = (await starAdd({ id: id })).data
      this.data.Star += data
      this.data.IsStar = data === 1
    },
    // 取消关注
    async starCancel (id) {
      const data = (await starCancel({ id: id })).data
      this.data.Star -= data
      this.data.IsStar = false
    },
    // 添加群聊
    async groupAdd (data) {
      await groupAdd({ uid: data.Uid })
      this.data.IsGroup = true
    },
    // 取消群聊
    async groupCancel (data) {
      await groupCancel({ uid: data.Uid })
      this.data.IsGroup = false
    },
    // 添加私聊
    async privateAdd (data) {
      await privateAdd({ uid: data.Uid })
      this.data.IsPrivate = true
    },
    // 取消私聊
    async privateCancel (data) {
      await privateCancel({ uid: data.Uid })
      this.data.IsPrivate = false
    },
    // 点击关键词
    clickKeyword (key) {
      this.$emit('clickKeyword', key)
    },
    // 点击地址
    clickAddress (index) {
      this.$emit('clickAddress', this.address.slice(0, index + 1).join(''))
    }
  }
}
</script>

<style scoped>
.popover{
  text-align: center;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  padding: .1rem;
  cursor: pointer;
}

.cardItem{
    padding: .1rem .3rem;
    border: .013333rem solid #909090;
    width: 100%;
    border-radius: .066667rem;
    margin: .106667rem auto;
    font-size: .29rem;
    line-height: .45rem;
    word-break: break-all;
    color: #000;
    background: #fff;
}

.cardItemActive{
  padding: .1rem .3rem;
  border: .013333rem solid red;
  width: 100%;
  border-radius: .066667rem;
  margin: .106667rem auto;
  font-size: .29rem;
  line-height: .45rem;
  word-break: break-all;
  color: #000;
  background: #fff;
}

.into{
  position: absolute;
  right: .4rem;
  cursor: pointer;
  color: #409EFF;
}

.intoActive{
  position: absolute;
  right: .4rem;
  color: red;
  cursor: pointer;
}

a {
  color: #409eff;
  text-decoration:none;
}

a:hover {
  text-decoration: underline;
}

.card_title {
    display: flex;
    clear: both;
}

.card_center {
    display: flex;
    align-items: center;
}

.card_address{
  display: flex;
}

.card_address_item{
  color: #000;
  cursor: pointer;
}

.card_address_item_red{
  color: red;
  cursor: pointer;
}

.card_address_item:hover{
  color: red;
}

.card_content{
  color: #777;
  font-size: .24rem;
  line-height: .32rem;
  text-align: left;
  padding: .1rem 0;
}

.card_keyword{
  display: flex;
}

.card_keyword_item{
  cursor: pointer;
  margin-right: .17rem;
  color: #777;
  text-decoration: underline;
}

.card_keyword_item_red{
  cursor: pointer;
  margin-right: .17rem;
  color: red;
  text-decoration: underline;
}

.card_keyword_item:hover{
  color: red;
}

.card_options{
  display: flex;
}

.card_options_item{
  margin-left: .26rem;
  color: #777;
  font-size: .26rem;
}

.card_options_item:hover{
  color: #409eff;
}
</style>
