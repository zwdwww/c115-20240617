<template>
  <div>
    <div :key="i" v-for="(item, i) in items"
         @mouseenter="needLoadData(i)"
         @touchstart="needLoadData(i)">
      <slot :item="item" :index="i+1"></slot>
    </div>
  </div>
</template>

<script>
// 动态加载数据
export default {
  name: 'DynamicsLoad',
  props: {
    items: {
      type: Array,
      default: () => ([])
    },
    per: {
      type: Number,
      default: 20
    },
    reset: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      currIndex: this.per - 5
    }
  },
  methods: {
    // 是否需要加载数据
    needLoadData (i) {
      if (this.reset) {
        this.currIndex = this.per - 5
        this.$emit('update:reset', false)
        console.log('load reset true')
      }
      if (this.currIndex > this.items.length) {
        return
      }
      if ((i + 1) >= this.currIndex) {
        console.log('DynamicsLoad', i, this.currIndex)
        this.currIndex += this.per
        this.$emit('load')
      }
    }
  }
}
</script>

<style scoped>

</style>
