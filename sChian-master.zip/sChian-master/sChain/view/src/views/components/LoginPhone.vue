<template>
  <div class="content">
    <div style="margin-bottom: 15%"></div>
    <div class="inputCard">
      <div style="font-size: .4rem;margin-bottom: .2rem;padding-top: .2rem">登录</div>
      <el-form v-loading="loading" class="loginForm" ref="form" :model="form">
        <el-form-item prop="username">
          <el-input size="medium" class="loginFormInput" ref="username" v-model="form.username" placeholder="登录ID(7~13位数字/手机/QQ)">
            <template slot="append">.{{ getDomain() }}</template>
          </el-input>
        </el-form-item>
        <div class="itemSpan">
          <span>密码登录</span>
        </div>
        <el-form-item prop="password">
          <el-input size="medium" class="loginFormInput" :type="passwordEye" v-model="form.password" placeholder="请输入密码">
            <i style="cursor: pointer" slot="suffix" class="el-input__icon el-icon-view" @click="changePwdEye"></i>
          </el-input>
        </el-form-item>
        <div class="itemSpan">
          <span>忘记密码 / 验证码登录</span>
        </div>
        <el-form-item prop="verifyCode">
          <el-input size="medium" class="loginFormInput" v-model="form.verifyCode" placeholder="请输入验证码">
            <el-button type="text" slot="append" @click="sendVerifyCode">{{ verifyCodeBtn }}</el-button>
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-button class="loginFormInput" style="padding: .3rem;font-size: .26rem" type="primary" v-loading="loading" @click="handleLogin">登录</el-button>
        </el-form-item>
        <el-form-item>
          <div style="text-align: right;margin: auto;color: rgba(0, 0, 0, 0.6);font-size: .26rem">
            <span style="cursor: pointer">
              <my-link to="/register">注册界面</my-link>
            </span>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <div class="loginFooter">
      <div>
        客服<my-link class="link" :open="getManageHttpCard()">{{getManageCard()}}</my-link>
      </div>
      <div>
        测试<my-link class="link" :open="getHttpCard(12345678)">{{ getCard(12345678) }}
        <span style="padding-left: .1rem;">(密码8个8)</span>
      </my-link>
      </div>
      <div>
        Copyright©2018
      </div>
    </div>
  </div>
</template>

<script>

import {
  sendVerifyCode
} from '@/api/auth'
import {getCard, getDomain, getHttpCard, getManageCard, getManageHttpCard} from '@/utils/card'

export default {
  name: 'LoginPhone',
  components: {
    MyLink: () => import('@/views/components/MyLink.vue')
  },
  data () {
    return {
      loading: false,
      wait60Second: 0,
      timeoutId: 0,
      redirect: undefined,
      passwordEye: 'password',
      form: {
        username: '',
        password: '',
        verifyCode: ''
      }
    }
  },
  created () {
    if (this.$route.query.id) {
      this.form.username = this.$route.query.id
    }
  },
  computed: {
    verifyCodeBtn () {
      if (this.wait60Second === 0) {
        return '获取验证码'
      }
      return `${this.wait60Second}秒后重新发送`
    }
  },
  destroyed () {
    if (this.timeoutId !== 0) {
      window.clearTimeout(this.timeoutId)
    }
  },
  methods: {
    getDomain,
    getCard,
    getHttpCard,
    getManageCard,
    getManageHttpCard,
    changePwdEye () {
      if (this.passwordEye === 'text') {
        this.passwordEye = 'password'
      } else {
        this.passwordEye = 'text'
      }
    },
    // 发送验证码
    async sendVerifyCode () {
      if (this.wait60Second !== 0) {
        return
      }
      if (this.form.username === '') {
        this.$message.warning('请先输入登录ID')
        return
      }
      await sendVerifyCode(this.form)
      this.wait60Second = 60
      this.countdown()
    },
    // 倒计时开始
    countdown () {
      this.wait60Second--
      if (this.wait60Second === 0) {
        return
      }
      this.timeoutId = setTimeout(this.countdown, 1000)
    },
    // 登录
    handleLogin () {
      if (this.form.username === '') {
        this.$message.warning('请输入登录ID')
        return
      }
      if (this.form.password === '' && this.form.verifyCode === '') {
        this.$message.warning('请输入密码或验证码')
        return
      }
      this.loading = true
      const form = { ...this.form }
      this.$store.dispatch('user/login', form).then(() => {
        location.href = `${getHttpCard(this.form.username)}`
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    }
  }
}
</script>

<style scoped>
.content{
  width: 100%;
  background-color: #fff;
  overflow: auto;
  height: calc(100vh - 2.7rem);
}

.inputCard{
  margin: auto;
  background-color: #f1f1f1;
  width: 98%;
  border-radius: .2rem;
}

.loginFooter{
  font-size: .24rem;
  padding: .2rem;
  color: rgba(0, 0, 0, 0.6);
}

.link{
  color: #1e90ff;
  text-decoration: none;
  padding-left: .2rem;
}

.loginForm{
  width: 80%;
  margin: auto;
}

.loginFormInput{
  width: 100%;
}

.itemSpan{
  text-align: left;
  font-size: .2rem;
  padding-bottom: .13rem;
  margin-left: .1rem;
  color: #4a4ea6;
  cursor: default;
}
</style>
