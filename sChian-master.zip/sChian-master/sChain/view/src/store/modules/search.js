const state = {
  searchInput: ''
}

const mutations = {
  CHANGE_INPUT: (state, word) => {
    state.searchInput = word
  }
}

const actions = {
  changeSearchInput ({ commit }, word) {
    commit('CHANGE_INPUT', word)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
