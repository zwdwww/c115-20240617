const state = {
  cachedViews: []
}

const mutations = {
  ADD_CACHED_VIEW: (state, view) => {
    if (state.cachedViews.includes(view.name)) return
    state.cachedViews.push(view.name)
  },

  DEL_CACHED_VIEW: (state, name) => {
    const index = state.cachedViews.indexOf(name)
    index > -1 && state.cachedViews.splice(index, 1)
  },

  DEL_ALL_CACHED_VIEWS: state => {
    state.cachedViews = []
  }
}

const actions = {
  addCachedView ({ commit }, view) {
    commit('ADD_CACHED_VIEW', view)
  },

  delCachedView ({ commit, state }, name) {
    return new Promise(resolve => {
      commit('DEL_CACHED_VIEW', name)
      resolve([...state.cachedViews])
    })
  },

  delAllCachedViews ({ commit, state }) {
    return new Promise(resolve => {
      commit('DEL_ALL_CACHED_VIEWS')
      resolve([...state.cachedViews])
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
