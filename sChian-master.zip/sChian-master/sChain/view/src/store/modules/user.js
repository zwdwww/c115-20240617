import { login, logout, getInfo, register } from '@/api/auth'
import { getToken, setToken, removeToken } from '@/utils/auth'

const state = {
  token: getToken(),
  username: '',
  phone: '',
  question: ''
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_NAME: (state, name) => {
    state.username = name
  },
  SET_PHONE: (state, phone) => {
    state.phone = phone
  },
  SET_QUESTION: (state, question) => {
    state.question = question
  }
}

const actions = {
  // user login
  login ({commit}, userInfo) {
    return new Promise((resolve, reject) => {
      login(userInfo).then(response => {
        const {data} = response
        commit('SET_TOKEN', data.token)
        commit('SET_NAME', data.username)
        commit('SET_PHONE', data.phone.toString())
        try {
          commit('SET_QUESTION', JSON.parse(data.question))
        } catch (e) {
          commit('SET_QUESTION', {})
        }
        setToken(data.token)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  register ({commit}, form) {
    return new Promise((resolve, reject) => {
      register(form).then(response => {
        const { data } = response
        commit('SET_TOKEN', data.token)
        commit('SET_NAME', data.username)
        commit('SET_PHONE', data.phone.toString())
        try {
          commit('SET_QUESTION', JSON.parse(data.question))
        } catch (e) {
          commit('SET_QUESTION', {})
        }
        setToken(data.token)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo ({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo(state.token).then(response => {
        const { data } = response
        const { username, phone, question } = data
        commit('SET_NAME', username)
        commit('SET_PHONE', phone.toString())
        try {
          commit('SET_QUESTION', JSON.parse(question))
        } catch (e) {
          commit('SET_QUESTION', {})
        }
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout ({commit, state, dispatch}) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        commit('SET_TOKEN', '')
        commit('SET_NAME', '')
        commit('SET_PHONE', '')
        commit('SET_QUESTION', '')
        removeToken()
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken ({commit}) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      removeToken()
      resolve()
    })
  },

  // set phone
  setPhone ({ commit }, phone) {
    return new Promise(resolve => {
      commit('SET_PHONE', phone)
      resolve()
    })
  },

  // set Question
  setQuestion ({commit}, question) {
    return new Promise(resolve => {
      commit('SET_QUESTION', question)
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
