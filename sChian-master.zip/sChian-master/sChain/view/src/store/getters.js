const getters = {
  token: state => state.user.token,
  username: state => state.user.username,
  phone: state => state.user.phone,
  question: state => state.user.question,
  cachedViews: state => state.tagsView.cachedViews,
  searchInput: state => state.search.searchInput
}
export default getters
