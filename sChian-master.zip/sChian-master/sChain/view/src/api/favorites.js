import request from '@/utils/request'

export function favList (data) {
  return request.post('/favorites/list', data)
}

export function favAdd (data) {
  return request.post('/favorites/add', data)
}

export function favCancel (data) {
  return request.post('/favorites/cancel', data)
}

export function favUpdate (data) {
  return request.post('/favorites/update', data)
}

export function favDel (data) {
  return request.post('/favorites/del', data)
}

export function favOrder (data) {
  return request.post('/favorites/order', data)
}
