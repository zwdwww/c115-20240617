import request from '@/utils/request'

export function recordAddress () {
  return request.post('/record/address')
}

export function recordAddressPush (data) {
  return request.post('/record/address/push', data)
}
