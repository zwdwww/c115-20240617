import request from '@/utils/request'

export function leaveMsgList (data) {
  return request.post('/leave-msg/list', data)
}

export function leaveMsgAdd (data) {
  return request.post('/leave-msg/add', data)
}

export function leaveMsgDelOther (data) {
  return request.post('/leave-msg/del-other', data)
}

export function leaveMsgDelMy (data) {
  return request.post('/leave-msg/del-my', data)
}
