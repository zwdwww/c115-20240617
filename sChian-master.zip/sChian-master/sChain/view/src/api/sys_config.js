import request from '@/utils/request'

export function sysConfigGet (data) {
  return request.post('/sys', data)
}
