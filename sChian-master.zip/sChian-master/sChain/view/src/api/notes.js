import request from '@/utils/request'

export function notesGet (data) {
  return request.post('/notes/get', data)
}

export function notesSet (data) {
  return request.post('/notes/set', data)
}
