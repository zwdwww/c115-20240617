import request from '@/utils/request'

export function essayList (data) {
  return request.post('/essay', data)
}

export function essayAdd (data) {
  return request.post('/essay/add', data)
}

export function essayDel (data) {
  return request.post('/essay/del', data)
}

export function essayUpdate (data) {
  return request.post('/essay/update', data)
}

export function essayTopping (data) {
  return request.post('/essay/topping', data)
}
