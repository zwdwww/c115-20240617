import request from '@/utils/request'

export function login (data) {
  return request.post('/auth/login', data)
}

export function register (data) {
  return request.post('/auth/register', data)
}

export function sendRegisterMsg (data) {
  return request.post('/auth/sendRegMsg', data)
}

export function logout (data) {
  return request.post('/auth/logout', data)
}

export function logoff () {
  return request.post('/auth/logoff')
}

export function checkExists (data) {
  return request.post('/auth/exists', data)
}

export function getInfo (data) {
  return request.post('/auth/info', data)
}

export function resetPassword (data) {
  return request.post('/auth/reset', data)
}

export function sendVerifyCode (data) {
  return request.post('/auth/sendMsg', data)
}

export function sendForgetVerifyCode (data) {
  return request.post('/auth/forget/sendMsg', data)
}

export function phoneForget (data) {
  return request.post('/auth/forget', data)
}

export function questionForget (data) {
  return request.post('/auth/forget/question', data)
}

export function getQuestionForget (data) {
  return request.post('/auth/forget/question/get', data)
}

export function sendInfoVerifyCode () {
  return request.post('/auth/info/sendMsg')
}

export function infoSetPassword (data) {
  return request.post('/auth/set/password', data)
}

export function infoSetPhone (data) {
  return request.post('/auth/set/phone', data)
}

export function infoSetQuestion (data) {
  return request.post('/auth/set/question', data)
}
