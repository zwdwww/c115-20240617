import request from '@/utils/request'

// 推荐页
export function cardSuggest (data) {
  return request.post('/card/suggest', data)
}

// 搜索
export function cardSearch (data) {
  return request.post('/card/search', data)
}

// 排行
export function cardRank (data) {
  return request.post('/card/stars/rank', data)
}

// 更新自己的名片
export function cardUpdate (data) {
  return request.post('/card/update', data)
}

// 获取自己的名片数据
export function cardCurrent () {
  return request.post('/card/current')
}

// 获取自己的关注名片列表
export function starsCard () {
  return request.post('/card/stars')
}

// 关注
export function starAdd (data) {
  return request.post('/card/star/add', data)
}

// 取消关注
export function starCancel (data) {
  return request.post('/card/star/cancel', data)
}
