import request from '@/utils/request'

export function searchKeys () {
  return request.post('/search/keys')
}
