import request from '@/utils/request'

export function diskLs (data) {
  return request.post('/disk/ls', data)
}

export function diskPdfPages (data) {
  return request.post('/disk/pdf/pages', data)
}

export function diskSurplus (data) {
  return request.post('/disk/surplus', data)
}

export function diskRename (data) {
  return request.post('/disk/rename', data)
}

export function newFolder (data) {
  return request.post('/disk/new/folder', data)
}

export function diskRm (data) {
  return request.post('/disk/rm', data)
}

export function diskOrder (data) {
  return request.post('/disk/order', data)
}

export function diskMove (data) {
  return request.post('/disk/move', data)
}
