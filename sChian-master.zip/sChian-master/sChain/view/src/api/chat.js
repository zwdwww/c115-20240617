import request from '@/utils/request'

export function groupAdd (data) {
  return request.post('/chat/group/add', data)
}

export function groupCount (data) {
  return request.post('/chat/group/count', data)
}

export function groupCancel (data) {
  return request.post('/chat/group/cancel', data)
}

export function privateAdd (data) {
  return request.post('/chat/private/add', data)
}

export function privateCancel (data) {
  return request.post('/chat/private/cancel', data)
}

export function chatList () {
  return request.post('/chat/list')
}

export function register (data) {
  return request.post('/chat/register', data)
}

export function sendMsg (data) {
  return request.post('/chat/sendMsg', data)
}

export function newMsg (data) {
  return request.post('/chat/newMsg', data)
}

export function history (data) {
  return request.post('/chat/history', data)
}
