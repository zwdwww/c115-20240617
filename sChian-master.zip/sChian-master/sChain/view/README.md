vue-pdf问题处理(重要):
> 在`node_modules/vue-pdf/src/componentFactory.js`的第`78`行加上下面这行代码, 不然超链接的位置会出问题(导致无法点击)
```js
this.$refs.annotationLayer.style.transform = 'scale('+resolutionScale+')';
```
