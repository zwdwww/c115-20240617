'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  VUE_APP_BASE_API : '"http://192.168.0.103:10001/api"',
  VUE_CARD_DOMAIN: '"localhost"',
  VUE_CARD_PREFIX: '"http://"',
  VUE_CARD_MANAGE: '"13017181618"'
})
