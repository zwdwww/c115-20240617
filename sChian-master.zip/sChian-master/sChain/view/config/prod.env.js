'use strict'
module.exports = {
  NODE_ENV: '"production"',
  VUE_APP_BASE_API : '"https://115.cn/schain/api"',
  VUE_CARD_DOMAIN: '"115.cn"',
  VUE_CARD_PREFIX: '"http://"',
  VUE_CARD_MANAGE: '"13017181618"'
}
