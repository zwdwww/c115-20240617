package main

import (
	"cChain/common"
	"cChain/event"
	"cChain/handle"
	"cChain/model"
	"cChain/shell"
	"fmt"
	"gopkg.in/urfave/cli.v1"
	"net/http"
	"os"
)

func run() {
	if err := common.InitSnow(1); err != nil {
		panic(err)
	}
	if err := common.InitGeoIp("config/GeoLite2-City.mmdb"); err != nil {
		panic(err)
	}
	if err := model.LoadAuthToken(); err != nil {
		panic(err)
	}

	go event.Run()

	defer func() {
		_ = common.GeoIp.Close()
	}()

	common.Loggers.Infof("ListenAndServe start,:%v", common.Config.Port)
	common.Loggers.Errorf("ListenAndServe,%v",
		http.ListenAndServe(":"+common.Config.Port, handle.Intercept{}),
	)
}

func main() {
	common.InitConfig("config/config.yaml")

	app := cli.NewApp()

	app.Version = "1.0.0"
	app.Action = func(c *cli.Context) error {
		run()
		return nil
	}

	app.Commands = []cli.Command{
		{
			Name:  "syncdisk",
			Usage: "同步文件",
			Action: func(c *cli.Context) error {
				return shell.SyncDiskFile(c.String("path"))
			},
			Flags: []cli.Flag{
				cli.StringFlag{
					Name:  "path",
					Usage: "存放文件夹的路径",
				},
			},
		},
		{
			Name:  "synckkfile",
			Usage: "同步KKFile文件",
			Action: func(c *cli.Context) error {
				shell.SyncKKFile()
				return nil
			},
		},
		{
			Name:  "recoverfile",
			Usage: "恢复不可预览的文件",
			Action: func(c *cli.Context) error {
				shell.RecoverFile()
				return nil
			},
		},
	}

	if err := app.Run(os.Args); err != nil {
		_, _ = fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
