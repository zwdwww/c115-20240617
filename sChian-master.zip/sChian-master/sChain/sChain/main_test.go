package main

import (
	"cChain/common"
	"cChain/model"
	"fmt"
	"testing"
)

func TestAny(t *testing.T) {
	//uri := "https://115.cn/file/fileUpload"
	//resp, err := common.UploadFile(uri, "./1234.docx", "file")
	//fmt.Println(err)
	//fmt.Println(string(resp))
	common.InitConfig("config/config.yaml")
	name := model.KKFileViewApi.Remove("1aa92388cba5465a16957c9ebe7a2121.html")
	fmt.Println(name)
}
