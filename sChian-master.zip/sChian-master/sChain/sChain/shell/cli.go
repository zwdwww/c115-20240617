package shell

import (
	"cChain/common"
	"cChain/model"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func SyncDiskFile(path string) error {
	files, err := os.ReadDir(path)
	if err != nil {
		return err
	}

	for _, file := range files {
		filePath := filepath.Join(path, file.Name())
		content, err := os.ReadFile(filePath)
		if err != nil {
			return err
		}

		nameSlice := strings.Split(file.Name(), ".")
		md5 := nameSlice[0]
		diskFile := &model.DiskFile{}
		if diskFile.Get(md5).Err != nil {
			if diskFile.IsMysqlNil() {
				fmt.Println("not found file: ", file.Name())
				continue
			} else {
				return diskFile.Err
			}
		}

		if diskFile.UpdateContent(content).Err != nil {
			return diskFile.Err
		}

		fmt.Println("update success: ", file.Name())
	}
	return nil
}

func SyncKKFile() {
	df := &model.DiskFile{}
	df.Get("10a1fd511938e9477bd2ffefc199729a")
	uri := fmt.Sprintf("%v/fileUpload", common.Config.KKFileURI)
	data, err := common.UploadFile(uri, "file", fmt.Sprintf("%v.%v", df.FileMd5, df.FileType), df.FileContent)
	fmt.Println(err)
	fmt.Println(string(data))
	//items := model.KKFileViewApi.DirList()
	//fmt.Println(items)
}

func RecoverFile() {
	uri := fmt.Sprintf("%v/fileUpload", common.Config.KKFileURI)

	df := &model.DiskFile{}
	items := df.FindByIsPreview(0)
	for _, item := range items {
		if item.FileContent == nil {
			fmt.Println("file not content: ", item.FileMd5)
			continue
		}
		data, err := common.UploadFile(uri, "file", fmt.Sprintf("%v.%v", item.FileMd5, item.FileType), item.FileContent)
		fmt.Println("upload file: ", string(data), err)
		if err == nil {
			item.UpdatePreview(1)
		}
	}
}
