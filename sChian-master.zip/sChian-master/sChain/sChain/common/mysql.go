package common

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"
)

func InitMysql() {
	config := &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			SingularTable: true,
		},
		DisableForeignKeyConstraintWhenMigrating: true,
	}

	if Config.Mysql.LoggerDebug {
		config.Logger = logger.Default.LogMode(logger.Info)
	}

	var err error
	Db, err = gorm.Open(mysql.Open(Config.Mysql.Source), config)
	if err != nil {
		panic(fmt.Sprintf("MySQL链接失败: err=%v", err))
	}
	sqlDB, _ := Db.DB()
	sqlDB.SetMaxOpenConns(Config.Mysql.MaxOpenConn)
	sqlDB.SetMaxIdleConns(Config.Mysql.MaxIdleConn)
}
