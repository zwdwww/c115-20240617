package common

import (
	"encoding/json"
	"fmt"
	"net/url"
)

var RongYunApi RongYun

const rongYunSendApi = "https://sms.rong-api.com/sendCode.json"
const rongYunVerifyApi = "https://sms.rong-api.com/verifyCode.json"

type rongYunSendResp struct {
	Code      int    `json:"code"`
	SessionId string `json:"sessionId"`
}

type rongYunVerifyResp struct {
	Code    int  `json:"code"`
	Success bool `json:"success"`
}

// RongYun 融云
type RongYun struct{}

func (r RongYun) post(url string, values url.Values) ([]byte, error) {
	now := TimestampSec()
	nonce := SnowStringID()
	headers := map[string]string{
		"App-key":   Config.RongYun.AppKey,
		"Nonce":     nonce,
		"Timestamp": fmt.Sprintf("%v", now),
		"Signature": HashSha1(fmt.Sprintf("%v%v%v", Config.RongYun.AppSecret, nonce, now)),
	}
	return PostURLAndHeader(url, values, headers)
}

// SendMsg 发送短信验证码
func (r RongYun) SendMsg(mobile, tempId string) (string, error) {
	values := url.Values{}
	values.Set("mobile", mobile)
	values.Set("templateId", tempId)
	values.Set("region", "86")

	data, err := r.post(rongYunSendApi, values)
	if err != nil {
		return "", err
	}

	var resp rongYunSendResp
	_ = json.Unmarshal(data, &resp)
	if resp.Code != 200 {
		return "", fmt.Errorf("%s", data)
	}
	return resp.SessionId, nil
}

// VerifyCode 验证结果
func (r RongYun) VerifyCode(sessionId, code string) bool {
	values := url.Values{}
	values.Set("sessionId", sessionId)
	values.Set("code", code)
	data, err := r.post(rongYunVerifyApi, values)
	if err != nil {
		Loggers.Errorf("rongyun verifyCode err=%v", err)
		return false
	}
	var resp rongYunVerifyResp
	fmt.Printf("%s\v", data)
	_ = json.Unmarshal(data, &resp)
	return resp.Code == 200 && resp.Success
}
