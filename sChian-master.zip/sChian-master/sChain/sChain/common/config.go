package common

import (
	"go.uber.org/zap/zapcore"
	"strings"
)

// BaseConf 配置
type BaseConf struct {
	Logger    LoggerConf  `yaml:"logger"`
	Mysql     MysqlConf   `yaml:"mysql"`
	RongYun   RongYunConf `yaml:"rongYun"`
	Port      string      `yaml:"port"`
	FavMax    int         `yaml:"favMax"` // 收藏夹数量最大限制
	KKFileURI string      `yaml:"kkFileURI"`
}

type MysqlConf struct {
	Source      string `yaml:"source"`
	MaxIdleConn int    `yaml:"max_idle_conn"`
	MaxOpenConn int    `yaml:"max_open_conn"`
	LoggerDebug bool   `yaml:"logger_debug"`
}

type RongYunConf struct {
	AppKey       string `yaml:"appKey"`
	AppSecret    string `yaml:"appSecret"`
	LoginTemp    string `yaml:"loginTemp"`
	ForgetTemp   string `yaml:"forgetTemp"`
	InfoTemp     string `yaml:"infoTemp"`
	RegisterTemp string `yaml:"registerTemp"`
}

// LoggerConf 日志配置
type LoggerConf struct {
	// 日志输出级别控制, 优先使用该项目的日志输出等级[bg,uc,rp,client]
	// 如果没有项目日志等级配置, 默认使用Level
	Project     string // 项目名, 程序启动后赋值
	Level       string `yaml:"level"` // 级别
	BgLevel     string `yaml:"bgLevel"`
	ClientLevel string `yaml:"clientLevel"`
	UcLevel     string `yaml:"ucLevel"`
	RpLevel     string `yaml:"rpLevel"`

	Format       string `yaml:"format"`       // 输出
	Director     string `yaml:"director"`     // 日志文件夹
	MaxAge       int    `yaml:"maxAge"`       // 日志留存时间
	ShowLine     bool   `yaml:"showLine"`     // 显示行
	LogInConsole bool   `yaml:"loginConsole"` // 输出控制台
}

// TransportLevel 根据字符串转化为 zapcore.Level
func (z *LoggerConf) TransportLevel() zapcore.Level {
	z.Level = strings.ToLower(z.Level)
	switch z.Level {
	case "debug":
		return zapcore.DebugLevel
	case "info":
		return zapcore.InfoLevel
	case "warn":
		return zapcore.WarnLevel
	case "error":
		return zapcore.WarnLevel
	case "dpanic":
		return zapcore.DPanicLevel
	case "panic":
		return zapcore.PanicLevel
	case "fatal":
		return zapcore.FatalLevel
	default:
		return zapcore.DebugLevel
	}
}
