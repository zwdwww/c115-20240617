package common

import (
	"github.com/oschwald/geoip2-golang"
	"net"
)

// InitGeoIp 初始化GeoIp
func InitGeoIp(path string) (err error) {
	GeoIp, err = geoip2.Open(path)
	return err
}

// GetProvince 获取省份信息
func GetProvince(ip string) string {
	if ip == "127.0.0.1" {
		return ""
	}

	city, err := GeoIp.City(net.ParseIP(ip))
	if err != nil {
		Loggers.Errorf("GetProvince ip=%v, err=%v", ip, err)
		return ""
	}

	if len(city.Subdivisions) == 0 {
		return ""
	}

	name, ok := city.Subdivisions[0].Names["zh-CN"]
	if ok {
		return name
	}
	return ""
}
