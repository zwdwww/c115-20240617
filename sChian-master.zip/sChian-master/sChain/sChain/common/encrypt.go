package common

import (
	"crypto/aes"
	"crypto/sha1"
	"encoding/base64"
	"fmt"
	"io"
)

func generateKey(key []byte) (genKey []byte) {
	genKey = make([]byte, 16)
	copy(genKey, key)
	for i := 16; i < len(key); {
		for j := 0; j < 16 && i < len(key); j, i = j+1, i+1 {
			genKey[j] ^= key[i]
		}
	}
	return genKey
}

// AesEncryptECB Aes-ECB模式, 加密
func AesEncryptECB(origData []byte, key []byte) (encrypted []byte) {
	cipher, _ := aes.NewCipher(generateKey(key))
	length := (len(origData) + aes.BlockSize) / aes.BlockSize
	plain := make([]byte, length*aes.BlockSize)
	copy(plain, origData)
	pad := byte(len(plain) - len(origData))
	for i := len(origData); i < len(plain); i++ {
		plain[i] = pad
	}
	encrypted = make([]byte, len(plain))
	// 分组分块加密
	for bs, be := 0, cipher.BlockSize(); bs <= len(origData); bs, be = bs+cipher.BlockSize(), be+cipher.BlockSize() {
		cipher.Encrypt(encrypted[bs:be], plain[bs:be])
	}

	return encrypted
}

// AesDecryptECB Aes-ECB模式, 解密
func AesDecryptECB(encrypted []byte, key []byte) (decrypted []byte) {
	defer func() {
		if r := recover(); r != nil {
			decrypted = []byte{}
			return
		}
	}()
	cipher, _ := aes.NewCipher(generateKey(key))
	decrypted = make([]byte, len(encrypted))

	for bs, be := 0, cipher.BlockSize(); bs < len(encrypted); bs, be = bs+cipher.BlockSize(), be+cipher.BlockSize() {
		cipher.Decrypt(decrypted[bs:be], encrypted[bs:be])
	}

	trim := 0
	if len(decrypted) > 0 {
		trim = len(decrypted) - int(decrypted[len(decrypted)-1])
	}

	return decrypted[:trim]
}

// AesEncryptECBBase64 Aes-ECB模式,加密,并转成base64
func AesEncryptECBBase64(origData, key string) string {
	encry := AesEncryptECB([]byte(origData), []byte(key))
	return base64.StdEncoding.EncodeToString(encry)
}

// AesDecryptECBBase64 Aes-ECB模块,解密, 传入base64的encrypted
func AesDecryptECBBase64(encrypted, key string) []byte {
	decode, err := base64.StdEncoding.DecodeString(encrypted)
	if err != nil {
		return []byte{}
	}
	decry := AesDecryptECB(decode, []byte(key))
	if len(decry) == 0 {
		return []byte{}
	}
	return decry
}

// HashSha1 sha1签名
func HashSha1(baseStr string) string {
	t := sha1.New()
	_, _ = io.WriteString(t, baseStr)
	return fmt.Sprintf("%x", t.Sum(nil))
}
