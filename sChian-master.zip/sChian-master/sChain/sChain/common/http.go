package common

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"net/url"
	"path/filepath"
	"strings"
	"time"
)

const httpTimeout = time.Second * 60

func httpGet(url string) (resp *http.Response, err error) {
	client := http.Client{
		Timeout: httpTimeout,
	}
	return client.Get(url)
}

func httpPost(url, contentType string, body io.Reader) (resp *http.Response, err error) {
	client := http.Client{
		Timeout: httpTimeout,
	}
	return client.Post(url, contentType, body)
}

func httpPostForm(url string, data url.Values) (resp *http.Response, err error) {
	client := http.Client{
		Timeout: httpTimeout,
	}
	return client.PostForm(url, data)
}

// PostURL 请求URL
func PostURL(URL string, params url.Values) ([]byte, error) {
	resp, err := httpPostForm(URL, params)
	if err != nil {
		return nil, err
	}
	defer func() {
		_ = resp.Body.Close()
	}()
	return io.ReadAll(resp.Body)
}

// PostURLAndHeader Post请求 Form格式 设置请求头
func PostURLAndHeader(url string, values url.Values, headers map[string]string) ([]byte, error) {
	client := http.Client{Timeout: time.Second * 5}
	req, err := http.NewRequest("POST", url, strings.NewReader(values.Encode()))
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer func() {
		_ = resp.Body.Close()
	}()
	return io.ReadAll(resp.Body)
}

// PostMapReceiveJSON POST请求  自动解析JSON
func PostMapReceiveJSON(URL string, maps map[string]string, receive interface{}) error {
	params := url.Values{}
	for k, v := range maps {
		params.Set(k, v)
	}
	body, err := PostURL(URL, params)
	if err != nil {
		return err
	}
	err = json.Unmarshal(body, receive)
	if err != nil {
		return fmt.Errorf("body:%v,err:%v", string(body), err)
	}
	return nil
}

// PostJSON POST请求 BODY为JSON格式 ContentType=application/json
func PostJSON(URL string, v interface{}) ([]byte, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return nil, err
	}
	resp, err := httpPost(URL, "application/json", bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	defer func() {
		_ = resp.Body.Close()
	}()
	return io.ReadAll(resp.Body)
}

// PostJSONAndHeader Post请求 Json格式 设置请求头
func PostJSONAndHeader(url string, v interface{}, headers map[string]string) ([]byte, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return nil, err
	}
	client := http.Client{Timeout: time.Second * 5}
	req, err := http.NewRequest("POST", url, bytes.NewReader(b))
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", "application/json")
	for key, value := range headers {
		req.Header.Set(key, value)
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer func() {
		_ = resp.Body.Close()
	}()
	return io.ReadAll(resp.Body)
}

// UploadFile 上传文件
func UploadFile(uri, keyName, filename string, fileContent []byte) ([]byte, error) {
	var b bytes.Buffer
	w := multipart.NewWriter(&b)

	filePart, err := w.CreateFormFile(keyName, filepath.Base(filename))
	if err != nil {
		return nil, err
	}

	_, err = io.Copy(filePart, bytes.NewBuffer(fileContent))
	if err != nil {
		return nil, err
	}

	if err = w.Close(); err != nil {
		return nil, err
	}

	req, err := http.NewRequest("POST", uri, &b)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", w.FormDataContentType())

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer func() {
		_ = resp.Body.Close()
	}()

	return io.ReadAll(resp.Body)
}

// GetURL 请求URL
func GetURL(URL string) ([]byte, error) {
	resp, err := httpGet(URL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	return ioutil.ReadAll(resp.Body)
}
