package common

import "fmt"

// Cache 用户多了之后,建议替换成redis
var Cache = MemoryCache{}

// 用户Token缓存, 用户多了之后,建议替换成redis
var authTokenCache = MemoryCache{}

// VerifyCodeCache 短信验证码缓存
var VerifyCodeCache = MemoryCache{}

type CacheNode struct {
	Value   interface{}
	Expired int64
	Created int64
}

type MemoryCache map[string]*CacheNode

// Set 设置缓存数据
func (m MemoryCache) Set(key string, value interface{}, expired int64) {
	if expired > 0 {
		m[key] = &CacheNode{
			Value:   value,
			Expired: expired,
			Created: TimestampSec(),
		}
	} else {
		m[key] = &CacheNode{Value: value}
	}
}

func (m MemoryCache) SetNode(key string, node *CacheNode) {
	m[key] = node
}

// Get 获取数据
func (m MemoryCache) Get(key string) interface{} {
	node, ok := m[key]
	if !ok {
		return nil
	}
	// 过期检查
	if node.Expired != 0 && (TimestampSec()-node.Created > node.Expired) {
		delete(m, key)
		return nil
	}
	return node.Value
}

// GetAndExpired 获取数据并响应是否过期
func (m MemoryCache) GetAndExpired(key string) (interface{}, bool) {
	node, ok := m[key]
	if !ok {
		return nil, false
	}
	// 过期检查
	if node.Expired != 0 && (TimestampSec()-node.Created >= node.Expired) {
		delete(m, key)
		return nil, true
	}
	return node.Value, false
}

// GetSeconds 获取设置了多少秒了
func (m MemoryCache) GetSeconds(key string) int64 {
	node, ok := m[key]
	if !ok {
		return 0
	}
	return TimestampSec() - node.Created
}

func (m MemoryCache) Remove(key string) {
	delete(m, key)
}

// SetAuthTokenByNode 设置用户认证Token
func SetAuthTokenByNode(uid string, node *CacheNode) {
	authTokenCache.SetNode(fmt.Sprintf("%v", uid), node)
}

func GetAuthToken(uid string) (interface{}, bool) {
	return authTokenCache.GetAndExpired(fmt.Sprintf("%v", uid))
}

func RemoveAuthToken(uid string) {
	delete(authTokenCache, fmt.Sprintf("%v", uid))
}
