package event

import "cChain/common"

// 事件队列

type Item struct {
	Data []byte
	Name string
}

var Queue = make(chan Item, 128)

func Run() {
	common.Loggers.Infof("event running")
	for {
		item := <-Queue
		event, ok := IEventMap[item.Name]
		if !ok {
			common.Loggers.Errorf("event not found: name=%v", item.Name)
			continue
		}

		common.Loggers.Debugf("event start: name=%v", item.Name)
		if err := event.Do(item.Data); err != nil {
			common.Loggers.Errorf("event error: name=%v, err=%v", item.Name, err)
		}
	}
}
