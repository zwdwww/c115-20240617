package event

import (
	"cChain/model"
	"encoding/json"
	"fmt"
)

type IEvent interface {
	Do(data []byte) error
}

const (
	EKKFile = "KKFile"
)

var IEventMap = map[string]IEvent{
	EKKFile: new(KKFileEvent),
}

type KKFileEventItem struct {
	DiskFileID int
}

type KKFileEvent struct{}

func (k *KKFileEvent) Do(data []byte) error {
	var item KKFileEventItem
	if err := json.Unmarshal(data, &item); err != nil {
		return err
	}

	diskFile := model.DiskFile{ID: item.DiskFileID}
	if diskFile.LoadByID().Err != nil {
		return diskFile.Err
	}

	if err := model.KKFileViewApi.Upload(fmt.Sprintf("%v.%v", diskFile.FileMd5, diskFile.FileType), diskFile.FileContent); err != nil {
		return err
	}

	df := &model.DiskFile{ID: item.DiskFileID}
	return df.UpdatePreview(1).Err
}
