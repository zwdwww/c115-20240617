package handle

import (
	"cChain/handle/args"
	"cChain/model"
	"fmt"
)

var cardHandle Card

type Card struct{}

// Suggest 获取名片推荐列表
// 推荐内容,由后台管理
func (c Card) Suggest(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id   string `json:"id"`
		Page int    `json:"page"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Page == 0 {
		return nil, err
	}

	items, count := ctx.User().Card().Suggest(req.Page, 10)
	if ctx.Username != "" {
		// 读取用户对名片的操作状态
		_ = ctx.User().CardExtend("1").SetCardExtend(ctx.Username, items)
	}

	// 根据域名的ID,置顶推荐ID或设置一个404ID
	if req.Id != "" {
		card := &model.Card{Uid: req.Id}
		if card.Get().Err != nil {
			config := &model.SysConfig{}
			card = config.Card404()
		}
		return H{"items": items, "count": count, "card": card}, nil
	}
	return H{"items": items, "count": count, "card": nil}, nil
}

// Refresh 刷新页面
func (c Card) Refresh(ctx *Ctx) (interface{}, error) {
	var req struct {
		Page int `json:"page"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Page == 0 {
		return nil, err
	}

	items, count := ctx.User().Card().Refresh(req.Page, 10)
	if ctx.Username != "" {
		// 读取用户对名片的操作状态
		_ = ctx.User().CardExtend("1").SetCardExtend(ctx.Username, items)
	}
	return H{"items": items, "count": count, "card": nil}, nil
}

// Search 搜索
func (c Card) Search(ctx *Ctx) (interface{}, error) {
	var req struct {
		Page int `json:"page"`
		model.CardSearchArgs
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Page == 0 {
		return nil, err
	}

	items, count := ctx.User().Card().Search(req.Page, 10, &req.CardSearchArgs)
	if ctx.Username != "" {
		// 读取用户对名片的操作状态
		_ = ctx.User().CardExtend("1").SetCardExtend(ctx.Username, items)
	}
	return H{"items": items, "count": count, "card": nil}, nil
}

// StarsRank 根据关注度的排名获取名片
func (c Card) StarsRank(ctx *Ctx) (interface{}, error) {
	var req args.Page
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	// 只能获取前200个
	cards, count := ctx.User().
		Card().
		StarsDesc(req.GetPage(), 10)

	if ctx.Username != "" {
		_ = ctx.User().CardExtend("1").SetCardExtend(ctx.Username, cards)
	}
	return H{"items": cards, "count": count}, nil
}

// Current 获取自己的名片数据
func (c Card) Current(ctx *Ctx) (interface{}, error) {
	card := ctx.User().Card().Get()
	if card.Err != nil {
		return errSystem, fmt.Errorf("名片获取失败")
	}
	return H{"card": card}, nil
}

// UpdateCard 更新自己的名片
func (c Card) UpdateCard(ctx *Ctx) (interface{}, error) {
	var req struct {
		Address  []string
		Contact  []string
		Keywords []string
		Title    string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	if err := ctx.User().
		Card().
		UpdateCard(req.Title, req.Contact, req.Address, req.Keywords).Err; err != nil {
		return errSystem, fmt.Errorf("名片更新失败")
	}
	return nil, nil
}
