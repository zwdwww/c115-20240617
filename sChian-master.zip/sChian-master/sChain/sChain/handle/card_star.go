package handle

import (
	"cChain/common"
	"cChain/handle/args"
	"cChain/model"
	"fmt"
)

var cardStarHandle CardStar

type CardStar struct{}

// Stars 获取关注的卡片列表
func (c CardStar) Stars(ctx *Ctx) (interface{}, error) {
	stars := ctx.User().CardExtend("1").Stars()
	cards := ctx.User().Card().In(stars)
	_ = ctx.User().CardExtend("1").SetCardExtend(ctx.Username, cards)
	return cards, nil
}

// AddStar 添加关注
func (c CardStar) AddStar(ctx *Ctx) (interface{}, error) {
	var req args.Id
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}
	if star := ctx.User().
		CardExtend(req.Id).
		Create(model.CardStar).
		AddCardStar(1); star.Err != nil {
		common.Loggers.Errorf("关注失败:err=%v", star.Err)
		return 0, nil
	}
	return 1, nil
}

// CancelStar 取消关注
func (c CardStar) CancelStar(ctx *Ctx) (interface{}, error) {
	var req args.Id
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}
	if star := ctx.User().
		CardExtend(req.Id).
		Delete(model.CardStar).
		AddCardStar(-1); star.Err != nil {
		return 0, nil
	}
	return 1, nil
}
