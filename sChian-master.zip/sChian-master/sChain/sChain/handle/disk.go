package handle

import (
	"bytes"
	"cChain/common"
	"cChain/event"
	"cChain/model"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"strconv"
	"strings"
)

var diskHandle Disk

type Disk struct{}

func (d Disk) getFileType(filename string) string {
	arr := strings.Split(filename, ".")
	if len(arr) == 1 {
		return "?"
	}
	return arr[len(arr)-1]
}

func (d Disk) Root(_ *Ctx) (interface{}, error) {
	return []H{
		{"Path": "/public", "FileName": "公盘", "FileType": "dir", "IsRoot": true},
		{"Path": "/private", "FileName": "私盘", "FileType": "dir", "IsRoot": true},
		{"Path": "/group", "FileName": "群盘", "FileType": "dir", "IsRoot": true},
	}, nil
}

// Upload 上传文件
func (d Disk) Upload(ctx *Ctx) (interface{}, error) {
	if ctx.Request.Method == "POST" {
		err := ctx.Request.ParseMultipartForm(32 << 20)
		if err != nil {
			return errSystem, fmt.Errorf("上传失败")
		}

		// 路径存放路径
		parent := ctx.Request.Form.Get("parent")
		if parent == "" {
			return errSystem, fmt.Errorf("参数异常")
		}

		file, handler, err := ctx.Request.FormFile("File")
		if err != nil {
			return errSystem, fmt.Errorf("上传失败")
		}

		defer func() {
			_ = file.Close()
		}()

		// 存储空间检查
		size := ctx.User().DiskSize()
		if size.SurplusSize() < handler.Size {
			return errSystem, fmt.Errorf("存储空间不足")
		}

		bytesData, err := io.ReadAll(file)
		if err != nil {
			return errSystem, fmt.Errorf("文件读取失败")
		}

		// md5计算和物理存储
		// 如何md5已存在,则直接使用已存在的文件
		md5 := common.Md5(bytesData)
		diskFile := ctx.User().DiskFile().Get(md5)
		if diskFile.IsMysqlNil() {
			diskFile.Err = nil
			diskFile.FileMd5 = md5
			diskFile.FileType = d.getFileType(handler.Filename)
			diskFile.FileByteSize = handler.Size
			diskFile.AddFile(bytesData)

			item := event.KKFileEventItem{
				DiskFileID: diskFile.ID,
			}
			bytesData, _ := json.Marshal(item)
			event.Queue <- event.Item{Name: event.EKKFile, Data: bytesData}
		} else {
			diskFile.AddCount(1)
		}

		if diskFile.Err != nil {
			common.Loggers.Errorf("diskFile AddFile err=%v", diskFile.Err)
			return errSystem, fmt.Errorf("文件上传失败")
		}

		// 逻辑文件存储
		rel := ctx.User().DiskRel()
		rel.FileMd5 = md5
		rel.FileByteSize = handler.Size
		rel.FileName = handler.Filename
		rel.FileType = d.getFileType(handler.Filename)
		rel.Parent = parent
		if rel.Create(size).Err != nil {
			common.Loggers.Errorf("DiskRel Create err=%v", rel.Err)
			return errSystem, fmt.Errorf("文件上传失败")
		}
		return rel, nil
	} else {
		return errSystem, fmt.Errorf("请求异常")
	}
}

// Download 下载
func (d Disk) Download(ctx *Ctx) (interface{}, error) {
	to := ctx.Request.URL.Query().Get("to")
	if to == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	enEsc, err := url.QueryUnescape(to)
	if err != nil {
		return errSystem, err
	}

	file := &model.DiskFile{}
	file.Get(enEsc)
	if file.Err != nil {
		return errSystem, fmt.Errorf("文件下载异常")
	}

	if err != nil {
		return errSystem, fmt.Errorf("系统错误")
	}
	ctx.Response.Header().Set("Content-Type", "application/octet-stream")
	ctx.Response.Header().Set("Content-Length", strconv.FormatInt(file.FileByteSize, 10))
	_, _ = io.Copy(ctx.Response, bytes.NewBuffer(file.FileContent))
	return nil, nil
}

// CreateFolder 创建文件夹
func (d Disk) CreateFolder(ctx *Ctx) (interface{}, error) {
	var req struct {
		Parent string `json:"parent"`
		Name   string `json:"name"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Parent == "" || req.Name == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	file := &model.DiskRel{
		Uid:      ctx.Username,
		Parent:   req.Parent,
		FileName: req.Name,
		FileType: "dir",
		Created:  common.TimestampSec(),
	}
	if err := common.Db.Create(&file).Error; err != nil {
		return nil, err
	}
	return file, nil
}

// Rm 删除文件
func (d Disk) Rm(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if err := ctx.User().DiskRel().Get(req.Id).Remove().Err; err != nil {
		common.Loggers.Errorf("disk remove err=%v", err)
		return errSystem, fmt.Errorf("删除失败")
	}
	return nil, nil
}

// Ls 获取文件夹内容
// 三个系统文件夹
// /public:公共 /private:私有 /group：群聊
func (d Disk) Ls(ctx *Ctx) (interface{}, error) {
	var req struct {
		Path string `json:"path"`
		Id   string `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Path == "" || req.Id == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	// 权限检查
	haveAuth := false

	if ctx.Username == "" {
		haveAuth = strings.HasPrefix(req.Path, "/public")
	} else if ctx.Username == req.Id {
		haveAuth = true
	} else if strings.HasPrefix(req.Path, "/public") {
		haveAuth = true
	} else if strings.HasPrefix(req.Path, "/private") {
		haveAuth = ctx.Username == req.Id
	} else if strings.HasPrefix(req.Path, "/group") {
		haveAuth = ctx.User().ChatSession().ExistsGroup(req.Id).Err == nil
	} else {
		return errSystem, fmt.Errorf("目录异常")
	}

	if haveAuth {
		disk := &model.DiskRel{Uid: req.Id}
		items := disk.FindByParent(req.Path)
		order := &model.DiskOrder{Uid: req.Id}
		return H{"items": items, "order": order.Get(req.Path).OrderArray(), "auth": haveAuth}, nil
	} else {
		return H{"items": []model.DiskRel{}, "order": []int{}, "auth": haveAuth}, nil
	}
}

// SurplusSize 剩余空间获取
func (d Disk) SurplusSize(ctx *Ctx) (interface{}, error) {
	return ctx.User().DiskSize().SurplusSize(), nil
}

// Rename 重命名
func (d Disk) Rename(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id  int    `json:"id"`
		New string `json:"new"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 || req.New == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if err := ctx.User().DiskRel().Get(req.Id).Rename(req.New).Err; err != nil {
		return errSystem, fmt.Errorf("重命名失败")
	}
	return nil, nil
}

// SetOrder 设置排序
func (d Disk) SetOrder(ctx *Ctx) (interface{}, error) {
	var req struct {
		Path  string `json:"path"`
		Order []int  `json:"order"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Path == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if order := ctx.User().DiskOrder().Upsert(req.Path, req.Order); order.Err != nil {
		return errSystem, fmt.Errorf("收藏夹排序失败")
	}
	return nil, nil
}

// MoveFile 移动文件
func (d Disk) MoveFile(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id   int
		Path string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Path == "" || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if err := ctx.User().DiskRel().Get(req.Id).Move(req.Path).Err; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// GetShowURI 获取KKFile的文件渲染URI
func (d Disk) GetShowURI(ctx *Ctx) (interface{}, error) {
	var req struct {
		Md5 string `json:"md5"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}

	df := ctx.User().DiskFile()
	if df.Get(req.Md5).Err != nil {
		return errSystem, df.Err
	}

	if df.IsPreview != 1 {
		return "", nil
	}

	previewUrl := model.KKFileViewApi.GetShowURL(fmt.Sprintf("%v.%v", df.FileMd5, df.FileType))
	if df.FileType == "docx" || df.FileType == "doc" || df.FileType == "pdf" {
		previewUrl = fmt.Sprintf("%v&officePreviewType=pdf", previewUrl)
	}
	return previewUrl, nil
}
