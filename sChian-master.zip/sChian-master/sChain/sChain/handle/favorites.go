package handle

import (
	"cChain/common"
	"cChain/handle/args"
	"cChain/model"
	"fmt"
)

var favoritesHandle Favorites

// Favorites 收藏夹
type Favorites struct{}

// Favorites 收藏夹列表
func (f Favorites) Favorites(ctx *Ctx) (interface{}, error) {
	var req args.Id
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	favorites := &model.Favorites{Uid: req.Id}
	items := favorites.ListByUid()
	order := &model.FavoritesOrder{Uid: req.Id}
	order.Get()
	return H{"items": items, "order": order.OrderArray()}, nil
}

// Add 新增收藏夹
func (f Favorites) Add(ctx *Ctx) (interface{}, error) {
	var req struct {
		Name  string `json:"name"`
		Link  string `json:"link"`
		Uid   string `json:"uid"`
		Order []int  `json:"order"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	if ctx.User().Favorites().CountByUid() > int64(common.Config.FavMax) {
		return errSystem, fmt.Errorf("收藏夹已达上限")
	}

	favorites := &model.Favorites{Uid: ctx.Username, Key: req.Name, Value: req.Link}
	if favorites.Create().Err != nil {
		return errSystem, fmt.Errorf("收藏夹添加失败")
	}

	var order = req.Order
	if order != nil {
		order = append(order, favorites.ID)
	} else {
		order = ctx.User().FavoritesOrder().Get().OrderArray()
		order = append(order, favorites.ID)
	}
	if err := ctx.User().FavoritesOrder().Upsert(order).Err; err != nil {
		return errSystem, err
	}
	if req.Uid != "" {
		_ = ctx.User().CardExtend(req.Uid).Create(model.CardFavorites)
	}
	return favorites, nil
}

// Update 修改收藏夹
func (f Favorites) Update(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id   int    `json:"id"`
		Name string `json:"name"`
		Link string `json:"link"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}
	if fav := ctx.User().Favorites().Get(req.Id).UpdateContent(req.Name, req.Link); fav.Err != nil {
		return errSystem, fav.Err
	}
	return nil, nil
}

// Del 删除收藏夹
func (f Favorites) Del(ctx *Ctx) (interface{}, error) {
	var req args.FavReq
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	if order := ctx.User().FavoritesOrder().Upsert(req.Order); order.Err != nil {
		return errSystem, fmt.Errorf("收藏夹排序失败")
	}

	if fav := ctx.User().Favorites().Get(req.Id).Delete(); fav.Err != nil {
		return errSystem, fmt.Errorf("删除错误")
	}
	return nil, nil
}

// Cancel 取消收藏夹
func (f Favorites) Cancel(ctx *Ctx) (interface{}, error) {
	var req struct {
		Link string `json:"link"`
		Uid  string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	//ctx.User().Favorites().DeleteByValue(req.Link)  // 不删除收藏夹
	ctx.User().CardExtend(req.Uid).Delete(model.CardFavorites)
	return nil, nil
}

// SetOrder 设置收藏夹排序
func (f Favorites) SetOrder(ctx *Ctx) (interface{}, error) {
	var req args.FavReq
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}
	if order := ctx.User().FavoritesOrder().Upsert(req.Order); order.Err != nil {
		return errSystem, fmt.Errorf("收藏夹排序失败")
	}
	return nil, nil
}
