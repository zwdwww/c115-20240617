package handle

import (
	"cChain/common"
	"cChain/handle/args"
	"cChain/model"
	"fmt"
	"strings"
)

var leaveMsgHandle LeaveMessage

type LeaveMessage struct{}

// 设置扩展数据
func (l LeaveMessage) setMessageExtend(username string, items []model.LeaveMessage) []*model.LeaveMessage {
	tmpSave := make(map[string]*model.LeaveMessage, len(items))
	tmpIdSave := make(map[int]*model.LeaveMessage, len(items))
	uidArr := make([]string, 0, len(items))
	idArr := make([]int, 0, len(items))
	result := make([]*model.LeaveMessage, 0, len(items))

	for i, item := range items {
		tmpSave[item.Left] = &items[i]
		tmpIdSave[item.ID] = &items[i]
		uidArr = append(uidArr, item.Left)
		idArr = append(idArr, item.ID)
		result = append(result, &items[i])
	}

	var users []model.User
	_ = common.Db.Model(model.User{}).Where("`username` in ?", uidArr).Find(&users)
	for _, v := range users {
		tmpSave[v.Username].Ip = v.Province
	}

	if username != "" {
		var likeItems []model.LeaveMessageLike
		_ = common.Db.Model(model.LeaveMessageLike{}).Where("`uid` = ? && `leave_id` in (?)", username, idArr).Find(&likeItems)
		for _, v := range likeItems {
			tmpIdSave[v.LeaveId].IsLike = true
		}
	}
	return result
}

// Messages 获取留言板内容
func (l LeaveMessage) Messages(ctx *Ctx) (interface{}, error) {
	var req args.PageAngId
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id.Id == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	items, count := ctx.User().
		LeaveMessage().
		ListByRight(req.Id.Id, req.GetPage(), req.GetLimit())

	resp := H{"items": l.setMessageExtend(ctx.Username, items), "count": count}

	if ctx.Username != "" {
		if msg := ctx.User().LeaveMessage().GetMessage(req.Id.Id); msg.FilterMysqlNilErr() {
			return errSystem, fmt.Errorf("留言获取失败")
		} else {
			if !msg.IsMysqlNil() {
				resp["current"] = msg
			}
		}
	}
	return resp, nil
}

// Add 添加留言
func (l LeaveMessage) Add(ctx *Ctx) (interface{}, error) {
	var req struct {
		Right   string `json:"right"`
		Content string `json:"content"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Right == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if len(strings.Split(req.Content, "")) > 500 {
		return errSystem, fmt.Errorf("留言内容过长,请修改")
	}

	user := &model.User{Username: req.Right}
	user.Get()
	if user.AllowLeaveMsg == 1 {
		return errSystem, fmt.Errorf("禁止留言")
	}

	msg := &model.LeaveMessage{
		Left:    ctx.Username,
		Right:   req.Right,
		Content: req.Content,
		Updated: common.TimestampSec(),
	}
	if msg.Upsert().Err != nil {
		return errSystem, fmt.Errorf("留言失败")
	}
	return msg, nil
}

// DelOther 删除别人给自己的留言
func (l LeaveMessage) DelOther(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if msg := ctx.User().LeaveMessage().DeleteRight(req.Id); msg.Err != nil {
		return errSystem, fmt.Errorf("留言删除失败")
	}

	lml := &model.LeaveMessageLike{LeaveId: req.Id}
	lml.RemoveByLeaveId()
	return nil, nil
}

// DelMy 删除自己给别人的留言
func (l LeaveMessage) DelMy(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if msg := ctx.User().LeaveMessage().DeleteLeft(req.Id); msg.Err != nil {
		return errSystem, fmt.Errorf("留言删除失败")
	}

	lml := &model.LeaveMessageLike{LeaveId: req.Id}
	lml.RemoveByLeaveId()
	return nil, nil
}

// GetMyAll 获取我的所有留言
func (l LeaveMessage) GetMyAll(ctx *Ctx) (interface{}, error) {
	var req args.PageAngId
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}
	items, count := ctx.User().LeaveMessage().ListByLeft(ctx.Username, req.GetPage(), req.GetLimit())
	return H{"items": items, "count": count}, nil
}

// AddLike 点赞
func (l LeaveMessage) AddLike(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}

	lml := &model.LeaveMessageLike{Uid: ctx.Username, LeaveId: req.Id}
	if !lml.LoadByInfo().IsMysqlNil() {
		return errSystem, fmt.Errorf("已点赞")
	}

	lm := &model.LeaveMessage{ID: req.Id}
	if lm.LoadById().Err != nil {
		return errSystem, fmt.Errorf("数据异常")
	}

	if lml.Create().Err != nil {
		return errSystem, lml.Err
	}

	if lm.AddLikeCount(1).Err != nil {
		return errSystem, lm.Err
	}
	return nil, nil
}

// RemLike 取消点赞
func (l LeaveMessage) RemLike(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}

	lml := &model.LeaveMessageLike{Uid: ctx.Username, LeaveId: req.Id}
	if lml.LoadByInfo().Err != nil {
		return errSystem, fmt.Errorf("未点赞")
	}

	lm := &model.LeaveMessage{ID: req.Id}
	if lm.LoadById().Err != nil {
		return errSystem, fmt.Errorf("数据异常")
	}

	if lml.Remove().Err != nil {
		return errSystem, lml.Err
	}

	if lm.AddLikeCount(-1).Err != nil {
		return errSystem, lm.Err
	}
	return nil, nil
}
