package handle

import (
	"cChain/common"
	"cChain/handle/args"
	"cChain/model"
	"fmt"
)

var essayHandle Essay

type Essay struct{}

// Essay 获取短文
func (e Essay) Essay(ctx *Ctx) (interface{}, error) {
	var req args.Id
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	essay := &model.CardEssay{Uid: req.Id}
	return essay.List(), nil
}

// Add 添加短文
func (e Essay) Add(ctx *Ctx) (interface{}, error) {
	var req struct {
		Essay string `json:"essay"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	essay := &model.CardEssay{
		Uid:     ctx.Username,
		Essay:   req.Essay,
		Updated: common.TimestampSec()}
	if essay.Create().Err != nil {
		return errSystem, fmt.Errorf("短文添加失败")
	}
	return essay, nil
}

// Del 删除短文
func (e Essay) Del(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if essay := ctx.User().CardEssay().Get(req.Id); essay.Err != nil || essay.Top == 1 {
		return errSystem, fmt.Errorf("请保留一个置顶短文")
	}
	if essay := ctx.User().CardEssay().Delete(req.Id); essay.Err != nil {
		return errSystem, fmt.Errorf("短文删除失败")
	}
	return nil, nil
}

// Update 修改短文
func (e Essay) Update(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id    int    `json:"id"`
		Essay string `json:"essay"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}

	if essay := ctx.User().CardEssay().Get(req.Id).UpdateEssay(req.Essay); essay.Err != nil {
		return errSystem, fmt.Errorf("短文修改失败")
	}
	return nil, nil
}

// Topping 置顶短文
func (e Essay) Topping(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}
	if essay := ctx.User().CardEssay().Get(req.Id).Topping(); essay.Err != nil {
		return errSystem, fmt.Errorf("置顶失败")
	}
	return nil, nil
}
