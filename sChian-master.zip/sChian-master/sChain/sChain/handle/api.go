package handle

type Handle struct {
	method      func(ctx *Ctx) (interface{}, error)
	notAuth     bool // 不需要登录权限
	autoAuth    bool // 不需要登录权限,如果已登录,则加载用户数据
	notDebug    bool // debug时不要输出Body内容
	notReadBody bool // handle层不要读取Body内容
	notResp     bool // 不要写入响应内容
}

var HTTPMap = map[string]*Handle{
	"/api/auth/login":               {method: authHandle.Login, notAuth: true},
	"/api/auth/register":            {method: authHandle.Register, notAuth: true},
	"/api/auth/sendRegMsg":          {method: authHandle.SendRegisterVerifyCode, notAuth: true},
	"/api/auth/sendMsg":             {method: authHandle.SendLoginVerifyCode, notAuth: true},
	"/api/auth/exists":              {method: authHandle.CheckUserExists, notAuth: true},
	"/api/auth/forget":              {method: authHandle.Forget, notAuth: true},
	"/api/auth/forget/sendMsg":      {method: authHandle.SendForgetVerifyCode, notAuth: true},
	"/api/auth/forget/question":     {method: authHandle.ForgetQuestion, notAuth: true},
	"/api/auth/forget/question/get": {method: authHandle.GetForgetQuestion, notAuth: true},
	"/api/auth/logout":              {method: authHandle.Logout},
	"/api/auth/info":                {method: authHandle.GetInfo},
	"/api/auth/logoff":              {method: authHandle.LogOff},
	"/api/auth/info/sendMsg":        {method: authHandle.SendInfoVerifyCode},
	"/api/auth/set/password":        {method: authHandle.SetPassword},
	"/api/auth/set/phone":           {method: authHandle.SetPhone},
	"/api/auth/set/question":        {method: authHandle.SetQuestion},
	"/api/auth/set/allow/leaveMsg":  {method: authHandle.ChangeAllowLeaveMsg},
	"/api/auth/leaveMsg/status":     {method: authHandle.LeaveMsgStatus, notAuth: true},

	"/api/card/suggest":     {method: cardHandle.Suggest, autoAuth: true},
	"/api/card/refresh":     {method: cardHandle.Refresh, autoAuth: true},
	"/api/card/search":      {method: cardHandle.Search, autoAuth: true},
	"/api/card/stars/rank":  {method: cardHandle.StarsRank, autoAuth: true},
	"/api/card/update":      {method: cardHandle.UpdateCard},
	"/api/card/current":     {method: cardHandle.Current},
	"/api/card/stars":       {method: cardStarHandle.Stars},
	"/api/card/star/add":    {method: cardStarHandle.AddStar},
	"/api/card/star/cancel": {method: cardStarHandle.CancelStar},

	"/api/favorites/list":   {method: favoritesHandle.Favorites, notAuth: true},
	"/api/favorites/cancel": {method: favoritesHandle.Cancel},
	"/api/favorites/add":    {method: favoritesHandle.Add},
	"/api/favorites/update": {method: favoritesHandle.Update},
	"/api/favorites/del":    {method: favoritesHandle.Del},
	"/api/favorites/order":  {method: favoritesHandle.SetOrder},

	"/api/leave-msg/list":      {method: leaveMsgHandle.Messages, autoAuth: true},
	"/api/leave-msg/add":       {method: leaveMsgHandle.Add},
	"/api/leave-msg/del-other": {method: leaveMsgHandle.DelOther},
	"/api/leave-msg/del-my":    {method: leaveMsgHandle.DelMy},
	"/api/leave-msg/my-all":    {method: leaveMsgHandle.GetMyAll},
	"/api/leave-msg/add-like":  {method: leaveMsgHandle.AddLike},
	"/api/leave-msg/rem-like":  {method: leaveMsgHandle.RemLike},

	"/api/essay":         {method: essayHandle.Essay, notAuth: true},
	"/api/essay/add":     {method: essayHandle.Add},
	"/api/essay/del":     {method: essayHandle.Del},
	"/api/essay/update":  {method: essayHandle.Update},
	"/api/essay/topping": {method: essayHandle.Topping},

	"/api/chat/group/add":      {method: chatHandle.Group},
	"/api/chat/group/info":     {method: chatHandle.GroupInfo},
	"/api/chat/group/count":    {method: chatHandle.GroupCount},
	"/api/chat/group/cancel":   {method: chatHandle.CancelGroup},
	"/api/chat/private/add":    {method: chatHandle.Private},
	"/api/chat/private/cancel": {method: chatHandle.CancelPrivate},
	"/api/chat/private/find":   {method: chatHandle.PrivateFind},
	"/api/chat/list":           {method: chatHandle.ChatList},
	"/api/chat/register":       {method: chatHandle.Register},
	"/api/chat/sendMsg":        {method: chatHandle.SendMsg},
	"/api/chat/newMsg":         {method: chatHandle.GetNewMsg},
	"/api/chat/history":        {method: chatHandle.MsgHistory},
	"/api/chat/session/info":   {method: chatHandle.SessionInfo},

	"/api/disk/upload":     {method: diskHandle.Upload, notDebug: true, notReadBody: true},
	"/api/disk/download":   {method: diskHandle.Download, notAuth: true, notResp: true},
	"/api/disk/ls":         {method: diskHandle.Ls, autoAuth: true},
	"/api/disk/root":       {method: diskHandle.Root, notAuth: true},
	"/api/disk/show":       {method: diskHandle.GetShowURI, notAuth: true},
	"/api/disk/rm":         {method: diskHandle.Rm},
	"/api/disk/new/folder": {method: diskHandle.CreateFolder},
	"/api/disk/surplus":    {method: diskHandle.SurplusSize},
	"/api/disk/rename":     {method: diskHandle.Rename},
	"/api/disk/order":      {method: diskHandle.SetOrder},
	"/api/disk/move":       {method: diskHandle.MoveFile},

	"/api/record/address":      {method: recordHandle.Address, autoAuth: true},
	"/api/record/address/push": {method: recordHandle.LPushAddress, autoAuth: true},

	"/api/notes/set":    {method: cardNotesHandle.Set},
	"/api/notes/get":    {method: cardNotesHandle.Get},
	"/api/notes/all":    {method: cardNotesHandle.GetAll},
	"/api/notes/delete": {method: cardNotesHandle.Delete},

	"/api/sys":         {method: SysConfigHandle.Get, notAuth: true},
	"/api/search/keys": {method: searchKeyHandle.Keys, notAuth: true},
}
