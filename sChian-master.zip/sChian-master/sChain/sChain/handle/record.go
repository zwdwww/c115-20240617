package handle

import (
	"cChain/common"
	"fmt"
)

var recordHandle Record

type Record struct{}

func (r Record) Address(ctx *Ctx) (interface{}, error) {
	if ctx.Username == "" {
		return H{"province": common.GetProvince(ctx.IP()), "record": []string{}}, nil
	}
	record := ctx.User().RecordAddress().Array()
	return H{"province": common.GetProvince(ctx.IP()), "record": record}, nil
}

func (r Record) LPushAddress(ctx *Ctx) (interface{}, error) {
	if ctx.Username == "" {
		return nil, nil
	}

	var req struct {
		Address string `json:"address"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Address == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	_ = ctx.User().RecordAddress().LPush(req.Address)
	return nil, nil
}
