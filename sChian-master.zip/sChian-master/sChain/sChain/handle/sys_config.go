package handle

import (
	"encoding/json"
	"fmt"
)

var SysConfigHandle SysConfig

type SysConfig struct{}

func (s SysConfig) Get(ctx *Ctx) (interface{}, error) {
	var req struct {
		Key string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Key == "" {
		return errSystem, fmt.Errorf("参数错误")
	}

	configData := ctx.User().SysConfig().Get()
	configH := H{}
	data, _ := json.Marshal(configData)
	_ = json.Unmarshal(data, &configH)
	return H{"value": configH[req.Key]}, nil
}
