package args

import (
	"strconv"
)

// 请求参数结构

// Id Id
type Id struct {
	Id string `json:"id"`
}

func (i Id) Int() int {
	v, _ := strconv.Atoi(i.Id)
	return v
}

// Page Page-Limit
type Page struct {
	Page  int `json:"page"`
	Limit int `json:"limit"`
}

func (p Page) GetPage() int {
	if p.Page <= 0 {
		return 1
	}
	return p.Page
}

func (p Page) GetLimit() int {
	if p.Limit <= 0 {
		return 10
	}
	if p.Limit > 100 {
		return 100
	}
	return p.Limit
}

// PageAngId PageAndId
type PageAngId struct {
	Id
	Page
}

// FavReq 收藏夹参数
type FavReq struct {
	Id    int   `json:"id"`
	Order []int `json:"order"`
}
