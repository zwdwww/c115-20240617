package handle

const (
	// 成功
	success int = 0
	// 失败
	errSystem = 500
	// JWT鉴权失败
	errAuthFail = 40001
)
