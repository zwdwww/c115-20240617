package handle

import (
	"cChain/common"
	"cChain/model"
	"cChain/service"
	"fmt"
)

var chatHandle Chat

type Chat struct{}

// GroupInfo 群聊信息
func (c Chat) GroupInfo(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}

	cs := &model.ChatSession{Sid: req.Sid}
	items := cs.FindBySid()
	if cs.Err != nil {
		return errSystem, cs.Err
	}

	var peoples []string
	var master string
	for _, item := range items {
		peoples = append(peoples, item.Receiver)
	}
	if len(items) > 0 {
		peoples = append(peoples, items[0].Promoter)
		master = items[0].Promoter
	}

	if !common.InStrArray(peoples, ctx.Username) {
		return H{}, nil
	}
	return H{"Master": master, "Peoples": peoples}, nil
}

// Group 群聊
func (c Chat) Group(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if ctx.Username == req.Uid {
		return errSystem, fmt.Errorf("无法将自己加入群聊")
	}
	sess := ctx.User().ChatSession().Group(req.Uid)
	if sess.Err != nil {
		return errSystem, sess.Err
	}

	_ = ctx.User().CardExtend(req.Uid).Create(model.CardGroup)
	return nil, nil
}

// Private 私聊
func (c Chat) Private(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if ctx.Username == req.Uid {
		return errSystem, fmt.Errorf("无法将自己加入私聊")
	}
	sess := ctx.User().ChatSession().Private(req.Uid)
	if sess.Err != nil {
		if sess.Err.Error() == "私聊已存在" {
			return nil, nil
		}
		common.Loggers.Errorf("Private err=%v", sess.Err)
		return errSystem, fmt.Errorf("加入私聊失败")
	}
	_ = ctx.User().CardExtend(req.Uid).CreateSwap(model.CardPrivate)
	return nil, nil
}

// CancelGroup 取消群聊
func (c Chat) CancelGroup(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if err := ctx.User().ChatSession().CancelGroup(req.Uid).Err; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// CancelPrivate 取消私聊
func (c Chat) CancelPrivate(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if err := ctx.User().ChatSession().CancelPrivate(req.Uid).Err; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// GroupCount 群聊人数统计
func (c Chat) GroupCount(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	count := ctx.User().ChatSession().GroupCount(req.Sid)
	if count != 0 {
		// 加上创建群的人
		count++
	}
	return count, nil
}

type ChatListItem struct {
	Sid string
	Uid string
}

type ChatListResp struct {
	GroupMy    []ChatListItem
	GroupOther []ChatListItem
	Private    []ChatListItem
}

// ChatList 会话列表获取
func (c Chat) ChatList(ctx *Ctx) (interface{}, error) {
	items := ctx.User().ChatSession().ChatList()
	resp := &ChatListResp{}
	for _, item := range items {
		if item.Type == model.ChatPrivate {
			if item.Promoter == ctx.Username {
				resp.Private = append(resp.Private, ChatListItem{
					Uid: item.Receiver,
					Sid: item.Sid,
				})
			} else {
				resp.Private = append(resp.Private, ChatListItem{
					Uid: item.Promoter,
					Sid: item.Sid,
				})
			}
			continue
		}

		if item.Promoter == ctx.Username {
			resp.GroupMy = append(resp.GroupMy, ChatListItem{
				Uid: item.Receiver,
				Sid: item.Sid,
			})
			continue
		}

		resp.GroupOther = append(resp.GroupOther, ChatListItem{
			Uid: item.Promoter,
			Sid: item.Sid,
		})
	}
	return resp, nil
}

// SessionInfo 获取会话信息
func (c Chat) SessionInfo(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	cs := &model.ChatSession{}
	if cs.GetSessionBySid(req.Sid).Err != nil {
		return errSystem, cs.Err
	}
	return cs, nil
}

// PrivateFind 获取私聊会话ID
func (c Chat) PrivateFind(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	sess := ctx.User().ChatSession().FindPrivate(req.Uid)
	if sess.Err != nil {
		return errSystem, sess.Err
	}
	return sess.Sid, nil
}

// Register 注册在线
func (c Chat) Register(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	service.ChatManageService.Register(req.Sid, ctx.Username)
	return nil, nil
}

// GetNewMsg 获取最新信息
func (c Chat) GetNewMsg(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	items, wait := service.ChatManageService.Accept(req.Sid, ctx.Username)
	// wait: 3秒后在来接收一次最新消息
	return H{"items": items, "wait": wait}, nil
}

// SendMsg 发送信息
func (c Chat) SendMsg(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid string `json:"sid"`
		Msg string `json:"msg"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" || req.Msg == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	service.ChatManageService.SendMsg(model.ChatMsg{Sid: req.Sid, Uid: ctx.Username, Msg: req.Msg})
	return nil, nil
}

// MsgHistory 获取历史信息
func (c Chat) MsgHistory(ctx *Ctx) (interface{}, error) {
	var req struct {
		Sid   string `json:"sid"`
		Page  int    `json:"page"`
		Limit int    `json:"limit"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Sid == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	return ctx.User().ChatMsg().History(req.Sid, req.Page, req.Limit), nil
}
