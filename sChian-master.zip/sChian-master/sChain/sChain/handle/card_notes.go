package handle

import (
	"cChain/model"
	"fmt"
)

var cardNotesHandle CardNotes

type CardNotes struct{}

func (c CardNotes) Get(ctx *Ctx) (interface{}, error) {
	var req struct {
		Right string `json:"right"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Right == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	nodes := ctx.User().CardNotes(req.Right)
	user := &model.User{Username: req.Right}
	return H{"Ip": user.Get().Province, "Notes": nodes.Cnt}, nil
}

func (c CardNotes) Set(ctx *Ctx) (interface{}, error) {
	var req struct {
		Right string `json:"right"`
		Cnt   string `json:"cnt"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	ctx.User().CardNotes(req.Right).Update(req.Cnt)
	return nil, nil
}

func (c CardNotes) GetAll(ctx *Ctx) (interface{}, error) {
	notes := model.CardNotes{Left: ctx.Username}
	items := notes.All()
	return items, nil
}

func (c CardNotes) Delete(ctx *Ctx) (interface{}, error) {
	var req struct {
		Right string `json:"right"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	notes := &model.CardNotes{Left: ctx.Username}
	if notes.Delete(req.Right).Err != nil {
		return errSystem, notes.Err
	}
	return nil, nil
}
