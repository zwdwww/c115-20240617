package handle

import (
	"cChain/common"
	"cChain/model"
	"cChain/modules/jwt"
	"encoding/json"
	"net/http"
	"runtime/debug"
	"strings"
	"time"
)

type H map[string]interface{}

func (h H) Bytes() []byte {
	bytes, _ := json.Marshal(h)
	return bytes
}

// Intercept 路由拦截
type Intercept struct{}

func SetJwtAccessHeader(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")             //允许访问所有域
	w.Header().Add("Access-Control-Allow-Headers", "Content-Type") //header的类型
	w.Header().Add("Access-Control-Allow-Headers", "token")        //header的类型
	w.Header().Add("Access-Control-Allow-Credentials", "true")
	w.Header().Add("Access-Control-Allow-Methods", "GET, POST, PUT,DELETE,OPTIONS") //header的类型
	w.Header().Add("Content-Type", "application/json")
}

func (i Intercept) ServeHTTP(rw http.ResponseWriter, req *http.Request) {
	req.Header.Set("Access-Control-Allow-Origin", "*")
	SetJwtAccessHeader(rw)
	if strings.EqualFold(req.Method, "OPTIONS") {
		return
	}

	start := time.Now()
	ctx := &Ctx{Request: req, Response: rw}
	h, ok := HTTPMap[req.URL.Path]
	if !ok {
		common.Loggers.Warnf("not found http request, addr=%v", req.URL.Path)
		rw.Header().Set("X-Content-Type-Options", "nosniff")
		rw.WriteHeader(http.StatusNotFound)
		return
	}

	defer func() {
		ctx.ClearBody()
		if err := recover(); err != nil {
			rw.Header().Set("X-Content-Type-Options", "nosniff")
			rw.WriteHeader(http.StatusBadRequest)
			common.Loggers.Errorf("args=%v,Info=%v,Stack=%s", req.URL.Path, err, debug.Stack())
		}
	}()

	if !h.notAuth {
		if len(req.Header["Token"]) == 0 && !h.autoAuth {
			_ = ctx.WriteJSON(rw, errAuthFail, "鉴权失败")
			return
		}

		// Token解析
		authToken := req.Header.Get("Token")
		claims, err := jwt.ParseToken(authToken)
		if err != nil && !h.autoAuth {
			_ = ctx.WriteJSON(rw, errAuthFail, "鉴权失败")
			return
		}

		if common.TimestampSec() > claims.ExpiresAt {
			if !h.autoAuth {
				// 触发一下更新Token缓存
				_ = model.GetAuthToken(claims.Username)
				_ = ctx.WriteJSON(rw, errAuthFail, "认证已失效")
				return
			}
			claims.Username = ""
		}

		// Token是否是最新的
		if claims.Username != "" && model.GetAuthToken(claims.Username) != authToken {
			_ = ctx.WriteJSON(rw, errAuthFail, "认证已失效")
			return
		}
		ctx.Username = claims.Username
	}

	if !h.notReadBody {
		flag := ctx.ReadJSON(rw, req)
		if !flag {
			common.Loggers.Debugf("%v,svrConfig Agreement is not json", req.URL.Path)
			rw.Header().Set("X-Content-Type-Options", "nosniff")
			rw.WriteHeader(http.StatusBadGateway)
			return
		}
	}

	rs, err := h.method(ctx)
	common.Loggers.Debugf("args.URL.Path=%v,ms=%v", req.URL.Path, time.Since(start).Milliseconds())

	if err != nil {
		if h.notDebug {
			common.Loggers.Errorf("addr=%v,err=%v", req.URL.Path, err)
		} else {
			common.Loggers.Errorf("addr=%v,body=%s,err=%v", req.URL.Path, ctx.Body(), err)
		}
		if value, ok := rs.(int); ok {
			_ = ctx.WriteJSON(rw, value, err.Error())
			return
		}
		_ = ctx.WriteJSON(rw, errSystem, nil)
		return
	}

	if !h.notResp {
		err = ctx.WriteJSON(rw, success, rs)
		if err != nil {
			common.Loggers.Errorf("write message,err=%v, addr=%v", err, req.URL.Path)
			rw.Header().Set("X-Content-Type-Options", "nosniff")
			rw.WriteHeader(http.StatusBadRequest)
		}
	}
}
