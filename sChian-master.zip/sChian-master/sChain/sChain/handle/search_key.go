package handle

import "cChain/common"

var searchKeyHandle SearchKey

type SearchKey struct{}

func (s SearchKey) Keys(ctx *Ctx) (interface{}, error) {
	keysMap := common.Cache.Get("searchKey")
	if keysMap != nil {
		return H{"keysMap": keysMap}, nil
	}

	keysMap = ctx.User().SearchKey().Keys()
	common.Cache.Set("searchKey", keysMap, 600)
	return H{"keysMap": keysMap}, nil
}
