package handle

import (
	"cChain/common"
	"cChain/model"
	"cChain/modules/jwt"
	"encoding/json"
	"fmt"
	"gorm.io/gorm"
	"strings"
)

var authHandle Auth

type Auth struct{}

// InitCard 初始化名片数据
func (a Auth) InitCard(usr *model.User) error {
	if usr.Err != nil {
		return usr.Err
	}

	m := usr.SysConfig().Get()

	err := model.WithBegin(func(db *gorm.DB) error {
		essay := &model.CardEssay{
			Uid:     usr.Username,
			Essay:   m.CardEssay,
			Top:     1,
			Updated: common.TimestampSec(),
		}

		card := &model.Card{
			Uid:      usr.Username,
			Title:    m.CardName,
			Essay:    essay.Essay,
			Keywords: m.CardKey,
			Address:  m.CardAddress,
			Created:  essay.Updated,
			Updated:  essay.Updated,
		}

		// 关键词
		if card.Keywords != "" {
			arr := strings.Split(card.Keywords, "$$")
			keys := make([]model.CardKey, 0, len(arr))
			for _, word := range arr {
				keys = append(keys, model.CardKey{Uid: usr.Username, Key: word})
			}
			if err := db.Create(&keys).Error; err != nil {
				return err
			}
		}

		// 收藏夹
		for _, item := range m.DefaultFav {
			fav1 := &model.Favorites{
				Uid:     usr.Username,
				Key:     item.Key,
				Value:   item.Value,
				Created: common.TimestampSec(),
			}
			if err := db.Create(fav1).Error; err != nil {
				return err
			}
		}

		// 网盘默认内容
		for _, item := range m.DefaultDisk {
			disk := &model.DiskFile{}
			disk.Get(item.DiskId)
			if disk.Err == nil {
				rel := &model.DiskRel{
					Uid:          usr.Username,
					Parent:       "/public",
					FileName:     item.DiskName,
					FileMd5:      disk.FileMd5,
					FileByteSize: disk.FileByteSize,
					FileType:     disk.FileType,
					Created:      common.TimestampSec(),
				}
				size := usr.DiskSize()
				rel.Create(size)
				_ = disk.AddCount(1)
			}
		}

		if err := db.Create(essay).Error; err != nil {
			return err
		}
		if err := db.Create(card).Error; err != nil {
			return err
		}
		return nil
	})
	return err
}

func (a Auth) SendRegisterVerifyCode(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
		Phone    string `json:"phone"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Phone == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	user := &model.User{Username: req.Username}
	if !user.Get().IsMysqlNil() {
		return errSystem, fmt.Errorf("ID已被注册")
	}

	if !a.checkSendMsg60Seconds(req.Phone) {
		return errSystem, fmt.Errorf("发送频繁,请稍后重试")
	}

	if err := a.sendMsgAndSetCache(req.Phone, req.Phone, "register"); err != nil {
		common.Loggers.Errorf("sendMsg err: %v", err)
		return errSystem, fmt.Errorf("短信发送失败")
	}
	return nil, nil
}

// 检查用户ID是否正确
func (a Auth) checkUserId(id string) bool {
	length := len(id)
	if !(length >= 7 && length <= 13) {
		return false
	}
	id = strings.Replace(id, "-", "", 1)
	return common.DefaultInt64Zero(id) != 0
}

// Register 注册ID
func (a Auth) Register(ctx *Ctx) (interface{}, error) {
	var req struct {
		Type       string `json:"type"`
		Username   string `json:"username"`
		Phone      string `json:"phone"`
		Password   string `json:"password"`
		VerifyCode string `json:"verifyCode"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	req.Password = strings.ToLower(req.Password)

	// 手机号注册
	if req.Type == "0" {
		if !common.IsPhone(req.Username) || !a.checkUserId(req.Username) {
			return errSystem, fmt.Errorf("请输入正确的手机号")
		}
	} else if req.Type == "1" { // 其他数字注册(不能是手机号)
		if !a.checkUserId(req.Username) || common.IsPhone(req.Username) {
			return errSystem, fmt.Errorf("7~13位数字(非手机号)")
		}
	} else {
		return errSystem, fmt.Errorf("注册选项异常")
	}

	if !a.checkVerifyCode(req.Phone, req.VerifyCode) {
		return errSystem, fmt.Errorf("验证码错误")
	}

	user := &model.User{Username: req.Username, Phone: req.Phone}
	user.SetPassword(req.Password)
	user.Ip = ctx.IP()
	user.Province = common.GetProvince(user.Ip)
	user.Create()
	_ = a.InitCard(user)
	a.removeMsgVerifyCode(req.Phone)

	token, err := a.getAuthToken(user)
	if err != nil {
		common.Loggers.Errorf("token生成失败: err=%v", err)
		return errSystem, fmt.Errorf("系统异常")
	}
	return H{"token": token, "username": user.Username, "phone": user.Phone, "question": user.Question}, nil
}

type LoginReq struct {
	Username   string `json:"username"`
	Password   string `json:"password"`
	VerifyCode string `json:"verifyCode"`
}

// 验证码登录
func (a Auth) loginByVerifyCode(ctx *Ctx, req *LoginReq) (user *model.User, err error) {
	if req.Username == "" || req.VerifyCode == "" {
		return nil, fmt.Errorf("参数异常")
	}

	if !a.checkVerifyCode(req.Username, req.VerifyCode) {
		return nil, fmt.Errorf("验证码错误")
	}

	user = &model.User{Username: req.Username}
	if user.Get().Err != nil {
		if user.IsMysqlNil() {
			return nil, fmt.Errorf("ID未注册")
		}
		return nil, fmt.Errorf("系统异常")
	}

	user.UpdateIp(ctx.IP())
	return user, user.Err
}

// 密码登录
func (a Auth) loginByPassword(ctx *Ctx, req *LoginReq) (user *model.User, err error) {
	if req.Username == "" || req.Password == "" {
		return nil, fmt.Errorf("参数异常")
	}

	user = &model.User{Username: req.Username}
	if user.Get().Err != nil {
		if user.IsMysqlNil() {
			return nil, fmt.Errorf("ID未注册")
		}
		return nil, fmt.Errorf("系统异常")
	}

	if user.Verify(req.Password).Err != nil {
		return nil, fmt.Errorf("密码错误")
	}
	user.UpdateIp(ctx.IP())
	return user, user.Err
}

// SendLoginVerifyCode 发送登录短信验证码
func (a Auth) SendLoginVerifyCode(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	user := &model.User{Username: req.Username}
	if user.Get().Err != nil {
		if user.IsMysqlNil() {
			return errSystem, fmt.Errorf("ID未注册")
		}
		return errSystem, fmt.Errorf("系统异常")
	}
	if !a.checkSendMsg60Seconds(req.Username) {
		return errSystem, fmt.Errorf("发送频繁,请稍后重试")
	}
	if err := a.sendMsgAndSetCache(req.Username, user.Phone, "login"); err != nil {
		common.Loggers.Errorf("sendMsg err: %v", err)
		return errSystem, fmt.Errorf("短信发送失败")
	}
	return nil, nil
}

func (a Auth) getAuthToken(user *model.User) (string, error) {
	token, seconds, err := jwt.GenerateToken(user)
	if err != nil {
		return "", err
	}
	if err = model.SetAuthToken(user.Username, seconds, token); err != nil {
		return "", err
	}
	return token, nil
}

// Login 登录
func (a Auth) Login(ctx *Ctx) (interface{}, error) {
	var req LoginReq
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数异常")
	}

	req.Password = strings.ToLower(req.Password)

	var user *model.User
	var err error
	if req.VerifyCode != "" {
		user, err = a.loginByVerifyCode(ctx, &req)
	} else if req.Password != "" {
		user, err = a.loginByPassword(ctx, &req)
	} else {
		return errSystem, fmt.Errorf("登录异常")
	}

	if err != nil {
		return errSystem, err
	}

	a.removeMsgVerifyCode(user.Username)

	token, err := a.getAuthToken(user)
	if err != nil {
		common.Loggers.Errorf("token生成失败: err=%v", err)
		return errSystem, fmt.Errorf("系统异常")
	}
	return H{"token": token, "username": user.Username, "phone": user.Phone, "question": user.Question}, nil
}

// CheckUserExists 检查查链ID是否存在
func (a Auth) CheckUserExists(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	user := &model.User{Username: req.Username}
	return !user.Get().IsMysqlNil(), nil
}

// 发送短信
func (a Auth) sendMsgAndSetCache(username, phone string, sendType string) (err error) {
	var sessionId string

	if sendType == "login" {
		sessionId, err = common.RongYunApi.SendMsg(phone, common.Config.RongYun.LoginTemp)
	} else if sendType == "forget" {
		sessionId, err = common.RongYunApi.SendMsg(phone, common.Config.RongYun.ForgetTemp)
	} else if sendType == "info" {
		sessionId, err = common.RongYunApi.SendMsg(phone, common.Config.RongYun.InfoTemp)
	} else if sendType == "register" {
		sessionId, err = common.RongYunApi.SendMsg(phone, common.Config.RongYun.RegisterTemp)
	} else {
		panic(fmt.Sprintf("SendMsg sendType err: type=%v", sendType))
	}
	// 有效期15分钟
	common.VerifyCodeCache.Set(username, sessionId, 900)
	return err
}

// 验证短信验证码
func (a Auth) checkVerifyCode(username, verifyCode string) bool {
	sessionId := common.VerifyCodeCache.Get(username)
	if sessionId == nil {
		return false
	}
	return common.RongYunApi.VerifyCode(sessionId.(string), verifyCode)
}

// 检查发送短信是否已间隔60秒
func (a Auth) checkSendMsg60Seconds(username string) bool {
	value := common.VerifyCodeCache.GetSeconds(username)
	if value == 0 {
		return true
	}
	return value > 60
}

// 删除短信验证码
func (a Auth) removeMsgVerifyCode(username string) {
	common.VerifyCodeCache.Remove(username)
}

// SendInfoVerifyCode 发送信息修改验证码
func (a Auth) SendInfoVerifyCode(ctx *Ctx) (interface{}, error) {
	if !a.checkSendMsg60Seconds(ctx.Username) {
		return errSystem, fmt.Errorf("发送频繁,请稍后重试")
	}
	user := ctx.User().Get()
	if user.Err != nil {
		return errSystem, user.Err
	}
	if err := a.sendMsgAndSetCache(ctx.Username, user.Phone, "info"); err != nil {
		common.Loggers.Errorf("sendMsg err: %v", err)
		return errSystem, fmt.Errorf("短信发送失败")
	}
	return nil, nil
}

// GetForgetQuestion 获取密保问题
func (a Auth) GetForgetQuestion(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	user := model.User{Username: req.Username}
	question := user.Get().GetQuestion()
	if question == "" {
		return []string{}, nil
	}

	var keys []string
	resp := H{}
	_ = json.Unmarshal([]byte(question), &resp)
	for key := range resp {
		keys = append(keys, key)
	}
	return keys, nil
}

// ForgetQuestion 通过密保问题充值密码
func (a Auth) ForgetQuestion(ctx *Ctx) (interface{}, error) {
	var req struct {
		QuestionOne   string `json:"questionOne"`
		AnswerOne     string `json:"answerOne"`
		QuestionTwo   string `json:"questionTwo"`
		AnswerTwo     string `json:"answerTwo"`
		QuestionThree string `json:"questionThree"`
		AnswerThree   string `json:"answerThree"`
		Username      string `json:"username"`
		Password      string `json:"password"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" || len(req.Password) < 6 {
		return errSystem, fmt.Errorf("参数异常")
	}

	user := model.User{Username: req.Username}
	question := user.Get().GetQuestion()
	if question == "" {
		return errSystem, fmt.Errorf("密保错误")
	}

	questionMap := map[string]string{}
	_ = json.Unmarshal([]byte(question), &questionMap)

	if len(questionMap) == 0 {
		return errSystem, fmt.Errorf("密保错误")
	}

	if req.QuestionOne == "" || questionMap[req.QuestionOne] != req.AnswerOne {
		return errSystem, fmt.Errorf("问题1错误")
	}

	if req.QuestionTwo == "" || questionMap[req.QuestionTwo] != req.AnswerTwo {
		return errSystem, fmt.Errorf("问题2错误")
	}

	if req.QuestionThree == "" || questionMap[req.QuestionThree] != req.AnswerThree {
		return errSystem, fmt.Errorf("问题3错误")
	}
	if user.UpdatePassword(req.Password).Err != nil {
		return errSystem, user.Err
	}
	return nil, nil
}

// Forget 密码忘记重置
func (a Auth) Forget(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username   string `json:"username"`
		VerifyCode string `json:"verifyCode"`
		Password   string `json:"password"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" || req.VerifyCode == "" {
		return errSystem, fmt.Errorf("参数异常")
	}
	if !a.checkVerifyCode(req.Username, req.VerifyCode) {
		return errSystem, fmt.Errorf("验证码错误")
	}
	user := &model.User{Username: req.Username}
	user.UpdatePassword(req.Password)
	a.removeMsgVerifyCode(user.Username)
	return nil, nil
}

// SendForgetVerifyCode 发送忘记密码手机短信验证码
func (a Auth) SendForgetVerifyCode(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	user := &model.User{Username: req.Username}
	if user.Get().IsMysqlNil() {
		return errSystem, fmt.Errorf("查链ID不存在")
	}
	if user.Err != nil {
		return errSystem, user.Err
	}

	if !a.checkSendMsg60Seconds(user.Username) {
		return errSystem, fmt.Errorf("发送频繁,请稍后重试")
	}
	if err := a.sendMsgAndSetCache(user.Username, user.Phone, "forget"); err != nil {
		common.Loggers.Errorf("sendMsg err: %v", err)
		return errSystem, fmt.Errorf("短信发送失败")
	}
	return nil, nil
}

// SetPassword 设置密码
func (a Auth) SetPassword(ctx *Ctx) (interface{}, error) {
	var req struct {
		Password   string `json:"password"`
		VerifyCode string `json:"verifyCode"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || len(req.Password) < 6 || req.VerifyCode == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	if !a.checkVerifyCode(fmt.Sprintf("%v", ctx.Username), req.VerifyCode) {
		return errSystem, fmt.Errorf("验证码错误")
	}
	a.removeMsgVerifyCode(ctx.Username)

	if usr := ctx.User().UpdatePassword(req.Password); usr.Err != nil {
		common.Loggers.Errorf("resetPassword uid=%v,err=%v", usr.Username, usr.Err)
		return errSystem, fmt.Errorf("修改i失败")
	}
	return nil, nil
}

// SetPhone 设置手机号
func (a Auth) SetPhone(ctx *Ctx) (interface{}, error) {
	var req struct {
		Phone      string `json:"phone"`
		VerifyCode string `json:"verifyCode"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.VerifyCode == "" || len(req.Phone) != 11 {
		return errSystem, fmt.Errorf("参数异常")
	}

	if common.DefaultInt64Zero(req.Phone) == 0 {
		return errSystem, fmt.Errorf("参数异常")
	}

	if !a.checkVerifyCode(fmt.Sprintf("%v", ctx.Username), req.VerifyCode) {
		return errSystem, fmt.Errorf("验证码错误")
	}
	a.removeMsgVerifyCode(ctx.Username)

	if err := ctx.User().UpdatePhone(req.Phone).Err; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// SetQuestion 设置密保
func (a Auth) SetQuestion(ctx *Ctx) (interface{}, error) {
	var req struct {
		QuestionOne         string `json:"questionOne"`
		QuestionTwo         string `json:"questionTwo"`
		QuestionThree       string `json:"questionThree"`
		QuestionOneAnswer   string `json:"questionOneAnswer"`
		QuestionTwoAnswer   string `json:"questionTwoAnswer"`
		QuestionThreeAnswer string `json:"questionThreeAnswer"`
		VerifyCode          string `json:"verifyCode"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.VerifyCode == "" {
		return errSystem, fmt.Errorf("参数异常")
	}

	if !a.checkVerifyCode(fmt.Sprintf("%v", ctx.Username), req.VerifyCode) {
		return errSystem, fmt.Errorf("验证码错误")
	}
	a.removeMsgVerifyCode(ctx.Username)

	questionMap := map[string]string{
		req.QuestionOne:   req.QuestionOneAnswer,
		req.QuestionTwo:   req.QuestionTwoAnswer,
		req.QuestionThree: req.QuestionThreeAnswer,
	}
	bytes, _ := json.Marshal(questionMap)
	if err := ctx.User().UpdateQuestion(string(bytes)).Err; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// LogOff 注销账号
func (a Auth) LogOff(ctx *Ctx) (interface{}, error) {
	if err := ctx.User().LogOff().Err; err != nil {
		common.Loggers.Errorf("logOff uid=%v,err=%v", ctx.Username, err)
		return errSystem, fmt.Errorf("注销失败")
	}
	common.Loggers.Warnf("logOff Success uid=%v", ctx.Username)
	return nil, nil
}

// GetInfo 获取用户信息
func (a Auth) GetInfo(ctx *Ctx) (interface{}, error) {
	user := ctx.User().Get()
	return H{
		"username":      user.Username,
		"phone":         user.Phone,
		"question":      user.GetQuestion(),
		"allowLeaveMsg": user.AllowLeaveMsg,
	}, nil
}

// ChangeAllowLeaveMsg 修改留言权限
func (a Auth) ChangeAllowLeaveMsg(ctx *Ctx) (interface{}, error) {
	var req struct {
		Status int `json:"status"`
	}
	_ = ctx.JSONUnmarshal(&req)

	user := ctx.User().UpdateAllowLeaveMsg(int16(req.Status))
	if user.Err != nil {
		return errSystem, user.Err
	}
	return nil, nil
}

// Logout 退出登录
func (a Auth) Logout(ctx *Ctx) (interface{}, error) {
	if err := model.RemoveAuthToken(ctx.Username); err != nil {
		return errSystem, fmt.Errorf("登出异常")
	}
	return nil, nil
}

// LeaveMsgStatus 留言状态
func (a Auth) LeaveMsgStatus(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	_ = ctx.JSONUnmarshal(&req)
	user := &model.User{Username: req.Uid}
	user.Get()
	return user.AllowLeaveMsg, nil
}
