package model

import (
	"cChain/common"
	"gorm.io/gorm"
)

// CardKey 名片关键词
type CardKey struct {
	ID  int
	Uid string
	Key string
	Base
}

func (c *CardKey) Clear(uid string, db *gorm.DB) error {
	return db.Model(c).Where(CardKey{Uid: uid}).Delete(c).Error
}

func (c *CardKey) Find(key string) (items []string) {
	c.Err = common.Db.Model(c).Where("key = ?", key).Select("uid").Find(&items).Error
	return
}
