package model

import (
	"cChain/common"
	"encoding/json"
	"gorm.io/gorm"
)

// DiskOrder 链盘文件排序
type DiskOrder struct {
	ID    int
	Uid   string
	Path  string
	Order []byte
	Base
}

func (d *DiskOrder) Clear(uid string, db *gorm.DB) error {
	return db.Model(d).Where(DiskOrder{Uid: uid}).Delete(d).Error
}

func (d *DiskOrder) OrderArray() (items []int) {
	if d.Err != nil {
		return []int{}
	}
	_ = json.Unmarshal(d.Order, &items)
	return
}

func (d *DiskOrder) Get(path string) *DiskOrder {
	if d.Err != nil {
		return d
	}
	d.Err = common.Db.
		Where(DiskOrder{Uid: d.Uid, Path: path}).
		First(d).Error
	return d
}

// Upsert 更新或插入
func (d *DiskOrder) Upsert(path string, order []int) *DiskOrder {
	if d.Err != nil {
		return d
	}
	orderBytes, _ := json.Marshal(order)
	d.Err = common.Db.Where(DiskOrder{Uid: d.Uid, Path: path}).First(d).Error
	if d.IsMysqlNil() {
		d.Err = nil
		d.Order = orderBytes
		d.Path = path
		d.Err = common.Db.Create(d).Error
		return d
	} else if d.Err == nil {
		d.Order = orderBytes
		d.Err = common.Db.Model(d).Update("order", d.Order).Error
	}
	return d
}
