package model

import "cChain/common"

type ChatMsg struct {
	ID      int
	Uid     string // 发消息人
	Sid     string // 会话ID
	Msg     string // 消息内容
	Created int64  // 发消息时间
	Base
}

func (c *ChatMsg) Create() *ChatMsg {
	if c.Err != nil {
		return c
	}
	c.Created = common.TimestampSec()
	c.Err = common.Db.Create(c).Error
	return c
}

func (c *ChatMsg) History(sid string, page, limit int) (items []ChatMsg) {
	if c.Err != nil {
		return []ChatMsg{}
	}
	if page <= 0 {
		page = 1
	}
	if limit > 20 || limit <= 0 {
		limit = 20
	}
	c.Err = common.Db.Where(ChatMsg{Sid: sid}).
		Order("created desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

func (c *ChatMsg) LoadSessionReceiver() []string {
	if c.Err != nil {
		return []string{}
	}

	var items []ChatSession
	c.Err = common.Db.Where(ChatSession{Sid: c.Sid}).Find(&items).Error

	uidArr := make([]string, 0, len(items)+1)
	for _, item := range items {
		uidArr = append(uidArr, item.Receiver)
	}
	if len(items) != 0 {
		uidArr = append(uidArr, items[0].Promoter)
	}
	return uidArr
}
