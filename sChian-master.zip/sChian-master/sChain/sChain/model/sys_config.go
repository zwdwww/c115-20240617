package model

import (
	"cChain/common"
	"encoding/json"
)

type SysConfigDiskItem struct {
	DiskName string
	DiskId   string
}

type SysConfigFavItem struct {
	Key   string
	Value string
}

type SysConfigData struct {
	DefaultDisk     []SysConfigDiskItem
	DefaultFav      []SysConfigFavItem
	TopDbLink       string // 上链库
	DownDbLink      string // 上链库
	LibraryLink     string // 文库
	DefaultDiskSize string // 链盘默认大小
	CardName        string
	CardAddress     string
	CardKey         string
	CardEssay       string
	ID404           string
	Name404         string
	Address404      string
	Key404          string
	Essay404        string
}

// SysConfig 系统参数
type SysConfig struct {
	ID   int
	Data []byte
	Base
}

func (s *SysConfig) Get() *SysConfigData {
	if s.Err != nil {
		return &SysConfigData{}
	}

	s.Err = common.Db.Model(s).First(s, "id = 1").Error
	if s.IsMysqlNil() {
		s.Err = nil
		def := s.Default()
		bytes, _ := json.Marshal(def)
		s.Err = common.Db.Create(SysConfig{
			ID:   1,
			Data: bytes,
		}).Error
		return &def
	}

	m := SysConfigData{}
	_ = json.Unmarshal(s.Data, &m)
	return &m
}

func (s *SysConfig) Card404() *Card {
	m := s.Get()
	return &Card{
		ID:       0,
		Uid:      m.ID404,
		Title:    m.Name404,
		Address:  m.Address404,
		Keywords: m.Key404,
		Essay:    m.Essay404,
		Created:  common.TimestampSec(),
		Updated:  common.TimestampSec(),
	}
}

func (s *SysConfig) Default() SysConfigData {
	return SysConfigData{
		DefaultDisk: []SysConfigDiskItem{},
		DefaultFav: []SysConfigFavItem{
			{Key: "在线wetab", Value: "https://web.wetab.link/"},
			{Key: "360导航", Value: "https://hao.360.com/"},
		},
		TopDbLink:       "https://www.toutiao.com/",
		DownDbLink:      "https://www.toutiao.com/",
		LibraryLink:     "https://www.toutiao.com/",
		DefaultDiskSize: "40",
		CardName:        "",
		CardAddress:     "北京>地址1>地址2>地址3>地址4",
		CardKey:         "网友$$交友$$空缺",
		CardEssay:       "敬告：请遵守国家的法律法规、遵守社会的基本公允良俗，遵守同类网站的基本规则，善待他人，保护自己。有问题联系站长：13017181618.115.cn  共享助理 1111.115.cn 测试本站请单击：12345678.115.cn （密码8个8）",
		ID404:           "404",
		Name404:         "404",
		Address404:      "北京>地址1>地址2>地址3>地址4",
		Key404:          "网友$$交友$$空缺",
		Essay404:        "敬告：请遵守国家的法律法规、遵守社会的基本公允良俗，遵守同类网站的基本规则，善待他人，保护自己。有问题联系站长：13017181618.115.cn  共享助理 1111.115.cn 测试本站请单击：12345678.115.cn （密码8个8）",
	}
}
