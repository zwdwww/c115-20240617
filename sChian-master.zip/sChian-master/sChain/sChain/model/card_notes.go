package model

import "cChain/common"

// CardNotes 备注
type CardNotes struct {
	ID    int
	Left  string
	Right string
	Cnt   string
	Base
}

func (c *CardNotes) Update(cnt string) *CardNotes {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(c).Where("id = ?", c.ID).Update("cnt", cnt).Error
	return c
}

func (c *CardNotes) All() (items []CardNotes) {
	c.Err = common.Db.Model(c).Where("`left` = ?", c.Left).Find(&items).Error
	return
}

func (c *CardNotes) Delete(right string) *CardNotes {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(c).
		Where("`left` = ? and `right` = ?", c.Left, right).
		Delete(c).Error
	return c
}
