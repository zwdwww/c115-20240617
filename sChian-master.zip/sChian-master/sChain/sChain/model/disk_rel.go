package model

import (
	"cChain/common"
	"fmt"
	"gorm.io/gorm"
)

// DiskRel 链盘文件的虚拟路径关系
type DiskRel struct {
	ID           int
	Uid          string
	Parent       string
	FileName     string
	FileMd5      string
	FileByteSize int64
	FileType     string
	Created      int64
	Base
}

func (d *DiskRel) Clear(uid string, db *gorm.DB) error {
	var md5Arr []string
	if err := db.Model(d).Where(DiskRel{Uid: uid}).Select("file_md5").Find(&md5Arr).Error; err != nil {
		return err
	}
	if len(md5Arr) != 0 {
		var files []DiskFile
		if err := db.Model(DiskFile{}).Where("file_md5 in ?", md5Arr).Find(&files).Error; err != nil {
			return err
		}
		var delArr []string
		for _, file := range files {
			if file.Count == 1 {
				file.RemoveMd5File()
				delArr = append(delArr, file.FileMd5)
			} else {
				file.Count--
				if err := db.Model(DiskFile{}).Where(DiskFile{FileMd5: file.FileMd5}).Update("count", file.Count).Error; err != nil {
					return err
				}
			}
		}
		if len(delArr) != 0 {
			file := &DiskFile{}
			if err := db.Model(file).Where("file_md5 in ?", delArr).Delete(files).Error; err != nil {
				return err
			}
		}
	}
	return db.Model(d).Where(DiskRel{Uid: uid}).Delete(d).Error
}

func (d *DiskRel) Get(id int) *DiskRel {
	if d.Err != nil {
		return d
	}
	d.Err = common.Db.Model(DiskRel{}).Where(DiskRel{Uid: d.Uid, ID: id}).First(d).Error
	return d
}

func (d *DiskRel) Create(size *DiskSize) *DiskRel {
	if d.Err != nil {
		return d
	}

	d.Created = common.TimestampSec()
	d.Err = WithBegin(func(db *gorm.DB) error {
		if err := db.Create(d).Error; err != nil {
			return err
		}
		size.UsedSize += d.FileByteSize
		return db.Model(DiskSize{}).Where(DiskSize{Uid: d.Uid}).Update("used_size", size.UsedSize).Error
	})
	return d
}

// FindByParent 根据路径获取子文件
func (d *DiskRel) FindByParent(parent string) (items []DiskRel) {
	if d.Err != nil {
		return []DiskRel{}
	}
	d.Err = common.Db.Model(d).
		Where(DiskRel{Uid: d.Uid, Parent: parent}).
		Find(&items).Error
	return
}

func (d *DiskRel) factCollectDir(rel DiskRel, collect func([]DiskRel)) error {
	var items []DiskRel
	parent := fmt.Sprintf("%v/%v", rel.Parent, rel.FileName)
	if err := common.Db.Model(d).Where("parent = ?", parent).Find(&items).Error; err != nil {
		return err
	}
	collect(items)
	for _, item := range items {
		if item.FileType == "dir" {
			if err := d.factCollectDir(item, collect); err != nil {
				return err
			}
		}
	}
	return nil
}

// Remove 删除
func (d *DiskRel) Remove() *DiskRel {
	if d.Err != nil {
		return d
	}

	// 所有需要被删除的ID
	var needRmId = []int{d.ID}
	var fileCount = map[string]int{}

	// 删除目录下所有的文件
	if d.FileType == "dir" {
		d.Err = d.factCollectDir(*d, func(relArr []DiskRel) {
			for _, rel := range relArr {
				needRmId = append(needRmId, rel.ID)
				if rel.FileType != "dir" {
					fileCount[rel.FileMd5]++
				}
			}
		})
		if d.Err != nil {
			return d
		}
	} else {
		fileCount[d.FileMd5]++
	}

	// 获取逻辑对象
	var allRelObj []DiskRel
	var fileByteSize = int64(0)
	d.Err = common.Db.Model(DiskRel{}).Where("uid = ? && id in ?", d.Uid, needRmId).Find(&allRelObj).Error
	if d.Err != nil {
		return d
	}
	for _, rel := range allRelObj {
		fileByteSize += rel.FileByteSize
	}

	// 事务删除更新
	d.Err = WithBegin(func(db *gorm.DB) error {
		tmp := &DiskRel{}
		if err := db.Model(tmp).
			Where("uid = ? && id in ?", d.Uid, needRmId).
			Delete(tmp).Error; err != nil {
			return err
		}

		// 更新剩余空间
		user := &User{Username: d.Uid}
		size := user.DiskSize()
		size.UsedSize -= fileByteSize
		if err := db.Model(DiskSize{}).
			Where(DiskSize{Uid: d.Uid}).
			Update("used_size", size.UsedSize).Error; err != nil {
			return err
		}

		// 删除/更新物理存储
		for md5, count := range fileCount {
			file := user.DiskFile().Get(md5)
			file.Count -= count
			if file.Count == 0 {
				file.Err = file.RemoveMd5File().Delete().Err
			} else {
				file.Err = db.Model(DiskFile{}).
					Where(DiskFile{FileMd5: file.FileMd5}).
					Update("count", file.Count).Error
			}
			if file.Err != nil {
				return file.Err
			}
		}
		return nil
	})
	return d
}

// Rename 重命名
func (d *DiskRel) Rename(newName string) *DiskRel {
	if d.Err != nil {
		return d
	}

	if d.FileType == "dir" {
		oldParent := fmt.Sprintf("%v/%v", d.Parent, d.FileName)
		newParent := fmt.Sprintf("%v/%v", d.Parent, newName)
		d.Err = common.Db.Exec(
			"update disk_rel set parent = replace(parent, ?, ?) where uid = ? && parent like '"+oldParent+"%'",
			oldParent,
			newParent,
			d.Uid).Error
		if d.Err != nil {
			return d
		}
	}

	d.Err = common.Db.Model(DiskRel{}).
		Where(DiskRel{Uid: d.Uid, ID: d.ID}).
		Update("file_name", newName).Error
	return d
}

// Move 移动
func (d *DiskRel) Move(toPath string) *DiskRel {
	if d.Err != nil {
		return d
	}

	if d.FileType == "dir" {
		var check DiskRel
		check.Err = common.Db.Model(DiskRel{}).Where(DiskRel{
			Uid:      d.Uid,
			Parent:   toPath,
			FileName: d.FileName,
		}).First(&check).Error
		if check.Err == nil {
			d.Err = fmt.Errorf("移动异常,目录已存在同名文件夹")
			return d
		}

		// 子文件目录路径修改
		oldParent := fmt.Sprintf("%v/%v", d.Parent, d.FileName)
		newParent := fmt.Sprintf("%v/%v", toPath, d.FileName)
		d.Err = common.Db.Exec(
			"update disk_rel set parent = replace(parent, ?, ?) where uid = ? && parent like '"+oldParent+"%'",
			oldParent,
			newParent,
			d.Uid).Error
		if d.Err != nil {
			return d
		}
	}

	d.Err = common.Db.Model(DiskRel{}).
		Where(DiskRel{Uid: d.Uid, ID: d.ID}).
		Update("parent", toPath).Error
	return d
}
