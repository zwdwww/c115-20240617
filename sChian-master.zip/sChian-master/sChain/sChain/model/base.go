package model

import (
	"cChain/common"
	"errors"
	"gorm.io/gorm"
)

type H map[string]interface{}

// LogOff 注销
type LogOff interface {
	Clear(uid string, db *gorm.DB) error
}

type Base struct {
	Err error `gorm:"-" json:"-"`
}

func (b *Base) FilterMysqlNilErr() bool {
	return b.Err != nil && !b.IsMysqlNil()
}

func (b *Base) IsMysqlNil() bool {
	return errors.Is(b.Err, gorm.ErrRecordNotFound)
}

// WithBegin MySQL事务
func WithBegin(f func(db *gorm.DB) error) error {
	tx := common.Db.Begin()
	err := f(tx)
	if err != nil {
		tx.Rollback()
	} else {
		tx.Commit()
	}
	return err
}
