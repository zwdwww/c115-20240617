package model

import (
	"cChain/common"
	"encoding/json"
	"gorm.io/gorm"
)

// RecordAddress 记录点击地址
type RecordAddress struct {
	ID      int
	Uid     string
	Address []byte
	Base
}

func (r *RecordAddress) Clear(uid string, db *gorm.DB) error {
	return db.Model(r).Where(RecordAddress{Uid: uid}).Delete(r).Error
}

func (r *RecordAddress) Get() *RecordAddress {
	if r.Err != nil {
		return r
	}
	r.Err = common.Db.Where(RecordAddress{Uid: r.Uid}).First(r).Error
	return r
}

func (r *RecordAddress) Array() (items []string) {
	if r.Err != nil {
		return []string{}
	}
	_ = json.Unmarshal(r.Address, &items)
	return
}

// LPush 新增点击记录
func (r *RecordAddress) LPush(addr string) *RecordAddress {
	if r.Err != nil {
		return r
	}

	arr := r.Array()
	for _, v := range arr {
		if addr == v {
			return r
		}
	}

	tmp := make([]string, 0, 3)
	tmp = append(tmp, addr)

	if len(arr) < 3 {
		arr = append(tmp, arr...)
	} else {
		arr = arr[:2]
		arr = append(tmp, arr...)
	}
	bytes, _ := json.Marshal(arr)
	r.Address = bytes
	r.Err = common.Db.Model(RecordAddress{}).Where(RecordAddress{Uid: r.Uid}).Update("address", bytes).Error
	return r
}
