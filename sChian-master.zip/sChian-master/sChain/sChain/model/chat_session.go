package model

import (
	"cChain/common"
	"errors"
	"fmt"
	"gorm.io/gorm"
)

const (
	ChatPrivate = 1 // 私聊
	ChatGroup   = 2 // 群聊
)

type ChatSession struct {
	ID       int
	Sid      string
	Promoter string // 会话发起者
	Receiver string // 会话接收者
	Type     int    // 会话类型
	Created  int64
	Base
}

func (c *ChatSession) Clear(uid string, db *gorm.DB) error {
	var delSid []string
	// 删除该用户发起的所有会话
	var tmp1 []string
	if err := db.Model(c).Where("`promoter` = ?", uid).Select("sid").Find(&tmp1).Error; err != nil {
		return err
	}
	if err := db.Model(c).Where("`promoter` = ?", uid).Delete(c).Error; err != nil {
		return err
	}
	// 删除其他用户向该用户发起的私聊
	var tmp2 []string
	if err := db.Model(c).Where("`receiver` = ? && `type` = ?", uid, ChatPrivate).Select("sid").Find(&tmp2).Error; err != nil {
		return err
	}
	if err := db.Model(c).Where("`receiver` = ? && `type` = ?", uid, ChatPrivate).Delete(c).Error; err != nil {
		return err
	}

	// 删除该用户相关的会话
	msg := &ChatMsg{}
	if len(tmp1) != 0 {
		delSid = append(delSid, tmp1...)
	}
	if len(tmp2) != 0 {
		delSid = append(delSid, tmp2...)
	}
	if len(delSid) != 0 {
		if err := db.Model(msg).Where("`sid` in ?", delSid).Delete(msg).Error; err != nil {
			return err
		}
	}

	// 将该用户发的消息改成404用户
	if err := db.Model(msg).Where("`uid` = ?", uid).Update("uid", 404).Error; err != nil {
		return err
	}
	return nil
}

// Group 群聊
func (c *ChatSession) Group(receiver string) *ChatSession {
	if c.Err != nil {
		return c
	}

	c.Err = common.Db.Where(ChatSession{Promoter: c.Promoter, Receiver: receiver, Type: ChatGroup}).First(c).Error
	if c.Err == nil {
		c.Err = fmt.Errorf("群聊已存在")
		return c
	}

	// 获取自己的群聊ID
	tmpErr := common.Db.Where(ChatSession{Promoter: c.Promoter, Type: ChatGroup}).First(c).Error
	if errors.Is(tmpErr, gorm.ErrRecordNotFound) {
		c.Sid = common.SnowStringID()
	} else {
		sess := &ChatSession{}
		if sess.GroupCount(c.Sid) >= 2000 {
			c.Err = fmt.Errorf("群聊人数已达上限")
			return c
		}
	}

	if c.IsMysqlNil() {
		c.Err = common.Db.Create(&ChatSession{
			Promoter: c.Promoter,
			Receiver: receiver,
			Type:     ChatGroup,
			Sid:      c.Sid,
			Created:  common.TimestampSec(),
		}).Error
	}
	return c
}

// CancelGroup 取消群聊
func (c *ChatSession) CancelGroup(receiver string) *ChatSession {
	if c.Err != nil {
		return c
	}

	count := int64(0)
	c.Err = common.Db.Model(c).
		Where(ChatSession{Promoter: c.Promoter, Type: ChatGroup}).
		Count(&count).Error
	if c.Err != nil {
		return c
	}

	if count == 1 {
		c.Err = common.Db.Model(c).
			Where(ChatSession{Promoter: c.Promoter, Receiver: receiver, Type: ChatGroup}).
			First(c).Error
		if c.Err != nil {
			return c
		}
	}

	c.Err = WithBegin(func(db *gorm.DB) error {
		tmp := &ChatSession{}
		if err := db.Model(tmp).
			Where(ChatSession{Promoter: c.Promoter, Receiver: receiver, Type: ChatGroup}).
			Delete(tmp).Error; err != nil {
			return err
		}

		// 群聊状态删除
		ext := &CardExtend{}
		if err := db.Model(ext).
			Where(CardExtend{Left: c.Promoter, Right: receiver, Type: CardGroup}).
			Delete(ext).Error; err != nil {
			return err
		}

		if count != 1 {
			return nil
		}

		// 清空所有聊天记录
		msg := &ChatMsg{}
		if err := db.Model(msg).
			Where(map[string]string{"sid": c.Sid}).
			Delete(msg).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}

// GroupCount 群聊人数统计
func (c *ChatSession) GroupCount(sid string) (count int64) {
	if c.Err != nil {
		return 0
	}
	c.Err = common.Db.Model(ChatSession{}).
		Where(ChatSession{Sid: sid}).
		Count(&count).Error
	return
}

// FindPrivate 搜索私聊会话
func (c *ChatSession) FindPrivate(receiver string) *ChatSession {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Where(ChatSession{Promoter: c.Promoter, Receiver: receiver, Type: ChatPrivate}).First(c).Error
	if c.Err == nil {
		return c
	}
	c.Err = common.Db.Where(ChatSession{Promoter: receiver, Receiver: c.Promoter, Type: ChatPrivate}).First(c).Error
	if c.Err == nil {
		return c
	}
	c.Err = fmt.Errorf("not found private")
	return c
}

// Private 私聊
func (c *ChatSession) Private(receiver string) *ChatSession {
	if c.Err != nil {
		return c
	}

	// 双方只要有一人存在私聊会话即可
	c.Err = common.Db.Where(ChatSession{Promoter: c.Promoter, Receiver: receiver, Type: ChatPrivate}).First(c).Error
	if c.Err == nil {
		c.Err = fmt.Errorf("私聊已存在")
		return c
	}
	c.Err = common.Db.Where(ChatSession{Promoter: receiver, Receiver: c.Promoter, Type: ChatPrivate}).First(c).Error
	if c.Err == nil {
		c.Err = fmt.Errorf("私聊已存在")
		return c
	}

	if c.IsMysqlNil() {
		c.Err = common.Db.Create(&ChatSession{
			Promoter: c.Promoter,
			Receiver: receiver,
			Type:     ChatPrivate,
			Sid:      common.SnowStringID(),
			Created:  common.TimestampSec(),
		}).Error
	}
	return c
}

// CancelPrivate 取消私聊
func (c *ChatSession) CancelPrivate(receiver string) *ChatSession {
	if c.Err != nil {
		return c
	}

	promoter := c.Promoter
	c.Err = common.Db.Model(c).
		Where(ChatSession{Promoter: promoter, Receiver: receiver, Type: ChatPrivate}).
		First(c).Error

	if c.IsMysqlNil() {
		c.Err = nil
		c.Err = common.Db.Model(c).
			Where(ChatSession{Promoter: receiver, Receiver: promoter, Type: ChatPrivate}).
			First(c).Error
	}

	if c.Err != nil {
		return c
	}

	c.Err = WithBegin(func(db *gorm.DB) error {
		tmp := &ChatSession{}
		if err := db.Delete(tmp, c.ID).Error; err != nil {
			return err
		}

		// 删除私聊状态
		ext := &CardExtend{}
		if err := db.Model(ext).
			Where(CardExtend{Left: promoter, Right: receiver, Type: CardPrivate}).
			Delete(ext).Error; err != nil {
			return err
		}
		if err := db.Model(ext).
			Where(CardExtend{Left: receiver, Right: promoter, Type: CardPrivate}).
			Delete(ext).Error; err != nil {
			return err
		}

		// 删除聊天记录
		msg := &ChatMsg{}
		if err := db.Model(msg).
			Where(map[string]string{"sid": c.Sid}).
			Delete(msg).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}

// ChatList 获取该用户所有相关会话
func (c *ChatSession) ChatList() (items []ChatSession) {
	if c.Err != nil {
		return []ChatSession{}
	}
	c.Err = common.Db.Model(c).Where("promoter = ?", c.Promoter).Or("receiver = ?", c.Promoter).Find(&items).Error
	return
}

// ExistsGroup 检查是否在{uid}的群里
func (c *ChatSession) ExistsGroup(uid string) *ChatSession {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(c).
		Where(ChatSession{Promoter: uid, Receiver: c.Promoter, Type: ChatGroup}).
		First(c).Error
	return c
}

func (c *ChatSession) GetSessionBySid(sid string) *ChatSession {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(c).Where("sid = ?", sid).First(c).Error
	return c
}

func (c *ChatSession) FindBySid() (items []ChatSession) {
	c.Err = common.Db.Model(c).Where("sid = ?", c.Sid).Find(&items).Error
	return
}
