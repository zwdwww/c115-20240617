package model

import (
	"cChain/common"
	"gorm.io/gorm"
)

type Favorites struct {
	ID      int
	Uid     string
	Key     string
	Value   string
	Created int64
	Base
}

func (f *Favorites) Clear(uid string, db *gorm.DB) error {
	return db.Model(f).Where(Favorites{Uid: uid}).Delete(f).Error
}

func (f *Favorites) Create() *Favorites {
	if f.Err != nil {
		return f
	}
	f.Created = common.TimestampSec()
	f.Err = common.Db.Create(f).Error
	return f
}

func (f *Favorites) Delete() *Favorites {
	if f.Err != nil {
		return f
	}
	f.Err = common.Db.Delete(&Favorites{}, f.ID).Error
	return f
}

// Get 获取该用户的收藏夹
func (f *Favorites) Get(id int) *Favorites {
	if f.Err != nil {
		return f
	}
	f.Err = common.Db.
		Model(Favorites{}).
		Where("`id`=? && `uid`=?", id, f.Uid).
		First(f).Error
	return f
}

// UpdateContent 更新收藏夹内容
func (f *Favorites) UpdateContent(name, link string) *Favorites {
	if f.Err != nil {
		return f
	}
	f.Err = common.Db.Model(f).Updates(map[string]interface{}{"key": name, "value": link}).Error
	return f
}

// ListByUid 获取用户的收藏夹
func (f *Favorites) ListByUid() (items []Favorites) {
	if f.Err != nil {
		return []Favorites{}
	}
	f.Err = common.Db.Model(Favorites{}).
		Where(Favorites{Uid: f.Uid}).
		Find(&items).Error
	return
}

// CountByUid 获取用户有多少个收藏
func (f *Favorites) CountByUid() (count int64) {
	if f.Err != nil {
		return 0
	}
	f.Err = common.Db.
		Model(Favorites{}).
		Where(Favorites{Uid: f.Uid}).
		Count(&count).Error
	return
}

// DeleteByValue 根据Value删除收藏内容
func (f *Favorites) DeleteByValue(value string) *Favorites {
	if f.Err != nil {
		return f
	}
	f.Err = common.Db.Model(f).Where(Favorites{Uid: f.Uid, Value: value}).Delete(f).Error
	return f
}
