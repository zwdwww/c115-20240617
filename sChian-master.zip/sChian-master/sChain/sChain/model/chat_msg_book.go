package model

// ChatMsgBook 还未使用到
type ChatMsgBook struct {
	ID      int
	Uid     string
	Sid     string // 会话ID
	MsgTime int64  // 该会话的查看时间
	Base
}
