package model

import (
	"cChain/common"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type User struct {
	ID            int
	Username      string
	Password      string
	Phone         string
	Ip            string
	Province      string // 省份
	Question      string // 密码修改问题
	AllowLeaveMsg int16  // 0:允许留言,1:不允许留言
	Created       int64
	Updated       int64
	Base
}

// Card 名片
func (u *User) Card() *Card {
	return &Card{Uid: u.Username}
}

// CardExtend 名片数据扩展
func (u *User) CardExtend(right string) *CardExtend {
	if right == "" {
		return &CardExtend{Left: u.Username, Right: right, Base: Base{Err: fmt.Errorf("ID异常")}}
	}
	return &CardExtend{Left: u.Username, Right: right}
}

// CardEssay 短文
func (u *User) CardEssay() *CardEssay {
	return &CardEssay{Uid: u.Username}
}

// Favorites 收藏夹
func (u *User) Favorites() *Favorites {
	return &Favorites{Uid: u.Username}
}

// FavoritesOrder 收藏夹排序
func (u *User) FavoritesOrder() *FavoritesOrder {
	return &FavoritesOrder{Uid: u.Username}
}

// LeaveMessage 留言
func (u *User) LeaveMessage() *LeaveMessage {
	return &LeaveMessage{Right: u.Username}
}

// ChatSession 聊天会话关系记录
func (u *User) ChatSession() *ChatSession {
	return &ChatSession{Promoter: u.Username}
}

// ChatMsg 聊天信息
func (u *User) ChatMsg() *ChatMsg {
	return &ChatMsg{Uid: u.Username}
}

// DiskSize 链盘空间
func (u *User) DiskSize() *DiskSize {
	disk := &DiskSize{Uid: u.Username}
	disk.Err = common.Db.Model(disk).Where(disk).First(disk).Error
	if disk.IsMysqlNil() {
		disk.Err = nil
		sysConfig := &SysConfig{}
		disk.DiskSize = 1024 * 1024 * common.DefaultInt64(sysConfig.Get().DefaultDiskSize, 40) // 40MB
		disk.Updated = common.TimestampSec()
		disk.Err = common.Db.Create(disk).Error
	}
	return disk
}

// DiskFile 链盘文件信息
func (u *User) DiskFile() *DiskFile {
	return &DiskFile{}
}

// DiskRel 链盘文件逻辑路径
func (u *User) DiskRel() *DiskRel {
	return &DiskRel{Uid: u.Username}
}

// DiskOrder 链盘目录排序
func (u *User) DiskOrder() *DiskOrder {
	return &DiskOrder{Uid: u.Username}
}

// RecordAddress 地址点击记录
func (u *User) RecordAddress() *RecordAddress {
	record := &RecordAddress{Uid: u.Username}
	if record.Get().IsMysqlNil() {
		record.Err = nil
		record.Address = []byte{}
		record.Err = common.Db.Create(record).Error
	}
	return record
}

// SearchKey 搜词
func (u *User) SearchKey() *SearchKey {
	return &SearchKey{}
}

// SysConfig 系统配置
func (u *User) SysConfig() *SysConfig {
	return &SysConfig{}
}

// CardNotes 名片备注
func (u *User) CardNotes(right string) *CardNotes {
	notes := &CardNotes{Left: u.Username, Right: right}
	common.Db.FirstOrCreate(notes, notes)
	return notes
}

func (u *User) Create() *User {
	if u.Err != nil {
		return u
	}
	u.Created = common.TimestampSec()
	u.Updated = u.Created
	u.Err = common.Db.Create(u).Error
	return u
}

func (u *User) Get() *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Where("username=?", u.Username).First(u).Error
	return u
}

func (u *User) Clear(uid string, db *gorm.DB) error {
	return db.Model(u).Where(User{Username: uid}).Delete(u).Error
}

// Verify 密码验证
func (u *User) Verify(password string) *User {
	if u.Err != nil {
		return u
	}
	u.Err = bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))
	return u
}

// SetPassword 设置密码
func (u *User) SetPassword(password string) *User {
	if u.Err != nil {
		return u
	}
	value, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	u.Err = err
	u.Password = string(value)
	return u
}

// UpdatePassword 更新密码
func (u *User) UpdatePassword(newPassword string) *User {
	if u.Err != nil {
		return u
	}

	u.SetPassword(newPassword)
	if u.Err != nil {
		return u
	}

	u.Err = common.Db.Model(User{}).
		Where(User{Username: u.Username}).
		Update("password", u.Password).Error
	return u
}

// UpdateIp 更新IP
func (u *User) UpdateIp(ip string) *User {
	if u.Err != nil {
		return u
	}
	u.Ip = ip
	u.Province = common.GetProvince(ip)
	u.Updated = common.TimestampSec()
	u.Err = common.Db.Model(User{}).
		Where(User{Username: u.Username}).
		Updates(User{Province: u.Province, Ip: ip, Updated: u.Updated}).Error
	return u
}

// UpdatePhone 更新手机号
func (u *User) UpdatePhone(phone string) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(u).Where(User{Username: u.Username}).Update("phone", phone).Error
	return u
}

// UpdateQuestion 更新密保问题
func (u *User) UpdateQuestion(question string) *User {
	if u.Err != nil || question == "" {
		return u
	}
	encrypt := common.AesEncryptECBBase64(question, "SChainUserQuestion")
	u.Err = common.Db.Model(u).Where(User{Username: u.Username}).Update("question", encrypt).Error
	return u
}

// GetQuestion 获取解密的密保
func (u *User) GetQuestion() string {
	if u.Err != nil || u.Question == "" {
		return ""
	}
	bytes := common.AesDecryptECBBase64(u.Question, "SChainUserQuestion")
	return string(bytes)
}

// UpdateAllowLeaveMsg 修改留言权限
func (u *User) UpdateAllowLeaveMsg(state int16) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(u).
		Where("username = ?", u.Username).
		Update("allow_leave_msg", state).Error
	return u
}

// LogOff 注销全部数据
func (u *User) LogOff() *User {
	if u.Err != nil {
		return u
	}

	off := []LogOff{
		&Card{},
		&CardEssay{},
		&CardExtend{},
		&CardKey{},
		&ChatSession{},
		&DiskOrder{},
		&DiskRel{},
		&DiskSize{},
		&Favorites{},
		&FavoritesOrder{},
		&LeaveMessage{},
		&RecordAddress{},
		&User{},
	}
	u.Err = WithBegin(func(db *gorm.DB) error {
		for _, logOff := range off {
			if err := logOff.Clear(u.Username, db); err != nil {
				return err
			}
		}
		return nil
	})
	return u
}
