package model

import "gorm.io/gorm"

// DiskSize 用户的链盘空间
type DiskSize struct {
	ID       int
	Uid      string
	DiskSize int64 // 链盘总空间
	UsedSize int64 // 已使用空间
	Updated  int64
	Base
}

func (d *DiskSize) Clear(uid string, db *gorm.DB) error {
	return db.Model(d).Where(DiskSize{Uid: uid}).Delete(d).Error
}

// SurplusSize 剩余空间
func (d *DiskSize) SurplusSize() int64 {
	return d.DiskSize - d.UsedSize
}
