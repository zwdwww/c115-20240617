package model

import (
	"cChain/common"
	"fmt"
	"gorm.io/gorm"
	"strings"
)

// Card 完整的名片数据(需要保持数据的同步)
type Card struct {
	ID       int
	Uid      string
	Title    string // 标题
	Contact  string // 联系方式
	Address  string // 地址
	Weight   int    // 推荐权重 default=0
	Keywords string // 搜词(需要与CardKey同步更新)
	Essay    string // 短文(需要与CardEssay同步更新)
	Star     int    // 被关注的次数(需要与CardStar的数据同步)
	Created  int64
	Updated  int64

	IsStar      bool   `gorm:"-"` // 已关注
	IsGroup     bool   `gorm:"-"` // 已加入群聊
	IsPrivate   bool   `gorm:"-"` // 已加入私聊
	IsFavorites bool   `gorm:"-"` // 已收藏
	Notes       string `gorm:"-"` // 备注
	Base
}

func (c *Card) Create() *Card {
	if c.Err != nil {
		return c
	}
	c.Updated = common.TimestampSec()
	c.Err = common.Db.Create(c).Error
	return c
}

func (c *Card) Get() *Card {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Where(Card{Uid: c.Uid}).First(c).Error
	return c
}

func (c *Card) In(uidArr []string) (items []Card) {
	if c.Err != nil || len(uidArr) == 0 {
		return []Card{}
	}
	c.Err = common.Db.Model(Card{}).
		Where("`uid` in ?", uidArr).
		Find(&items).Error
	return
}

func (c *Card) Clear(uid string, db *gorm.DB) error {
	return db.Model(c).Where(Card{Uid: uid}).Delete(c).Error
}

func (c *Card) Refresh(page, limit int) (items []Card, count int64) {
	if c.Err != nil {
		return
	}

	c.Err = common.Db.Model(c).Count(&count).Error
	if c.Err != nil {
		return
	}

	c.Err = common.Db.Model(c).
		Order("created desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

// Suggest 获取推荐列表
func (c *Card) Suggest(page, limit int) (items []Card, count int64) {
	if c.Err != nil {
		return
	}

	c.Err = common.Db.Model(c).Count(&count).Error
	if c.Err != nil {
		return
	}

	c.Err = common.Db.Model(c).
		Order("weight desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

type CardSearchArgs struct {
	Mul     string   `json:"mul"`   // 综合
	Id      string   `json:"id"`    // ID号
	Title   string   `json:"title"` // 名称
	Essay   string   `json:"essay"` // 短文
	Disk    string   `json:"disk"`  // 公盘
	Key     string   `json:"key"`   // 关键词
	Address []string `json:"addr"`  // 地址
}

// 补齐结果
func (c *Card) joinSearchResult(page, limit int, result []int) (items []Card) {
	if c.Err != nil {
		return []Card{}
	}

	offset := (page - 1) * limit
	if (offset + limit) <= len(result) {
		c.Err = common.Db.Model(c).
			Where("id in ?", result[offset:limit+offset]).
			Order("weight desc").
			Find(&items).Error
	} else if offset < len(result) {
		c.Err = common.Db.Model(c).
			Where("id in ?", result[offset:]).
			Order("weight desc").
			Find(&items).Error
		var nextPart []Card
		c.Err = common.Db.Model(c).
			Where("id not in ?", result).
			Order("weight desc").
			Offset(0).
			Limit(limit - len(result[offset:])).
			Find(&nextPart).Error
		items = append(items, nextPart...)
	} else {
		query := common.Db.Model(c)
		if len(result) > 0 {
			query = query.Where("id not in ?", result)
		}
		c.Err = query.Order("weight desc").
			Offset(offset - len(result)).
			Limit(limit).
			Find(&items).Error
	}
	return
}

// Search 名片搜索
func (c *Card) Search(page, limit int, args *CardSearchArgs) (items []Card, count int64) {
	if c.Err != nil {
		return
	}
	if c.Err = common.Db.Model(c).Count(&count).Error; c.Err != nil {
		return nil, 0
	}

	query := common.Db.Model(c)
	if args.Mul != "" {
		subQuery := common.Db.Table("disk_rel").Select("uid").Where("`file_name` like ?", "%"+args.Mul+"%")
		query = query.Where("`uid` = ?", args.Mul).
			Or("`title` = ?", args.Mul).
			Or("`essay` like ?", "%"+args.Mul+"%").
			Or("`uid` in (?)", subQuery)
	} else if args.Id != "" {
		query = query.Where("`uid` = ?", args.Id)
	} else if args.Title != "" {
		query = query.Where("`title` = ?", args.Title)
	} else if args.Essay != "" {
		query = query.Where("`essay` like ?", "%"+args.Essay+"%")
	} else if args.Disk != "" {
		subQuery := common.Db.Table("disk_rel").Select("uid").Where("`file_name` like ?", "%"+args.Disk+"%")
		query = query.Where("`uid` in (?)", subQuery)
	} else if args.Key != "" {
		subQuery := common.Db.Table("card_key").Select("uid").Where("`key` = ?", args.Key)
		query = query.Where("`uid` in (?)", subQuery)
	} else if len(args.Address) != 0 {
		query = query.Where("`address` like ?", "%"+strings.Join(args.Address, ">")+"%")
	} else {
		c.Err = fmt.Errorf("search args error")
		return nil, 0
	}

	var idItems []int
	if c.Err = query.Select("id").Find(&idItems).Error; c.Err != nil {
		return nil, 0
	}

	items = c.joinSearchResult(page, limit, idItems)
	return
}

// StarsDesc 关注度降序获取
func (c *Card) StarsDesc(page, limit int) (items []Card, count int64) {
	if c.Err != nil {
		return []Card{}, 0
	}

	c.Err = common.Db.Model(Card{}).Count(&count).Error
	if c.Err != nil && count == 0 {
		return []Card{}, 0
	}

	c.Err = common.Db.Model(Card{}).
		Order("star DESC").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

// AddStar 关注度加
func (c *Card) AddStar(num int) *Card {
	if c.Err != nil {
		return c
	}
	c.Star += num
	if c.Star < 0 {
		c.Star = 0
	}
	c.Err = common.Db.
		Model(Card{}).
		Where(Card{Uid: c.Uid}).
		Update("star", c.Star).Error
	return c
}

// UpdateCard 更新名片
func (c *Card) UpdateCard(title string, contact, address, keywords []string) *Card {
	if c.Err != nil {
		return c
	}

	keywordArr := make([]CardKey, 0, 3)
	for _, v := range keywords {
		if v == "" {
			continue
		}
		keywordArr = append(keywordArr, CardKey{
			Uid: c.Uid,
			Key: v,
		})
	}

	update := Card{
		Title:    title,
		Contact:  strings.Join(contact, "$"),
		Address:  strings.Join(address, ">"),
		Keywords: strings.Join(keywords, "$$"),
		Updated:  common.TimestampSec(),
	}

	c.Err = WithBegin(func(db *gorm.DB) error {
		if err := db.Where(CardKey{Uid: c.Uid}).Delete(&CardKey{}).Error; err != nil {
			return err
		}
		if len(keywordArr) != 0 {
			if err := db.Create(&keywordArr).Error; err != nil {
				return err
			}
		}

		if err := db.Model(Card{}).
			Where(Card{Uid: c.Uid}).
			Updates(update).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}
