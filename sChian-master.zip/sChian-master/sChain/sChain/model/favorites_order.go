package model

import (
	"cChain/common"
	"encoding/json"
	"fmt"
	"gorm.io/gorm"
)

// FavoritesOrder 收藏夹排序记录
type FavoritesOrder struct {
	ID    int
	Uid   string
	Order []byte // 收藏夹ID排序记录
	Base
}

func (f *FavoritesOrder) Clear(uid string, db *gorm.DB) error {
	return db.Model(f).Where(FavoritesOrder{Uid: uid}).Delete(f).Error
}

func (f *FavoritesOrder) OrderArray() (items []int) {
	if f.Err != nil {
		return []int{}
	}
	_ = json.Unmarshal(f.Order, &items)
	return
}

func (f *FavoritesOrder) Get() *FavoritesOrder {
	if f.Err != nil {
		return f
	}
	f.Err = common.Db.
		Where(FavoritesOrder{Uid: f.Uid}).
		First(f).Error
	return f
}

// Upsert 更新或插入
func (f *FavoritesOrder) Upsert(order []int) *FavoritesOrder {
	if f.Err != nil {
		return f
	}
	if len(order) > common.Config.FavMax {
		f.Err = fmt.Errorf("收藏夹已达上限")
		return f
	}
	orderBytes, _ := json.Marshal(order)
	f.Err = common.Db.Where(FavoritesOrder{Uid: f.Uid}).First(f).Error
	if f.IsMysqlNil() {
		f.Err = nil
		f.Order = orderBytes
		f.Err = common.Db.Create(f).Error
		return f
	} else if f.Err == nil {
		f.Order = orderBytes
		f.Err = common.Db.Model(f).Update("order", f.Order).Error
	}
	return f
}
