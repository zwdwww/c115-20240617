package model

import (
	"cChain/common"
	"gorm.io/gorm"
)

const (
	CardStar      = 1 // 已关注
	CardGroup     = 2 // 已群聊
	CardPrivate   = 3 // 已私聊
	CardFavorites = 4 // 已收藏
)

// CardExtend 名片数据扩展
type CardExtend struct {
	ID      int
	Left    string // 关注者
	Right   string // 被关注
	Type    int    // 类型
	Created int64
	Base
}

func (c *CardExtend) Get(typ int) *CardExtend {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.
		Where(CardExtend{Left: c.Left, Right: c.Right, Type: typ}).
		First(c).Error
	return c
}

func (c *CardExtend) Create(typ int) *CardExtend {
	if c.Err != nil {
		return c
	}
	c.Type = typ
	c.Created = common.TimestampSec()
	c.Err = common.Db.Create(c).Error
	return c
}

func (c *CardExtend) CreateSwap(typ int) *CardExtend {
	c.Err = WithBegin(func(db *gorm.DB) error {
		tmp := &CardExtend{Left: c.Left, Right: c.Right, Type: typ, Created: common.TimestampSec()}
		tmp2 := &CardExtend{Left: c.Right, Right: c.Left, Type: typ, Created: common.TimestampSec()}
		if err := db.Create(tmp).Error; err != nil {
			return err
		}
		if err := db.Create(tmp2).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}

func (c *CardExtend) Delete(typ int) *CardExtend {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.
		Where(CardExtend{Left: c.Left, Right: c.Right, Type: typ}).
		Delete(&CardExtend{}).Error
	return c
}

func (c *CardExtend) Clear(uid string, db *gorm.DB) error {
	return db.Model(c).Where("`left` = ? or `right` = ?", uid, uid).Delete(c).Error
}

// AddCardStar 添加名片的关注数
func (c *CardExtend) AddCardStar(num int) *CardExtend {
	if c.Err != nil {
		return c
	}
	card := &Card{Uid: c.Right}
	c.Err = card.Get().AddStar(num).Err
	return c
}

// Stars 获取自己关注的名片列表
func (c *CardExtend) Stars() (items []string) {
	if c.Err != nil {
		return []string{}
	}
	c.Err = common.Db.Model(CardExtend{}).
		Where(CardExtend{Left: c.Left, Type: CardStar}).
		Select("right").
		Find(&items).Error
	return
}

// SetCardExtend 设置名片的扩展数据
func (c *CardExtend) SetCardExtend(uid string, cards []Card) error {
	if c.Err != nil {
		return c.Err
	}

	if len(cards) == 0 {
		return nil
	}

	// 取出名片的uid列表
	uidArr := make([]string, 0, len(cards))
	for _, card := range cards {
		uidArr = append(uidArr, card.Uid)
	}

	// 读取数据库数据
	var items []CardExtend
	c.Err = common.Db.Model(CardExtend{}).Where("`left` = ? && `right` in ?", uid, uidArr).Find(&items).Error
	if c.FilterMysqlNilErr() {
		return c.Err
	}

	if len(items) == 0 {
		return nil
	}

	// 构建映射
	itemMap := make(map[string]map[int]struct{}, len(items))
	for _, item := range items {
		if _, ok := itemMap[item.Right]; !ok {
			itemMap[item.Right] = make(map[int]struct{})
		}
		itemMap[item.Right][item.Type] = struct{}{}
	}

	// 获取备注
	var notesItems []CardNotes
	_ = common.Db.Model(CardNotes{}).Where("`left` = ? && `right` in ?", uid, uidArr).Find(&notesItems).Error

	notesMap := make(map[string]string, len(notesItems))
	for _, v := range notesItems {
		notesMap[v.Right] = v.Cnt
	}

	// 赋值结果
	for i := range cards {
		uid = cards[i].Uid

		if notes, ok := notesMap[uid]; ok {
			cards[i].Notes = notes
		}

		item, ok := itemMap[uid]
		if !ok {
			continue
		}

		if _, ok = item[CardStar]; ok {
			cards[i].IsStar = true
		}

		if _, ok = item[CardGroup]; ok {
			cards[i].IsGroup = true
		}

		if _, ok = item[CardPrivate]; ok {
			cards[i].IsPrivate = true
		}

		if _, ok = item[CardFavorites]; ok {
			cards[i].IsFavorites = true
		}
	}
	return nil
}
