package model

import (
	"cChain/common"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type LeaveMessage struct {
	ID        int
	Left      string // 留言人
	Right     string // 留言对象
	Content   string // 留言内容
	LikeCount int    // 点赞
	Updated   int64  // 更新时间

	Ip     string `gorm:"-"` // 留言对象的IP
	IsLike bool   `gorm:"-"` // 是否已点赞
	Base
}

func (l *LeaveMessage) LoadById() *LeaveMessage {
	l.Err = common.Db.Model(l).Where("id = ?", l.ID).First(l).Error
	return l
}

func (l *LeaveMessage) Clear(uid string, db *gorm.DB) error {
	return db.Model(l).Where("`left` = ? or `right` = ?", uid, uid).Delete(l).Error
}

func (l *LeaveMessage) Upsert() *LeaveMessage {
	if l.Err != nil {
		return l
	}
	l.Err = common.Db.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "left"}, {Name: "right"}},
		UpdateAll: true,
	}).Create(l).Error
	return l
}

func (l *LeaveMessage) AddLikeCount(add int) *LeaveMessage {
	if l.Err != nil {
		return l
	}
	l.LikeCount += add
	l.Err = common.Db.Model(l).Where("id = ?", l.ID).Update("like_count", l.LikeCount).Error
	return l
}

// DeleteRight 删除给我的留言
func (l *LeaveMessage) DeleteRight(id int) *LeaveMessage {
	if l.Err != nil {
		return l
	}
	l.Err = common.Db.Model(LeaveMessage{}).Where(LeaveMessage{ID: id, Right: l.Right}).Delete(l).Error
	return l
}

// DeleteLeft 删除给别人的留言
func (l *LeaveMessage) DeleteLeft(id int) *LeaveMessage {
	if l.Err != nil {
		return l
	}
	l.Err = common.Db.Model(LeaveMessage{}).Where(LeaveMessage{ID: id, Left: l.Right}).Delete(l).Error
	return l
}

// GetMessage 获取当前用户的留言
func (l *LeaveMessage) GetMessage(right string) *LeaveMessage {
	if l.Err != nil {
		return l
	}
	l.Err = common.Db.Where(LeaveMessage{Left: l.Right, Right: right}).First(l).Error
	return l
}

// ListByRight 获取某个留言对象的留言内容
func (l *LeaveMessage) ListByRight(right string, page, limit int) (items []LeaveMessage, count int64) {
	if l.Err != nil {
		return
	}
	l.Err = common.Db.
		Model(LeaveMessage{}).
		Where(LeaveMessage{Right: right}).
		Count(&count).Error
	if l.Err != nil {
		return
	}
	l.Err = common.Db.Model(LeaveMessage{}).
		Where(LeaveMessage{Right: right}).
		Order("like_count desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

// ListByLeft 获取我的所有留言
func (l *LeaveMessage) ListByLeft(left string, page, limit int) (items []LeaveMessage, count int64) {
	if l.Err != nil {
		return
	}
	l.Err = common.Db.
		Model(LeaveMessage{}).
		Where(LeaveMessage{Left: left}).
		Count(&count).Error
	if l.Err != nil {
		return
	}
	l.Err = common.Db.Model(LeaveMessage{}).
		Where(LeaveMessage{Left: left}).
		Order("like_count desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}
