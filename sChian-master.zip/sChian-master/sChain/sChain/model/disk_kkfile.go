package model

import (
	"cChain/common"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/url"
)

var KKFileViewApi KKFileView

type KKFileView struct{}

func (k *KKFileView) Upload(filename string, fileContent []byte) error {
	uri := fmt.Sprintf("%v/fileUpload", common.Config.KKFileURI)
	respData, err := common.UploadFile(uri, "file", filename, fileContent)
	common.Loggers.Infof("kkfile upload: filename=%v, %s", filename, respData)

	if err != nil {
		return err
	}

	var resp struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
	}
	if err = json.Unmarshal(respData, &resp); err != nil {
		return err
	}
	if resp.Code != 0 {
		return fmt.Errorf("%v:%v", resp.Code, resp.Msg)
	}
	return nil
}

func (k *KKFileView) Remove(filename string) error {
	queryName := url.QueryEscape(fmt.Sprintf("demo/%v", filename))
	uri := fmt.Sprintf("%v/deleteFile?fileName=%v", common.Config.KKFileURI, queryName)

	respData, err := common.GetURL(uri)
	if err != nil {
		return err
	}

	var resp struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
	}
	if err = json.Unmarshal(respData, &resp); err != nil {
		return err
	}
	if resp.Code != 0 {
		return fmt.Errorf("%v:%v", resp.Code, resp.Msg)
	}
	return nil
}

func (k *KKFileView) GetShowURL(filename string) string {
	baseStr := base64.StdEncoding.EncodeToString([]byte(
		fmt.Sprintf("%v/demo/%v", common.Config.KKFileURI, filename)))
	name := url.QueryEscape(baseStr)
	return fmt.Sprintf("%v/onlinePreview?url=%v", common.Config.KKFileURI, name)
}

type KKFileItem struct {
	FileName string `json:"fileName"`
}

func (k *KKFileView) DirList() (items []KKFileItem) {
	uri := fmt.Sprintf("%v/listFiles?order=asc", common.Config.KKFileURI)
	respData, _ := common.GetURL(uri)
	_ = json.Unmarshal(respData, &items)
	return
}
