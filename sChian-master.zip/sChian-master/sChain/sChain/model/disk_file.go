package model

import (
	"cChain/common"
	"fmt"
)

// DiskFile 链盘文件信息(物理地址存储)
type DiskFile struct {
	ID           int
	FileMd5      string
	FileByteSize int64
	FileContent  []byte `json:"-"`
	FileType     string // 文件类型
	Count        int    // 引用数量
	IsPreview    int    // 是否可以预览
	Created      int64
	Base
}

func (d *DiskFile) LoadByID() *DiskFile {
	d.Err = common.Db.Model(d).Where("id = ?", d.ID).First(d).Error
	return d
}

func (d *DiskFile) Get(md5 string) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Err = common.Db.Where(DiskFile{FileMd5: md5}).First(d).Error
	return d
}

func (d *DiskFile) Delete() *DiskFile {
	if d.Err != nil {
		return d
	}
	del := &DiskFile{}
	d.Err = common.Db.Where(DiskFile{FileMd5: d.FileMd5}).Delete(del).Error
	return d
}

// AddCount 添加引用数量
func (d *DiskFile) AddCount(add int) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Count += add
	d.Err = common.Db.Model(DiskFile{}).Where(DiskFile{FileMd5: d.FileMd5}).Update("count", d.Count).Error
	return d
}

// RemoveMd5File 删除文件
func (d *DiskFile) RemoveMd5File() *DiskFile {
	if d.Err != nil {
		return d
	}
	_ = KKFileViewApi.Remove(fmt.Sprintf("%v.%v", d.FileMd5, d.FileType))
	return d
}

// AddFile 添加文件
func (d *DiskFile) AddFile(fileBytes []byte) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Created = common.TimestampSec()
	d.Count = 1
	d.FileContent = fileBytes
	d.Err = common.Db.Create(d).Error
	return d
}

// UpdatePreview 修改预览状态
func (d *DiskFile) UpdatePreview(state int) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Err = common.Db.Model(d).Where("id = ?", d.ID).Update("is_preview", state).Error
	return d
}

// UpdateContent 更新文件内容
func (d *DiskFile) UpdateContent(fileContent []byte) *DiskFile {
	d.Err = common.Db.Model(d).Where("id = ?", d.ID).Update("file_content", fileContent).Error
	return d
}

func (d *DiskFile) FindByIsPreview(state int) (items []DiskFile) {
	d.Err = common.Db.Model(d).Where("is_preview = ?", state).Find(&items).Error
	return
}
