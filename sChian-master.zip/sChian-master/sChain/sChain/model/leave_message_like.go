package model

import "cChain/common"

type LeaveMessageLike struct {
	ID      int
	Uid     string
	LeaveId int
	Base
}

func (l *LeaveMessageLike) LoadByInfo() *LeaveMessageLike {
	l.Err = common.Db.Model(l).Where("uid = ? && leave_id = ?", l.Uid, l.LeaveId).First(l).Error
	return l
}

func (l *LeaveMessageLike) Create() *LeaveMessageLike {
	l.Err = common.Db.Create(l).Error
	return l
}

func (l *LeaveMessageLike) Remove() *LeaveMessageLike {
	l.Err = common.Db.Model(l).Where("id = ?", l.ID).Delete(l).Error
	return l
}

func (l *LeaveMessageLike) RemoveByLeaveId() *LeaveMessageLike {
	l.Err = common.Db.Model(l).Where("leave_id = ?", l.LeaveId).Delete(l).Error
	return l
}
