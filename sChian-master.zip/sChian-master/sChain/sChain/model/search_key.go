package model

import (
	"cChain/common"
)

// SearchKey 搜词
type SearchKey struct {
	ID      int
	Word    string
	Group   string
	Created int64
	Base
}

func (s *SearchKey) Keys() map[string][]string {
	if s.Err != nil {
		return map[string][]string{}
	}

	var items []SearchKey
	s.Err = common.Db.Model(s).Find(&items).Error
	if s.Err != nil {
		return map[string][]string{}
	}

	m := map[string][]string{}
	for _, item := range items {
		_, ok := m[item.Group]
		if !ok {
			m[item.Group] = []string{}
		}
		m[item.Group] = append(m[item.Group], item.Word)
	}
	return m
}
