package model

import "cChain/common"

// UserAuthToken 用来持久化保存用户token, 用于服务重启后加载
// 使用redis后, 可以去掉该表
type UserAuthToken struct {
	ID      int
	Uid     string
	Token   string
	Seconds int64
	Created int64
	Base
}

func SetAuthToken(uid string, seconds int64, token string) error {
	auth := &UserAuthToken{Uid: uid}
	if auth.Upsert(token, seconds).Err != nil {
		return auth.Err
	}

	common.SetAuthTokenByNode(uid, &common.CacheNode{
		Value:   token,
		Expired: seconds,
		Created: auth.Created,
	})
	return nil
}

func GetAuthToken(uid string) string {
	resp, isExpired := common.GetAuthToken(uid)
	if isExpired {
		auth := &UserAuthToken{Uid: uid}
		if auth.Delete().Err != nil {
			common.Loggers.Errorf("GetAuthToken delete uid=%v,err=%v", uid, auth.Token)
			return ""
		}
	}
	if resp == nil {
		return ""
	}
	return resp.(string)
}

func RemoveAuthToken(uid string) error {
	common.RemoveAuthToken(uid)
	auth := &UserAuthToken{Uid: uid}
	return auth.Delete().Err
}

func LoadAuthToken() error {
	auth := &UserAuthToken{}
	return auth.LoadAuthCache().Err
}

func (u *UserAuthToken) Upsert(token string, seconds int64) *UserAuthToken {
	if u.Err != nil {
		return u
	}

	u.Err = common.Db.Model(u).Where("`uid` = ?", u.Uid).First(u).Error
	u.Seconds = seconds
	u.Token = token
	u.Created = common.TimestampSec()

	if u.IsMysqlNil() {
		u.Err = nil
		u.Err = common.Db.Create(u).Error
	} else {
		u.Err = common.Db.Model(u).Where("`uid` = ?", u.Uid).Updates(map[string]interface{}{
			"token":   u.Token,
			"seconds": u.Seconds,
			"created": u.Created,
		}).Error
	}
	return u
}

func (u *UserAuthToken) Delete() *UserAuthToken {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(u).Where(UserAuthToken{Uid: u.Uid}).Delete(u).Error
	return u
}

// LoadAuthCache 加载缓存
func (u *UserAuthToken) LoadAuthCache() *UserAuthToken {
	if u.Err != nil {
		return u
	}

	var items []UserAuthToken
	u.Err = common.Db.Model(u).Find(&items).Error
	if u.Err != nil {
		return u
	}

	var expiredArr []int
	now := common.TimestampSec()

	for _, item := range items {
		if now-item.Created >= item.Seconds {
			expiredArr = append(expiredArr, item.ID)
			continue
		}
		common.SetAuthTokenByNode(item.Uid, &common.CacheNode{
			Value:   item.Token,
			Expired: item.Seconds,
			Created: item.Created,
		})
	}

	// 清理已经过期的token
	if len(expiredArr) != 0 {
		tmp := &UserAuthToken{}
		u.Err = common.Db.Model(tmp).Where("id in ?", expiredArr).Delete(tmp).Error
	}

	common.Loggers.Debugf("AutoToken加载完成: %v", len(items))
	return u
}
