package model

import (
	"cChain/common"
	"gorm.io/gorm"
)

// CardEssay 名片短文
type CardEssay struct {
	ID      int
	Uid     string
	Essay   string
	Top     int //是否被置顶
	Updated int64
	Base
}

func (c *CardEssay) Get(id int) *CardEssay {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(CardEssay{}).
		Where(CardEssay{Uid: c.Uid, ID: id}).
		First(c).Error
	return c
}

func (c *CardEssay) Create() *CardEssay {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Create(c).Error
	return c
}

func (c *CardEssay) Delete(id int) *CardEssay {
	if c.Err != nil {
		return c
	}
	c.Err = common.Db.Model(CardEssay{}).
		Where(CardEssay{Uid: c.Uid, ID: id}).
		Delete(c).Error
	return c
}

func (c *CardEssay) Clear(uid string, db *gorm.DB) error {
	return db.Model(c).Where(CardEssay{Uid: uid}).Delete(c).Error
}

func (c *CardEssay) List() (items []CardEssay) {
	if c.Err != nil {
		return []CardEssay{}
	}
	c.Err = common.Db.Model(CardEssay{}).
		Where(CardEssay{Uid: c.Uid}).
		Order("updated desc").
		Find(&items).Error
	return
}

// UpdateEssay 修改短文内容
func (c *CardEssay) UpdateEssay(essay string) *CardEssay {
	if c.Err != nil {
		return c
	}

	if c.Top != 1 {
		c.Err = common.Db.Model(CardEssay{}).
			Where(CardEssay{Uid: c.Uid, ID: c.ID}).
			Update("essay", essay).Error
		return c
	}

	c.Err = WithBegin(func(db *gorm.DB) error {
		if err := db.Model(CardEssay{}).
			Where(CardEssay{Uid: c.Uid, ID: c.ID}).
			Update("essay", essay).Error; err != nil {
			return err
		}
		if err := db.Model(Card{}).
			Where(Card{Uid: c.Uid}).
			Update("essay", essay).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}

// Topping 置顶短文
func (c *CardEssay) Topping() *CardEssay {
	if c.Err != nil {
		return c
	}
	c.Err = WithBegin(func(db *gorm.DB) error {
		if err := db.Model(CardEssay{}).
			Where(CardEssay{Uid: c.Uid, Top: 1}).
			Update("top", 0).Error; err != nil {
			return err
		}

		if err := db.Model(CardEssay{}).
			Where(CardEssay{Uid: c.Uid, ID: c.ID}).
			Update("top", 1).Error; err != nil {
			return err
		}

		if err := db.Model(Card{}).
			Where(Card{Uid: c.Uid}).
			Update("essay", c.Essay).Error; err != nil {
			return err
		}
		return nil
	})
	return c
}
