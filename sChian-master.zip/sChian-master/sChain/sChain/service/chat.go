package service

import (
	"cChain/common"
	"cChain/model"
	"sync"
	"time"
)

// 180秒如果没有进行通信,则释放会话数据
const chatExpiredTime = 180

// 消息进程启动锁
var chatProcessLock sync.Mutex

// ItemCache 用户消息缓存
type ItemCache struct {
	Msg     []model.ChatMsg // 最新消息
	Expired int64           // 会话过期时间
}

// MsgCache 用户消息推送缓存结构
type MsgCache map[string]*ItemCache

// SidMsgCache 会话+用户消息推送缓存结构
type SidMsgCache map[string]MsgCache

// ChatManageService 聊天会话管理
var ChatManageService = &ChatManage{
	msgCache: SidMsgCache{},
	msgQueue: make(chan model.ChatMsg, 128),
}

type ChatManage struct {
	msgCache   SidMsgCache
	msgQueue   chan model.ChatMsg
	msgRun     bool
	expiredRun bool
}

func (c *ChatManage) _handleMsg() {
	for {
		msg := <-c.msgQueue
		if msg.Create().Err != nil {
			common.Loggers.Errorf("handleMsg err=%v", msg.Err)
			continue
		}
		common.Loggers.Debugf("send msg=%+v", msg)

		cache, ok := c.msgCache[msg.Sid]
		if !ok {
			continue
		}

		for uid, itemCache := range cache {
			if uid == msg.Uid {
				continue
			}
			itemCache.Msg = append(itemCache.Msg, msg)
		}
	}
}

// 检查并启动处理消息进程
func (c *ChatManage) runHandleMsg() {
	if c.msgRun {
		return
	}
	chatProcessLock.Lock()
	defer chatProcessLock.Unlock()
	if c.msgRun {
		return
	}
	c.msgRun = true
	go c._handleMsg()
}

type ExpiredItem struct {
	Uid string
	Sid string
}

// 过期会话实际处理函数
func (c *ChatManage) _expiredProcess() {
	common.Loggers.Debugf("run chat expired processs")
	now := common.TimestampSec()
	for {
		var sidKeys []string
		var uidKeys []ExpiredItem
		for sid, cache := range c.msgCache {
			if len(cache) == 0 {
				sidKeys = append(sidKeys, sid)
				continue
			}
			for uid, item := range cache {
				if now-item.Expired > chatExpiredTime {
					uidKeys = append(uidKeys, ExpiredItem{
						Uid: uid,
						Sid: sid,
					})
				}
			}
		}
		for _, item := range uidKeys {
			delete(c.msgCache[item.Sid], item.Uid)
		}
		for _, key := range sidKeys {
			delete(c.msgCache, key)
		}
		time.Sleep(time.Second * 60)
	}
}

// 检查并启动处理函数
func (c *ChatManage) runExpiredProcess() {
	if c.expiredRun {
		return
	}
	chatProcessLock.Lock()
	defer chatProcessLock.Unlock()
	if c.expiredRun {
		return
	}
	c.expiredRun = true
	go c._expiredProcess()
}

// Register 已打开某个窗口会话,开始聊天
func (c *ChatManage) Register(sid string, uid string) {
	if _, ok := c.msgCache[sid]; !ok {
		c.msgCache[sid] = MsgCache{}
	}
	if _, ok := c.msgCache[sid][uid]; !ok {
		c.msgCache[sid][uid] = &ItemCache{
			Msg: []model.ChatMsg{},
		}
	}
	c.msgCache[sid][uid].Expired = common.TimestampSec()
	c.runExpiredProcess()
}

// SendMsg 发送消息
func (c *ChatManage) SendMsg(msg model.ChatMsg) {
	c.runHandleMsg()
	c.msgQueue <- msg
}

// Accept 接收最新消息
// 会话里没有一个人,则10秒通信一次
// 会话里存在人, 但是没有新信息,则5秒通信一次
// 发信息时3秒通信一次
func (c *ChatManage) Accept(sid, uid string) ([]model.ChatMsg, int) {
	cache, ok := c.msgCache[sid]
	if !ok {
		return []model.ChatMsg{}, 10000
	}
	item, ok := cache[uid]
	if !ok {
		return []model.ChatMsg{}, 10000
	}
	tmp := item.Msg
	item.Msg = []model.ChatMsg{}
	// 更新一次在线信息
	item.Expired = common.TimestampSec()

	if len(cache) == 1 {
		return tmp, 10000
	} else if len(tmp) == 0 {
		return tmp, 5000
	} else {
		return tmp, 3000
	}
}
