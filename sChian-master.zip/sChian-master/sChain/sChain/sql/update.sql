-- 用于更新数据库字段, 直接使用init.sql初始化不需要调用这个sql

alter table `card` add `weight` int default 0 not null ;

alter table `disk_file` add `file_type` varchar(20) default '' not null ;
update `disk_file` set `file_type`='docx';

alter table `disk_rel` add `file_type` varchar(20) default '' not null ;
update `disk_rel` set `file_type`='docx';

alter table `user` add `allow_leave_msg` tinyint default 0 not null ;

-- 2024-05-26
alter table `leave_message` add `like_count` int default 0 not null;

-- 2024-06-02
alter table `disk_file` add  `file_content` MEDIUMBLOB null;