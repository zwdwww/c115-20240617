# 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` int NOT NULL AUTO_INCREMENT,
    `username` varchar(20) NOT NULL,
    `password` varchar(255) not null,
    `ip`    varchar(64) not null,
    `province` varchar(128) not null,
    `phone` varchar(20) not null,
    `question` text not null,
    `allow_leave_msg` tinyint default 0,
    `created`  int not null,
    `updated`  int not null,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 完整名片表
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `title` varchar(255) not null ,
    `contact` varchar(255) not null ,
    `keywords` varchar(255) not null ,
    `essay` text not null ,
    `address` varchar(512) not null,
    `star` int not null ,
    `weight` int not null default 0,
    `created`  int not null,
    `updated`  int not null,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uid` (`uid`) using btree,
    key `idx_address`(`address`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 名片短文表
DROP TABLE IF EXISTS `card_essay`;
CREATE TABLE `card_essay` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `essay` text not null,
    `top` tinyint not null,
    `updated` int not null,
    PRIMARY KEY (`id`),
    key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 名片关键词表
DROP TABLE IF EXISTS `card_key`;
CREATE TABLE `card_key` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `key` varchar(255) not null ,
    PRIMARY KEY (`id`),
    key `idx_uid` (`uid`) using btree,
    key `idx_key` (`key`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 名片扩展数据
DROP TABLE IF EXISTS `card_extend`;
CREATE TABLE `card_extend` (
   `id` int NOT NULL AUTO_INCREMENT,
   `left` varchar(20) NOT NULL,
   `right` varchar(20) NOT NULL,
   `type` tinyint not null ,
   `created`  int not null,
   PRIMARY KEY (`id`),
    UNIQUE KEY `unique_key` (`left`, `right`, `type`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 备注
DROP TABLE IF EXISTS `card_notes`;
CREATE TABLE `card_notes`(
    `id` int NOT NULL AUTO_INCREMENT,
    `left` varchar(20) NOT NULL,
    `right` varchar(20) NOT NULL,
    `cnt` varchar(255) not null,
    PRIMARY KEY (`id`),
    key `idx_left`(`left`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 收藏夹表
DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `key` varchar(255) not null,
    `value` varchar(255) not null,
    `created`  int not null,
    PRIMARY KEY (`id`),
    key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 收藏夹排序表
DROP TABLE IF EXISTS `favorites_order`;
CREATE TABLE `favorites_order` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `order` blob not null,
    PRIMARY KEY (`id`),
    unique key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 留言表
DROP TABLE IF EXISTS `leave_message`;
CREATE TABLE `leave_message` (
    `id` int NOT NULL AUTO_INCREMENT,
    `left` varchar(20) NOT NULL,
    `right` varchar(20) NOT NULL,
    `content` text not null,
    `like_count` int not null default 0,
    `updated`  int not null,
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_left_right` (`left`, `right`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 留言点赞表
DROP TABLE IF EXISTS `leave_message_like`;
CREATE TABLE `leave_message_like` (
     `id` int NOT NULL AUTO_INCREMENT,
     `uid` varchar(20) NOT NULL,
     `leave_id` int not null,
     PRIMARY KEY (`id`),
     UNIQUE KEY `unique_key` (`uid`, `leave_id`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 聊天信息记录表
DROP TABLE IF EXISTS `chat_msg`;
CREATE TABLE `chat_msg` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `sid` varchar(24) not null,
    `msg` varchar(1024) not null,
    `created`  int not null,
    PRIMARY KEY (`id`),
    key `idx_sid` (`sid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 聊天信息读取时间记录
DROP TABLE IF EXISTS `chat_msg_book`;
CREATE TABLE `chat_msg_book` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `sid` varchar(24) not null,
    `msg_time`  int not null,
    PRIMARY KEY (`id`),
    unique key `idx_uid_sid` (`uid`, `sid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 聊天信息会话关系表
DROP TABLE IF EXISTS `chat_session`;
CREATE TABLE `chat_session` (
    `id` int NOT NULL AUTO_INCREMENT,
    `sid` varchar(24) not null,
    `promoter` varchar(20) NOT NULL,
    `receiver` varchar(20) NOT NULL,
    `type` tinyint not null ,
    `created`  int not null,
    PRIMARY KEY (`id`),
    key `idx_sid` (`sid`) using btree,
    unique key `idx_p_r_t` (`promoter`, `receiver`, `type`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 用户的链盘空间记录
DROP TABLE IF EXISTS `disk_size`;
CREATE TABLE `disk_size` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `disk_size` int not null,
    `used_size` int not null,
    `updated`  int not null,
    PRIMARY KEY (`id`),
    key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 链盘文件信息(物理地址存储)
DROP TABLE IF EXISTS `disk_file`;
CREATE TABLE `disk_file` (
    `id` int NOT NULL AUTO_INCREMENT,
    `file_md5` varchar(32) NOT NULL,
    `file_type` varchar(20) not null,
    `file_byte_size` int not null ,
    `file_content` MEDIUMBLOB null,
    `count` int not null,
    `is_preview` tinyint not null,
    `created`  int not null,
    PRIMARY KEY (`id`),
    unique key `idx_file_md5` (`file_md5`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 链盘文件的虚拟路径关系
DROP TABLE IF EXISTS `disk_rel`;
CREATE TABLE `disk_rel` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `parent` varchar(255) not null ,
    `file_name` varchar(255) not null ,
    `file_md5` varchar(32) not null ,
    `file_type` varchar(20) not null,
    `file_byte_size` int not null ,
    `created`  int not null,
    PRIMARY KEY (`id`),
    key `idx_uid` (`uid`) using btree,
    key `idx_parent` (`parent`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 链盘文件排序
DROP TABLE IF EXISTS `disk_order`;
CREATE TABLE `disk_order` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `path` varchar(255) not null,
    `order` blob not null,
    PRIMARY KEY (`id`),
    unique key `idx_uid_path` (`uid`, `path`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 搜词
DROP TABLE IF EXISTS `search_key`;
CREATE TABLE `search_key` (
    `id` int NOT NULL AUTO_INCREMENT,
    `word` varchar(128) not null ,
    `group` varchar(8) not null,
    `created`  int not null,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 地址点击记录
DROP TABLE IF EXISTS `record_address`;
CREATE TABLE `record_address` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `address` blob not null,
    PRIMARY KEY (`id`),
    unique key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# AuthToken持久化存储
DROP TABLE IF EXISTS `user_auth_token`;
CREATE TABLE `user_auth_token` (
    `id` int NOT NULL AUTO_INCREMENT,
    `uid` varchar(20) NOT NULL,
    `token` text not null,
    `seconds` int not null,
    `created` int not null,
    PRIMARY KEY (`id`),
    unique key `idx_uid` (`uid`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 系统配置
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
    `id` int NOT NULL AUTO_INCREMENT,
    `data` blob not null,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
