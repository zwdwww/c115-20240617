# 查链网站

- sChain
> 网站服务端、第一版网站界面

- sChainBack
> 网站的后台服务端和界面

- viewV2
> 使用Vant重构后的网站界面


# 部署

## 依赖

MySQL8.0、nodeV14、nodeV18+、Go1.20、kkfile、GeoLite2-City.mmdb

## 启动项目

1. 初始化数据库

    查链用户数据: 执行`sChain/sChain/sql/init.sql`
    
    查链后台数据: 执行`sChainBack/sChainBack/init.sql`

2. 启动查链用户端服务

    ```shell
    # 进入sChain/sChain文件夹
    go run main.go
    
    # 进入viewV2文件夹
    pnpm run dev  
    ```

3. 启动查链后台服务

    ```shell
    # 进入sChainBack/sChainBack文件夹
    go run main.go
    
    # 进入sChainBack/web文件夹
    npm run dev
    ```