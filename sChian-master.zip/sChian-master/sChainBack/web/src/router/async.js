export const asyncRoutes = [
  {
    path: '/permission',
    component: 'Layout',
    redirect: '/permission/page',
    alwaysShow: true, // will always show the root menu
    name: 'Permission',
    meta: {
      title: '权限管理',
      icon: 'lock'
    },
    children: [
      {
        path: 'role',
        component: 'views/permission/Role',
        name: 'Role',
        meta: {
          title: '角色管理',
          icon: 'el-icon-s-check',
          noCache: true
        }
      },
      {
        path: 'user',
        component: 'views/permission/User',
        name: 'User',
        meta: {
          title: '用户管理',
          icon: 'el-icon-user',
          noCache: true
        }
      }
    ]
  },
  {
    path: '/sysConfig',
    component: 'Layout',
    children: [
      {
        path: 'index',
        component: 'views/SysConfig',
        name: 'SysConfig',
        meta: { title: '系统配置', icon: 'el-icon-setting' }
      }
    ]
  },
  {
    path: '/user',
    component: 'Layout',
    children: [
      {
        path: 'index',
        component: 'views/CardUser',
        name: 'CardUser',
        meta: { title: '用户信息', icon: 'el-icon-user' }
      }
    ]
  },
  {
    path: '/card',
    component: 'Layout',
    children: [
      {
        path: 'index',
        component: 'views/vCard',
        name: 'Card',
        meta: { title: '推荐列表', icon: 'el-icon-tickets' }
      }
    ]
  },
  {
    path: '/keyword',
    component: 'Layout',
    children: [
      {
        path: 'index',
        component: 'views/SearchKey',
        name: 'SearchKey',
        meta: { title: '搜词', icon: 'el-icon-position' }
      }
    ]
  },
  {
    path: '/disk',
    component: 'Layout',
    children: [
      {
        path: 'index',
        component: 'views/Disk',
        name: 'Disk',
        meta: { title: '链盘空间', icon: 'el-icon-coin' }
      }
    ]
  }
]
