import Layout from '@/layout'

export const RouterMapping = {
  'Layout': Layout,
  'views/permission/User': () => import('@/views/permission/User'),
  'views/permission/Role': () => import('@/views/permission/Role'),
  'views/Disk': () => import('@/views/Disk'),
  'views/vCard': () => import('@/views/vCard'),
  'views/CardUser': () => import('@/views/CardUser'),
  'views/SearchKey': () => import('@/views/SearchKey'),
  'views/SysConfig': () => import('@/views/SysConfig')
}
