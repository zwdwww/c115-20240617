<template>
  <div class="app-container">
    <el-card class="box-card">
      <div class="filter-container">
        <div class="filter-item" style="margin-right: 10px">
          <el-input
            v-model="input.username"
            placeholder="请输入查链ID"
            clearable
          />
        </div>

        <div class="filter-item" style="margin-right: 10px">
          <el-input
            v-model="input.phone"
            placeholder="请输入手机号"
            clearable
          />
        </div>

        <el-button
          class="filter-item"
          type="success"
          @click="dialogVisible = true"
        >
          新增用户
        </el-button>

        <el-button
          class="filter-item"
          type="primary"
          @click="searchData(1)"
        >
          查询
        </el-button>
      </div>
      <el-table v-loading="loading" :data="list" style="width: 100%">
        <el-table-column prop="Username" label="查链ID" align="center" />
        <el-table-column prop="Phone" label="绑定手机" align="center" />
        <el-table-column prop="Ip" label="Ip地址" align="center" />
        <el-table-column prop="Province" label="Ip所属省份" align="center" />
        <el-table-column prop="Created" label="创建时间" align="center" sortable>
          <template slot-scope="scope">
            {{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Created) }}
          </template>
        </el-table-column>
        <el-table-column prop="Updated" label="最近登录时间" align="center" sortable>
          <template slot-scope="scope">
            {{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Updated) }}
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作" width="260" fixed="right">
          <template slot-scope="scope">
            <el-button type="warning" size="small" icon="el-icon-refresh" @click="resetPassword(scope.row)">重置密码</el-button>
            <el-button type="warning" size="small" icon="el-icon-refresh" @click="resetPhone(scope.row)">重置手机号</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        style="margin-top: 10px"
        :current-page="input.page"
        :page-sizes="[10, 20, 50, 100, 200, 300, 400]"
        :page-size="input.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="count"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />

      <el-dialog
        title="创建用户"
        :visible.sync="dialogVisible"
        width="50%"
      >
        <el-form :model="userForm" label-width="160px">
          <el-form-item label="查链ID(不要带域名.115)">
            <el-input v-model="userForm.username" placeholder="请输入ID" />
          </el-form-item>
          <el-form-item label="密码">
            <el-input v-model="userForm.password" type="password" placeholder="请输入密码" />
          </el-form-item>
          <el-form-item label="关联手机号">
            <el-input v-model="userForm.phone" placeholder="请输入手机号" />
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="createUser">创 建</el-button>
        </span>
      </el-dialog>
    </el-card>
  </div>
</template>

<script>
import { cardUserCreate, cardUserList, cardUserSetPassword, cardUserSetPhone } from '@/api/schain'
import { unixFormat } from '@/utils/date'

export default {
  name: 'CardUser',
  data() {
    return {
      dialogVisible: false,
      list: [],
      count: 0,
      loading: false,
      userForm: {
        username: '',
        password: '',
        phone: ''
      },
      input: {
        page: 1,
        limit: 10,
        username: '',
        phone: ''
      }
    }
  },
  created() {
    this.searchData()
  },
  methods: {
    unixFormat,
    async searchData(val) {
      if (typeof val === 'number') {
        this.input.page = val
      }
      this.loading = true
      const data = (await cardUserList(this.input)).data
      this.loading = false
      this.list = data.items || []
      this.count = data.count || 0
      this.$message.success('查询完成')
    },
    async createUser() {
      if (this.userForm.username === '') {
        this.$message.error('ID异常')
        return
      }
      if (this.userForm.password === '') {
        this.$message.error('请输入密码')
        return
      }
      if (this.userForm.phone === '') {
        this.$message.error('请输入手机号')
        return
      }
      await cardUserCreate(this.userForm)
      this.userForm.username = ''
      this.userForm.phone = ''
      this.userForm.password = ''
      this.dialogVisible = false
      await this.searchData(1)
    },
    handleSizeChange(val) {
      this.input.limit = val
      this.input.page = 1
      this.searchData()
    },
    handleCurrentChange(val) {
      this.input.page = val
      this.searchData()
    },
    resetPassword(row) {
      this.$prompt('请输入新密码', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value.length < 6) {
          this.$message.error('密码应不少于6位')
          return
        }
        cardUserSetPassword({ username: row.Username, password: value }).then(() => {
          this.$message.success('修改成功')
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消修改'
        })
      })
    },
    resetPhone(row) {
      this.$prompt('请输入新的手机号', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value.length !== 11) {
          this.$message.error('请输入正确的手机号')
          return
        }
        cardUserSetPhone({ username: row.Username, phone: value }).then(() => {
          this.$message.success('修改成功')
          row.Phone = value
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消修改'
        })
      })
    }
  }
}
</script>

<style scoped lang="scss">

</style>
