<template>
  <div class="app-container">
    <el-card class="box-card">
      <div class="filter-container">
        <el-input
          v-model="importTest"
          type="textarea"
          :rows="5"
          placeholder="输入搜词,多个搜词使用空格分隔"
        />
      </div>
      <div class="filter-container">
        <el-button class="filter-item" icon="el-icon-check" type="primary" @click="importSearchKey">
          导入文本中的搜词
        </el-button>
        <el-button
          class="filter-item"
          icon="el-icon-plus"
          type="primary"
          @click="addSearchKey"
        >
          新增搜词
        </el-button>
      </div>
      <el-table :data="list" style="width: 100%">
        <el-table-column align="center" prop="Group" label="首字母" />
        <el-table-column align="center" prop="Word" label="搜词" />
        <el-table-column align="center" label="创建时间">
          <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Created) }}</template>
        </el-table-column>
        <el-table-column align="center" label="操作" width="200" fixed="right">
          <template slot-scope="scope">
            <el-button type="danger" size="small" icon="el-icon-delete" @click="delSearchKey(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="count > 0"
        style="margin-top: 20px"
        :current-page="form.page"
        :page-sizes="[10, 20, 50, 100, 200, 300, 400]"
        :page-size="form.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="count"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script>
import { pinyin } from 'pinyin-pro'
import { searchKeyAdd, searchKeyBulk, searchKeyDel, searchKeyList } from '@/api/schain'
import { unixFormat } from '@/utils/date'

export default {
  name: 'SearchKey',
  data() {
    return {
      importTest: '',
      list: [],
      count: 0,
      form: {
        page: 1,
        limit: 10
      }
    }
  },
  created() {
    this.getData()
  },
  methods: {
    unixFormat,
    handleSizeChange(val) {
      this.form.limit = val
      this.form.page = 1
      this.getData()
    },
    handleCurrentChange(val) {
      this.form.page = val
      this.getData()
    },
    async getData() {
      const data = (await searchKeyList(this.form)).data
      this.list = data.items || []
      this.count = data.count || 0
    },
    async importSearchKey() {
      if (!this.importTest) return
      const items = []
      const textSplit = this.importTest.split(' ')
      for (const strV of textSplit) {
        const v = strV.trim()
        if (!v) continue
        const resp = pinyin(v, { toneType: 'none', type: 'array' })
        items.push({ word: v, group: resp[0][0] })
      }
      await searchKeyBulk({ items: items })
      await this.getData()
      this.$message.success('导入成功')
    },
    addSearchKey() {
      this.$prompt('请输入搜词', '添加搜词', {
        confirmButtonText: '确认',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        if (value === '') {
          return
        }
        const resp = pinyin(value, { toneType: 'none', type: 'array' })
        searchKeyAdd({ word: value, group: resp[0][0] }).then(() => {
          this.getData()
          this.$message.success('添加成功')
        })
      })
    },
    async delSearchKey(row) {
      await searchKeyDel({ id: row.ID })
      await this.getData()
      this.$message.success('删除成功')
    }
  }
}
</script>

<style scoped lang="scss">

</style>
