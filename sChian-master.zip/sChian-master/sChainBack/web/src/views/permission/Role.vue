<template>
  <div class="app-container">
    <el-card class="box-card">
      <el-button icon="el-icon-plus" type="primary" @click="openAdd">新建角色</el-button>
      <div style="margin-top: 10px">
        <el-table :data="tableData" style="width: 100%">
          <el-table-column align="center" prop="id" label="角色ID" width="400" />
          <el-table-column align="center" prop="role_name" label="角色名" />
          <el-table-column align="center" label="操作" width="200" fixed="right">
            <template slot-scope="scope">
              <el-button type="primary" size="small" icon="el-icon-edit" @click="openEdit(scope.row)">编辑</el-button>
              <el-button type="danger" size="small" icon="el-icon-delete-solid" @click="roleDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-dialog :visible.sync="dialogVisible" :title="isEdit ? '编辑角色' : '添加角色'" width="50%">
        <el-form :model="form" label-width="100px" label-position="left">
          <el-form-item label="角色名">
            <el-input v-model="form.role_name" placeholder="角色名" />
          </el-form-item>
          <el-form-item label="菜单栏">
            <el-input placeholder="输入关键字进行过滤" style="width: 300px;margin-right: 5px" />
            <el-button icon="el-icon-shopping-cart-full" @click="checkedAll">全选</el-button>
            <el-tree
              ref="tree"
              style="margin-top: 10px"
              :filter-node-method="filterNode"
              :data="routersTree"
              :check-strictly="checkStrictly"
              :props="props"
              show-checkbox
              node-key="path"
              class="permission-tree"
            />
          </el-form-item>
        </el-form>
        <div style="text-align:right;">
          <el-button type="danger" icon="el-icon-close" @click="dialogVisible=false">取 消</el-button>
          <el-button v-if="isEdit" type="primary" icon="el-icon-check" @click="edit">编 辑</el-button>
          <el-button v-else type="primary" icon="el-icon-check" @click="add">确 认</el-button>
        </div>
      </el-dialog>

    </el-card>
  </div>
</template>

<script>
import { asyncRoutes } from '@/router/async'
import { RoleList, RoleAdd, RoleDelete, RoleUpdate } from '@/api/role'

export default {
  name: 'Role',
  data() {
    return {
      tableData: [],
      dialogVisible: false,
      form: {
        id: '',
        role_name: '',
        role_routers: ''
      },
      props: {
        label: 'name',
        children: 'children'
      },
      isEdit: false,
      checkStrictly: false,
      routersTree: []
    }
  },
  created() {
    const tree = []
    this.generateRouterTree(asyncRoutes, tree)
    this.routersTree = tree
  },
  mounted() {
    this.list()
  },
  methods: {
    list() {
      RoleList({ page: 1, limit: 10 }).then((res) => {
        this.tableData = res.data || []
      })
    },
    add() {
      if (this.form.name === '') {
        this.$message.error('请输入角色名')
        return
      }
      this.form.role_routers = JSON.stringify(this.getRouters())
      RoleAdd(this.form).then(() => {
        this.dialogVisible = false
        this.list()
        this.$notify.success('添加成功')
      })
    },
    roleDelete(row) {
      RoleDelete(row).then(() => {
        this.$notify.success('删除成功')
        this.list()
      })
    },
    edit() {
      this.form.role_routers = JSON.stringify(this.getRouters())
      RoleUpdate(this.form).then(() => {
        this.dialogVisible = false
        this.$notify.success('修改成功')
        this.list()
      })
    },
    openAdd() {
      this.dialogVisible = true
      if (this.isEdit) {
        this.form.role_name = ''
        this.isEdit = false
        this.form.role_routers = ''
        this.$nextTick(() => {
          this.$refs.tree.setCheckedNodes([])
        })
      }
    },
    openEdit(row) {
      this.dialogVisible = true
      this.checkStrictly = true
      this.form.role_name = row.role_name
      this.form.id = row.id
      this.isEdit = true
      if (row.role_routers === '') {
        this.$nextTick(() => {
          this.$refs.tree.setCheckedNodes([])
          this.checkStrictly = false
        })
        return
      }
      const routers = JSON.parse(row.role_routers)
      const checkedNodes = []
      this.getCheckedRouters(routers, '', checkedNodes)
      this.$nextTick(() => {
        this.$refs.tree.setCheckedNodes(checkedNodes)
        this.checkStrictly = false
      })
    },
    checkedAll() {
      const accept = []
      this.getCheckedRouters(asyncRoutes, '', accept)
      this.$refs.tree.setCheckedNodes(accept)
    },
    getCheckedRouters(routers, rootPath, accept) {
      for (const router of routers) {
        accept.push({ path: rootPath + router.path })
        if (typeof router.children !== 'undefined') {
          this.getCheckedRouters(router.children, router.path + '/', accept)
        }
      }
    },
    filterNode() {
    },
    generateRouterTree(routers, save, parent, path = null) {
      const rootPath = path === null ? '' : path
      for (const router of routers) {
        if (router.path === '*') continue
        if (typeof router.name === 'undefined') {
          const node = {
            name: router.children[0].meta.title,
            isLeaf: true,
            path: rootPath + router.path,
            source: router
          }
          save.push(node)
        } else {
          const node = {
            name: router.meta.title,
            path: rootPath + router.path,
            isLeaf: false,
            children: [],
            source: router,
            parent: parent
          }
          save.push(node)
          if (typeof router.children !== 'undefined') {
            const _parent = { ...router }
            _parent.children = []
            this.generateRouterTree(router.children, node.children, _parent, node.path + '/')
          }
        }
      }
    },
    getRouters() {
      const nodes = this.$refs.tree.getCheckedNodes(true)
      const tree = {}
      for (const node of nodes) {
        if (typeof node.parent !== 'undefined') {
          if (node.parent.path in tree) {
            tree[node.parent.path].children.push(node.source)
          } else {
            tree[node.parent.path] = node.parent
            tree[node.parent.path].children.push(node.source)
          }
        } else {
          tree[node.path] = node.source
        }
      }
      return Object.values(tree)
    }
  }
}
</script>

<style scoped>

</style>
