<template>
  <div class="app-container">
    <el-card class="box-card">
      <el-button icon="el-icon-plus" type="primary" @click="openAdd">新建用户</el-button>
      <div style="margin-top: 10px">
        <el-table :data="tableData" style="width: 100%">
          <el-table-column align="center" prop="id" label="用户ID" width="200" />
          <el-table-column align="center" prop="username" label="用户名" />
          <el-table-column align="center" prop="role_name" label="角色" />
          <el-table-column align="center" label="创建日期" width="200">
            <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.created) }}</template>
          </el-table-column>
          <el-table-column align="center" label="修改日期" width="200">
            <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.updated) }}</template>
          </el-table-column>
          <el-table-column align="center" label="操作" width="300" fixed="right">
            <template slot-scope="scope">
              <el-button type="primary" size="small" icon="el-icon-edit" @click="openEdit(scope.row)">编辑</el-button>
              <el-button type="warning" size="small" icon="el-icon-refresh" @click="resetPassword(scope.row)">重置密码</el-button>
              <el-button type="danger" size="small" icon="el-icon-delete-solid" @click="userDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <el-dialog :visible.sync="dialogVisible" :title="isEdit ? '编辑用户' : '添加用户'" width="50%">
        <el-form ref="addForm" :model="form" :rules="formRules" label-width="100px" label-position="left">
          <el-form-item label="用户名" prop="username">
            <el-input v-model="form.username" placeholder="请输入用户名" />
          </el-form-item>
          <el-form-item v-show="!isEdit" label="用户密码" prop="password">
            <el-input v-model="form.password" placeholder="用户密码" type="password" />
          </el-form-item>
          <el-form-item label="角色选择" prop="role_id">
            <el-select v-model="form.role_id">
              <el-option v-for="(v, i) in Object.keys(roleMap)" :key="i" :label="roleMap[v]" :value="v" />
            </el-select>
          </el-form-item>
        </el-form>
        <div style="text-align:right;">
          <el-button type="danger" icon="el-icon-close" @click="dialogVisible=false">取 消</el-button>
          <el-button v-if="isEdit" type="primary" icon="el-icon-check" @click="edit">编 辑</el-button>
          <el-button v-else type="primary" icon="el-icon-check" @click="add">确 认</el-button>
        </div>
      </el-dialog>
    </el-card>
  </div>
</template>
<script>

import { UserAdd, UserList, UserUpdate, UserDelete, UserResetPassword } from '@/api/user'
import { RoleList } from '@/api/role'
import { unixFormat } from '../../utils/date'

export default {
  name: 'User',
  data() {
    return {
      tableData: [],
      isEdit: false,
      dialogVisible: false,
      formRules: {
        username: [{ required: true, trigger: 'blur' }],
        password: [{ required: true, trigger: 'blur' }],
        role_id: [{ required: true, trigger: 'blur' }]
      },
      form: {
        id: -1,
        username: '',
        password: '',
        role_id: '',
        page: 1,
        limit: 10
      },
      roleMap: {}
    }
  },
  created() {
    this.getRoleMap(this.searchData)
  },
  methods: {
    unixFormat,
    add() {
      this.$refs.addForm.validate(valid => {
        if (valid) {
          UserAdd(this.form).then(() => {
            this.searchData()
            this.dialogVisible = false
            this.$message.success('创建成功')
          })
        } else {
          return false
        }
      })
    },
    edit() {
      this.$refs.addForm.validate(valid => {
        if (valid) {
          UserUpdate(this.form).then(() => {
            this.searchData()
            this.dialogVisible = false
            this.$message.success('修改成功')
          })
        } else {
          return false
        }
      })
    },
    userDelete(row) {
      UserDelete(row).then(() => {
        this.searchData()
        this.$message.success('删除成功')
      })
    },
    resetPassword(row) {
      this.$prompt('请输入新的密码', '重置密码', {
        confirmButtonText: '重置',
        cancelButtonClass: '取消'
      }).then(({ value }) => {
        const form = { ...row }
        form.new_password = value
        UserResetPassword(form).then(() => {
          if (this.$store.getters.name === row.username) {
            this.$message.warning('请重新登录')
            this.$store.dispatch('user/logout')
            setTimeout(() => {
              location.reload()
            }, 1000)
          } else {
            this.$message.success('重置成功')
          }
        })
      }).catch(() => {
      })
    },
    openAdd() {
      if (this.isEdit) {
        this.form.username = ''
        this.form.password = ''
        this.form.role_id = ''
        this.form.id = ''
      }
      this.dialogVisible = true
      this.isEdit = false
    },
    openEdit(row) {
      this.form.id = row.id
      this.form.username = row.username
      this.form.password = 'edit'
      this.form.role_id = row.role_id.toString()
      this.isEdit = true
      this.dialogVisible = true
    },
    searchData() {
      UserList(this.form).then((res) => {
        const items = res.data || []
        for (const item of items) {
          item.role_name = this.roleMap[item.role_id]
        }
        this.tableData = items
      })
    },
    getRoleMap(callable) {
      RoleList({ types: 'map' }).then((res) => {
        this.roleMap = res.data.data || {}
        callable()
      })
    }
  }
}
</script>

<style scoped>

</style>
