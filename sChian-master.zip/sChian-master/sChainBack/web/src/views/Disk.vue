<template>
  <div class="app-container">
    <el-card class="box-card">
      <div class="filter-container">
        <el-button
          type="primary"
          icon="el-icon-plus"
          style="margin-right: 10px"
          class="filter-item"
          @click="earlyCreateDiskSize"
        >
          提前分配空间
        </el-button>
        <div class="filter-item">
          只有用户<strong>上传一次文件</strong>后系统才会分配存储空间(也可以手动提前进行分配)
        </div>
      </div>
      <el-table :data="list" style="width: 100%">
        <el-table-column align="center" prop="Uid" label="查链ID" />
        <el-table-column align="center" prop="DiskSize" label="总空间" />
        <el-table-column align="center" prop="SurplusSize" label="剩余空间" />
        <el-table-column align="center" label="更新时间">
          <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Updated) }}</template>
        </el-table-column>
        <el-table-column align="center" label="操作" width="320" fixed="right">
          <template slot-scope="scope">
            <el-button type="success" size="small" icon="el-icon-plus" @click="changeDiskSize(scope.row, 'add')">添加链盘空间</el-button>
            <el-button type="danger" size="small" icon="el-icon-minus" @click="changeDiskSize(scope.row, 'sub')">减少链盘空间</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="count > 0"
        style="margin-top: 20px"
        :current-page="form.page"
        :page-sizes="[10, 20, 50, 100, 200, 300, 400]"
        :page-size="form.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="count"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script>
import { diskSize, diskSizeChange, diskSizeEarlyCreate } from '@/api/schain'
import { unixFormat } from '../utils/date'

export default {
  name: 'Disk',
  data() {
    return {
      list: [],
      form: {
        page: 1,
        limit: 10
      },
      count: 0
    }
  },
  created() {
    this.getData()
  },
  methods: {
    unixFormat,
    async getData() {
      const data = (await diskSize(this.form)).data
      const items = data.items || []
      for (const item of items) {
        item.SurplusSize = `${((item.DiskSize - item.UsedSize) / 1024 / 1024).toFixed(2)}MB`
        item.DiskSize = `${(item.DiskSize / 1024 / 1024).toFixed(2)}MB`
      }
      this.list = items
      this.count = data.count || 0
    },
    handleSizeChange(val) {
      this.form.limit = val
      this.form.page = val
      this.getData()
    },
    handleCurrentChange(val) {
      this.form.page = val
      this.getData()
    },
    // 修改存储空间
    changeDiskSize(row, addOrSub) {
      let cnt = ''
      if (addOrSub === 'add') {
        cnt = '需要添加多少(MB)空间'
      } else {
        cnt = '需要减少多少(MB)空间'
      }
      this.$prompt(cnt, '修改存储空间', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        let size = (parseInt(value) || 0) * 1024 * 1024
        if (addOrSub === 'sub') {
          if (row.DiskSize - size <= 0) {
            this.$message.warning('存储空间不能小于0MB')
            return
          }
          size *= -1
        }
        diskSizeChange({ uid: row.Uid, size: size }).then(() => {
          this.getData()
          this.$message.success('修改成功')
        })
      })
    },
    // 提前创建存储空间
    earlyCreateDiskSize() {
      this.$prompt('请输入查链ID(需要去除域名)', '提前创建存储空间', {
        confirmButtonText: '确认',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        const uid = parseInt(value)
        diskSizeEarlyCreate({ uid: uid }).then(() => {
          this.getData()
          this.$message.success('创建成功')
        })
      })
    }
  }
}
</script>

<style scoped lang="scss">

</style>
