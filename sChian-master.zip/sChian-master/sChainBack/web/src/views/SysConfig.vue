<template>
  <div class="app-container">
    <el-card class="box-card">
      <el-button type="primary" @click="setSysConfig">确认修改</el-button>
      <el-divider content-position="left">配置</el-divider>
      <el-form label-width="120px">
        <el-form-item label="上链库">
          <el-input v-model="form.TopDbLink" />
        </el-form-item>
        <el-form-item label="下链库">
          <el-input v-model="form.DownDbLink" />
        </el-form-item>
        <el-form-item label="文库">
          <el-input v-model="form.LibraryLink" />
        </el-form-item>
        <el-form-item label="新用户链盘大小">
          <el-input v-model="form.DefaultDiskSize" type="number">
            <template slot="suffix">MB</template>
          </el-input>
        </el-form-item>
      </el-form>
    </el-card>
    <el-card class="box-card" style="margin-top: 20px">
      <el-button type="primary" @click="setSysConfig">确认修改</el-button>
      <el-divider content-position="left">注册名片默认值</el-divider>
      <el-form label-width="120px">
        <el-form-item label="默认名称">
          <el-input v-model="form.CardName" placeholder="不输入默认使用自己的ID作为名称" />
        </el-form-item>
        <el-form-item label="默认地址">
          <el-input v-model="form.CardAddress" />
        </el-form-item>
        <el-form-item label="默认搜词">
          <el-input v-model="form.CardKey" />
        </el-form-item>
        <el-form-item label="默认短文">
          <el-input v-model="form.CardEssay" type="textarea" />
        </el-form-item>
      </el-form>
    </el-card>
    <el-card class="box-card" style="margin-top: 20px">
      <el-button type="primary" @click="setSysConfig">确认修改</el-button>
      <el-divider content-position="left">404名片默认值</el-divider>
      <el-form label-width="120px">
        <el-form-item label="默认链号ID">
          <el-input v-model="form.ID404" />
        </el-form-item>
        <el-form-item label="默认名称">
          <el-input v-model="form.Name404" />
        </el-form-item>
        <el-form-item label="默认地址">
          <el-input v-model="form.Address404" />
        </el-form-item>
        <el-form-item label="默认搜词">
          <el-input v-model="form.Key404" />
        </el-form-item>
        <el-form-item label="默认短文">
          <el-input v-model="form.Essay404" type="textarea" />
        </el-form-item>
      </el-form>
    </el-card>
    <el-card class="box-card" style="margin-top: 20px">
      <div class="filter-container">
        <el-button type="primary" @click="setSysConfig">确认修改</el-button>
        <el-button type="success" @click="form.DefaultFav.push({ Key: '', Value: '' })">添加收藏夹</el-button>
      </div>
      <el-divider content-position="left">收藏夹默认内容</el-divider>
      <el-form label-width="120px">
        <div v-for="(item, i) in form.DefaultFav" :key="i">
          <el-form-item :label="`收藏夹名称-${i+1}`">
            <el-input v-model="item.Key" />
          </el-form-item>
          <el-form-item :label="`收藏夹链接-${i+1}`">
            <el-input v-model="item.Value" />
          </el-form-item>
        </div>
      </el-form>
    </el-card>
    <el-card class="box-card" style="margin-top: 20px">
      <el-divider content-position="left">网盘注册默认文件</el-divider>
      <el-upload
        ref="upload"
        :file-list="fileList"
        :on-change="onChangeFile"
        :auto-upload="false"
        style="margin-left: 50px;margin-bottom: 20px"
        :action="uploadAction"
        :on-success="uploadSuccess"
        name="File"
        multiple
      >
        <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
        <el-button style="margin-left: 10px;" size="small" type="success" @click="submitUpload">上传到服务器</el-button>
      </el-upload>
      <div>
        <el-form label-width="120px">
          <el-form-item label="默认文件名">
            <div v-for="(item, i) in form.DefaultDisk" :key="i" style="display: flex;margin-bottom: 10px">
              <el-input
                v-model="item.DiskName"
                style="padding-right: 20px"
                @change="diskNameChange"
              />
              <el-button type="success" @click="diskPreview(item.DiskId)">预览</el-button>
              <el-button type="danger" @click="diskRemove(i)">删除</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>
import { sysConfig, sysConfigDiskPreview, sysConfigDiskRemove, sysConfigSet } from '@/api/schain'

export default {
  name: 'SysConfig',
  data() {
    return {
      waitUploadFileCount: 0,
      fileList: [],
      uploadAction: process.env.VUE_APP_BASE_API + '/schain/sys/upload',
      form: {
        DefaultDisk: [],
        DefaultFav: [],
        DbLink: '',
        CardName: '',
        CardAddress: '',
        CardKey: '',
        CardEssay: '',
        ID404: '',
        Name404: '',
        Address404: '',
        Key404: '',
        Essay404: ''
      }
    }
  },
  created() {
    this.searchData()
  },
  methods: {
    submitUpload() {
      this.$refs.upload.submit()
    },
    async searchData() {
      this.form = (await sysConfig()).data
      this.form.DefaultFav = this.form.DefaultFav || []
      this.form.DefaultDisk = this.form.DefaultDisk || []
    },
    async setSysConfig() {
      await sysConfigSet({ data: this.form })
      await this.searchData()
      this.$message.success('修改成功')
    },
    onChangeFile(file, fileList) {
      console.log(file)
      this.fileList = fileList
    },
    startWaitUploadFile() {
      if (this.waitUploadFileCount === this.form.DefaultDisk.length) {
        this.$message.success('文件同步结束')
        return
      }
      this.searchData()
      setTimeout(this.startWaitUploadFile, 100)
    },
    uploadSuccess() {
      for (const item of this.fileList) {
        if (item.status !== 'success') return
      }
      this.$message.success('上传完成')
      this.waitUploadFileCount = this.form.DefaultDisk.length + this.fileList.length
      this.startWaitUploadFile()
    },
    async diskNameChange() {
      await this.setSysConfig()
    },
    async diskPreview(diskId) {
      const url = (await sysConfigDiskPreview({ diskId })).data || ''
      window.open(url)
    },
    async diskRemove(index) {
      await sysConfigDiskRemove({ index: index })
      this.$message.success('删除成功')
      await this.searchData()
    }
  }
}
</script>

<style scoped>

</style>
