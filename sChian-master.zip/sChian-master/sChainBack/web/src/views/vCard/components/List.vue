<template>
  <div>
    <el-table
      ref="multipleTable"
      :data="list"
      style="width: 100%"
      @selection-change="handleSelect"
    >
      <el-table-column type="selection" width="55" />
      <el-table-column align="center" prop="Uid" label="查链ID" />
      <el-table-column align="center" prop="Title" label="标题" />
      <el-table-column align="center" prop="Star" label="关注数" />
      <el-table-column align="center" label="更新时间">
        <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Updated) }}</template>
      </el-table-column>
    </el-table>
    <el-pagination
      v-if="count > 0"
      style="margin-top: 20px"
      :current-page="form.page"
      :page-sizes="[10, 20, 50, 100, 200, 300, 400]"
      :page-size="form.limit"
      layout="total, sizes, prev, pager, next, jumper"
      :total="count"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
    <div style="margin-top: 20px;text-align: right">
      <el-button type="primary" @click="changeSuggest">导入推荐名片</el-button>
    </div>
  </div>
</template>

<script>
import { cardList } from '@/api/schain'
import { unixFormat } from '../../../utils/date'

export default {
  name: 'List',
  data() {
    return {
      list: [],
      form: {
        page: 1,
        limit: 10
      },
      count: 0,
      suggest: [],
      isInit: true
    }
  },
  created() {
    this.getData()
  },
  methods: {
    unixFormat,
    async getData() {
      const data = (await cardList(this.form)).data
      this.list = data.items || []
      this.count = data.count || 0
      this.isInit = true

      this.$nextTick(() => {
        for (const item of this.list) {
          if (this.suggest.includes(item.ID)) {
            this.$refs.multipleTable.toggleRowSelection(item)
          }
        }
        this.isInit = false
      })
    },
    handleSelect(val) {
      if (this.isInit) {
        return
      }
      const add = []
      const del = []
      const valArr = []

      for (const v of val) {
        valArr.push(v.ID)
      }

      for (const v of this.list) {
        if (valArr.includes(v.ID)) {
          add.push(v.ID)
        } else {
          del.push(v.ID)
        }
      }

      for (const v of add) {
        if (this.suggest.includes(v)) {
          continue
        }
        this.suggest.push(v)
      }

      if (del.length !== 0) {
        const tmp = []
        for (const v of this.suggest) {
          if (del.includes(v)) {
            continue
          }
          tmp.push(v)
        }
        this.suggest = tmp
      }
      console.log(this.suggest)
    },
    changeSuggest() {
      this.$emit('change', this.suggest)
    },
    handleSizeChange(val) {
      this.form.page = 1
      this.form.limit = val
      this.getData()
    },
    handleCurrentChange(val) {
      this.form.page = val
      this.getData()
    }
  }
}
</script>

<style scoped lang="scss">

</style>
