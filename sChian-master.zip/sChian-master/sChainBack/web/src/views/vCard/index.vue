<template>
  <div class="app-container">
    <el-card class="box-card">
      <div class="filter-container">
        <el-input
          v-model="importTest"
          type="textarea"
          :rows="5"
          placeholder="输入查链ID,多个查链ID请使用空格分隔"
        />
      </div>
      <div class="filter-container">
        <el-button class="filter-item" icon="el-icon-check" type="primary" @click="importSuggest">
          导入文本中的查链ID
        </el-button>
        <el-button
          class="filter-item"
          icon="el-icon-plus"
          type="primary"
          @click="dialogVisible=true"
        >
          导入推荐名片
        </el-button>
      </div>
      <el-table :data="list" style="width: 100%">
        <el-table-column align="center" prop="Uid" label="查链ID" />
        <el-table-column align="center" prop="Title" label="标题" />
        <el-table-column align="center" prop="Star" label="关注数" />
        <el-table-column align="center" label="更新时间">
          <template slot-scope="scope">{{ unixFormat('YYYY-mm-dd HH:MM:SS', scope.row.Updated) }}</template>
        </el-table-column>
        <el-table-column align="center" label="操作" width="420" fixed="right">
          <template slot-scope="scope">
            <el-button type="primary" size="small" icon="el-icon-caret-top" @click="top(scope.row)">置顶</el-button>
            <el-button type="success" size="small" icon="el-icon-upload2" @click="up(scope.row)">上移一位</el-button>
            <el-button type="success" size="small" icon="el-icon-download" @click="down(scope.row)">下移一位</el-button>
            <el-button type="danger" size="small" icon="el-icon-close" @click="cancel(scope.row)">取消推荐</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        v-if="count > 0"
        style="margin-top: 20px"
        :current-page="form.page"
        :page-sizes="[10, 20, 50, 100, 200, 300, 400]"
        :page-size="form.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="count"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>

    <el-dialog
      title="选择推荐名片"
      :visible.sync="dialogVisible"
      width="80%"
    >
      <List v-if="dialogVisible" @change="updateSuggest" />
    </el-dialog>
  </div>
</template>

<script>
import { setSuggest, suggest } from '@/api/schain'
import { unixFormat } from '@/utils/date'

export default {
  name: 'Card',
  components: {
    List: () => import('./components/List')
  },
  data() {
    return {
      sourceList: [],
      list: [],
      dialogVisible: false,
      form: {
        page: 1,
        limit: 10
      },
      count: 0,
      suggest: [],
      importTest: ''
    }
  },
  created() {
    this.getData()
  },
  methods: {
    unixFormat,
    sortList(items, suggest) {
      const order = {}
      for (let i = 0; i < suggest.length; i++) {
        order[suggest[i]] = i
      }

      items.sort(function(a, b) {
        return (order[a.ID] || 0) - (order[b.ID] || 0)
      })
      return items
    },
    // 导入推荐名片
    async importSuggest() {
      if (!this.importTest) {
        this.$message.error('请输入ID后再点击导入')
        return
      }

      const array = this.importTest.split(' ')
      const suggest = []
      for (const e of array) {
        suggest.push(e.trim())
      }
      await setSuggest({ order: this.suggest, uid: suggest })
      await this.getData()
      this.$message.success('导入成功')
      this.importTest = ''
    },
    // 获取推荐列表数据
    async getData() {
      const data = (await suggest(this.form)).data
      this.sourceList = data.items || []
      this.suggest = data.suggest || []
      for (const item of data.items) {
        this.suggest.push(item.ID)
      }
      this.count = this.sourceList.length
      this.handleCurrentChange(1)
    },
    // 更新推荐列表
    async updateSuggest(val) {
      const tmp = []
      for (const v of val) {
        if (this.suggest.includes(v)) {
          continue
        }
        tmp.push(v)
      }
      const suggest = this.suggest.concat(tmp)
      await setSuggest({ order: suggest })
      await this.getData()
      this.$message.success('设置成功')
      this.dialogVisible = false
    },
    indexOfByList(id) {
      for (let i = 0; i < this.sourceList.length; i++) {
        if (this.sourceList[i].ID === id) {
          return i
        }
      }
      return -1
    },
    async swap(a, b) {
      const swap = this.sourceList[a]
      this.$set(this.sourceList, a, this.sourceList[b])
      this.$set(this.sourceList, b, swap)

      const swapSug = this.suggest[a]
      this.$set(this.suggest, a, this.suggest[b])
      this.$set(this.suggest, b, swapSug)
      await setSuggest({ order: this.suggest })
      this.handleCurrentChange(this.form.page)
    },
    // 上移
    async up(row) {
      const index = this.indexOfByList(row.ID)
      console.log(row, index)
      if (index > 0) {
        await this.swap(index - 1, index)
        this.$message.success('上移成功')
      }
    },
    // 下移
    async down(row) {
      const index = this.indexOfByList(row.ID)
      if (index >= 0 && index !== (this.sourceList.length - 1)) {
        await this.swap(index + 1, index)
        this.$message.success('下移成功')
      }
    },
    // 置顶
    async top(row) {
      const index = this.indexOfByList(row.ID)
      if (index > 0) {
        const tmp = this.sourceList.splice(index, 1)
        const tmpSug = this.suggest.splice(index, 1)
        this.sourceList = tmp.concat(this.sourceList)
        this.suggest = tmpSug.concat(this.suggest)
        await setSuggest({ order: this.suggest })
        this.handleCurrentChange(this.form.page)
        this.$message.success('置顶成功')
      }
    },
    // 取消推荐
    async cancel(row) {
      const index = this.indexOfByList(row.ID)
      this.suggest.splice(index, 1)
      this.sourceList.splice(index, 1)
      this.count = this.suggest.length
      await setSuggest({ order: this.suggest })
      this.handleCurrentChange(this.form.page)
      this.$message.success('已取消推荐')
    },
    handleSizeChange(val) {
      this.form.page = 1
      this.form.limit = val
      this.handleCurrentChange(1)
    },
    handleCurrentChange(val) {
      this.form.page = val
      const start = (val - 1) * this.form.limit
      const end = start + this.form.limit
      this.list = this.sourceList.slice(start, end)
    }
  }
}
</script>

<style scoped lang="scss">

</style>
