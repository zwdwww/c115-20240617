import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/user/login',
    method: 'post',
    data
  })
}

export function getInfo() {
  return request({
    url: '/user/info',
    method: 'post'
  })
}

export function logout() {
  return request({
    url: '/user/logout',
    method: 'post'
  })
}

export function UserAdd(data) {
  return request.post('/user/add', data)
}

export function UserUpdate(data) {
  return request.post('/user/update', data)
}

export function UserDelete(data) {
  return request.post('/user/delete', data)
}

export function UserList(data) {
  return request.post('/user/list', data)
}

export function UserResetPassword(data) {
  return request.post('/user/reset/password', data)
}
