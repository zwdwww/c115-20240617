import request from '@/utils/request'

export function cardList(data) {
  return request.post('/schain/cardList', data)
}

export function suggest(data) {
  return request.post('/schain/suggest', data)
}

export function setSuggest(data) {
  return request.post('/schain/setSuggest', data)
}

export function diskSize(data) {
  return request.post('/schain/diskSize', data)
}

export function diskSizeChange(data) {
  return request.post('/schain/diskSizeChange', data)
}

export function diskSizeEarlyCreate(data) {
  return request.post('/schain/diskSizeEarlyCreate', data)
}

export function searchKeyList(data) {
  return request.post('/schain/searchKey/list', data)
}

export function searchKeyAdd(data) {
  return request.post('/schain/searchKey/add', data)
}

export function searchKeyBulk(data) {
  return request.post('/schain/searchKey/bulk', data)
}

export function searchKeyDel(data) {
  return request.post('/schain/searchKey/del', data)
}

export function cardUserList(data) {
  return request.post('/schain/user/list', data)
}

export function cardUserCreate(data) {
  return request.post('/schain/user/create', data)
}

export function cardUserSetPassword(data) {
  return request.post('/schain/user/set/password', data)
}

export function cardUserSetPhone(data) {
  return request.post('/schain/user/set/phone', data)
}

export function sysConfig() {
  return request.post('/schain/sys/config')
}

export function sysConfigSet(data) {
  return request.post('/schain/sys/config/set', data)
}

export function sysConfigDiskRemove(data) {
  return request.post('/schain/sys/disk/remove', data)
}

export function sysConfigDiskPreview(data) {
  return request.post('/schain/disk/preview', data)
}
