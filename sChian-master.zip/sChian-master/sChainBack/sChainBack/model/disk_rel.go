package model

import (
	"sChainBack/common"
)

// DiskRel 链盘文件的虚拟路径关系
type DiskRel struct {
	ID           int
	Uid          string
	Parent       string
	FileName     string
	FileMd5      string
	FileByteSize int64
	FileType     string
	Created      int64
	Base
}

func (d *DiskRel) Create(size *DiskSize) *DiskRel {
	if d.Err != nil {
		return d
	}

	d.Created = common.TimestampSec()
	db := common.SChainDb.Begin()
	if d.Err = db.Create(d).Error; d.Err != nil {
		db.Rollback()
		return d
	}
	size.UsedSize += d.FileByteSize
	d.Err = db.Model(DiskSize{}).Where(DiskSize{Uid: d.Uid}).Update("used_size", size.UsedSize).Error
	if d.Err != nil {
		db.Rollback()
		return d
	}
	db.Commit()
	return d
}
