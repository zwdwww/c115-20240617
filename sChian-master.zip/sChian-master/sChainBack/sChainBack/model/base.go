package model

import (
	"errors"
	"gorm.io/gorm"
	"sChainBack/common"
)

type Base struct {
	Err error `gorm:"-" json:"-"`
}

func (b *Base) FilterMysqlNilErr() bool {
	return b.Err != nil && !b.IsMysqlNil()
}

func (b *Base) IsMysqlNil() bool {
	return errors.Is(b.Err, gorm.ErrRecordNotFound)
}

// WithBegin MySQL事务
func WithBegin(f func(db *gorm.DB) error) error {
	tx := common.Db.Begin()
	err := f(tx)
	if err != nil {
		tx.Rollback()
	} else {
		tx.Commit()
	}
	return err
}
