package model

// CardEssay 名片短文
type CardEssay struct {
	ID      int
	Uid     string
	Essay   string
	Top     int //是否被置顶
	Updated int64
	Base
}
