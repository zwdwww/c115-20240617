package model

import "sChainBack/common"

// DiskSize 用户的链盘空间
type DiskSize struct {
	ID       int
	Uid      string
	DiskSize int64 // 链盘总空间
	UsedSize int64 // 已使用空间
	Updated  int64
	Base
}

func (d *DiskSize) Create() *DiskSize {
	if d.Err != nil {
		return d
	}
	d.Updated = common.TimestampSec()
	d.Err = common.SChainDb.Create(d).Error
	return d
}

// SurplusSize 剩余空间
func (d *DiskSize) SurplusSize() int64 {
	return d.DiskSize - d.UsedSize
}

func (d *DiskSize) List(page, limit int) (items []DiskSize, count int64) {
	if d.Err != nil {
		return []DiskSize{}, 0
	}

	d.Err = common.SChainDb.Model(d).Count(&count).Error
	if d.Err != nil {
		return
	}

	d.Err = common.SChainDb.Model(d).
		Order("id desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

func (d *DiskSize) GetByUid(uid string) *DiskSize {
	if d.Err != nil {
		return d
	}
	d.Err = common.SChainDb.Where(DiskSize{Uid: uid}).First(d).Error
	return d
}

func (d *DiskSize) ChangeDiskSize(num int64) *DiskSize {
	if d.Err != nil {
		return d
	}
	d.DiskSize += num
	d.Err = common.SChainDb.Model(DiskSize{}).
		Where(DiskSize{Uid: d.Uid}).
		Updates(map[string]interface{}{
			"disk_size": d.DiskSize,
			"updated":   common.TimestampSec(),
		}).Error
	return d
}
