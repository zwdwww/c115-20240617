package model

import (
	"fmt"
	"sChainBack/common"
	"strings"
)

// DiskFile 链盘文件信息(物理地址存储)
type DiskFile struct {
	ID           int
	FileMd5      string
	FileByteSize int64
	FileContent  []byte `json:"-"`
	FileType     string // 文件类型
	Count        int    // 引用数量
	IsPreview    int    // 是否可以预览
	Created      int64
	Base
}

func (d *DiskFile) GetFileType(filename string) string {
	arr := strings.Split(filename, ".")
	if len(arr) == 1 {
		return "?"
	}
	return arr[len(arr)-1]
}

func (d *DiskFile) Get(md5 string) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Err = common.SChainDb.Where(DiskFile{FileMd5: md5}).First(d).Error
	return d
}

// AddCount 添加引用数量
func (d *DiskFile) AddCount(add int) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Count += add
	d.Err = common.SChainDb.Model(DiskFile{}).Where(DiskFile{FileMd5: d.FileMd5}).Update("count", d.Count).Error
	return d
}

// Create 创建
func (d *DiskFile) Create(content []byte) *DiskFile {
	if d.Err != nil {
		return d
	}
	d.FileContent = content
	d.Err = common.SChainDb.Create(d).Error
	if d.Err == nil {
		d.Err = KKFileViewApi.Upload(fmt.Sprintf("%v.%v", d.FileMd5, d.FileType), d.FileContent)
	}
	return d
}

// Remove 删除
func (d *DiskFile) Remove() *DiskFile {
	if d.Err != nil {
		return d
	}
	d.Err = common.SChainDb.Model(d).Delete(d, "id = ?", d.ID).Error
	if d.Err == nil {
		d.Err = KKFileViewApi.Remove(fmt.Sprintf("%v.%v", d.FileMd5, d.FileType))
	}
	return d
}
