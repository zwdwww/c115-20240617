package model

import (
	"sChainBack/common"
)

// Card 完整的名片数据(需要保持数据的同步)
type Card struct {
	ID       int
	Uid      string
	Title    string // 标题
	Contact  string // 联系方式
	Address  string // 地址
	Keywords string // 搜词(需要与CardKey同步更新)
	Essay    string // 短文(需要与CardEssay同步更新)
	Star     int    // 被关注的次数(需要与CardStar的数据同步)
	Weight   int    // 推荐权重 default=0
	Created  int64
	Updated  int64
	Base
}

func (c *Card) Create() *Card {
	if c.Err != nil {
		return c
	}
	c.Updated = common.TimestampSec()
	c.Err = common.SChainDb.Create(c).Error
	return c
}

func (c *Card) Get() *Card {
	if c.Err != nil {
		return c
	}
	c.Err = common.SChainDb.Where(Card{Uid: c.Uid}).First(c).Error
	return c
}

func (c *Card) In(id []int) (items []Card) {
	if c.Err != nil || len(id) == 0 {
		return []Card{}
	}
	c.Err = common.SChainDb.Model(Card{}).Where("`id` in ?", id).Find(&items).Error
	return
}

func (c *Card) List(page, limit int) (items []Card, count int64) {
	if c.Err != nil {
		return []Card{}, 0
	}

	c.Err = common.SChainDb.Model(Card{}).Where("weight = 0").Count(&count).Error
	if c.Err != nil {
		return []Card{}, 0
	}

	c.Err = common.SChainDb.Model(Card{}).
		Where("weight = 0").
		Order("star desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

func (c *Card) Suggest() (items []Card) {
	if c.Err != nil {
		return
	}
	c.Err = common.SChainDb.Model(Card{}).Where("weight > 0").Order("weight desc").Find(&items).Error
	return
}

func (c *Card) SetSuggest(orderId []int, orderUid []string) *Card {
	if c.Err != nil {
		return c
	}
	length := len(orderId) + len(orderUid)

	tx := common.SChainDb.Begin()
	c.Err = tx.Model(c).Where("weight > 0").Update("weight", 0).Error
	if c.Err != nil {
		tx.Rollback()
		return c
	}

	for _, id := range orderId {
		c.Err = tx.Model(c).Where("id = ?", id).Update("weight", length).Error
		if c.Err != nil {
			tx.Rollback()
			return c
		}
		length--
	}

	for _, uid := range orderUid {
		c.Err = tx.Model(c).Where("`uid` = ?", uid).Update("weight", length).Error
		if c.Err != nil {
			tx.Rollback()
			return c
		}
		length--
	}
	c.Err = tx.Commit().Error
	return c
}
