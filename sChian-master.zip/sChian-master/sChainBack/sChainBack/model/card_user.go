package model

import (
	"golang.org/x/crypto/bcrypt"
	"sChainBack/common"
	"strings"
)

type CardUser struct {
	ID       int
	Username string
	Password string
	Phone    string
	Ip       string
	Province string // 省份
	Question string // 密码修改问题
	Created  int64
	Updated  int64
	Base
}

func (c *CardUser) Get() *CardUser {
	if c.Err != nil {
		return c
	}
	c.Err = common.SChainDb.Table("user").Where("username=?", c.Username).First(c).Error
	return c
}

func (c *CardUser) List(page, limit int) (items []CardUser, count int64) {
	if c.Err != nil {
		return []CardUser{}, 0
	}

	c.Err = common.SChainDb.Table("user").Where(c).Count(&count).Error
	if c.Err != nil {
		return []CardUser{}, 0
	}

	c.Err = common.SChainDb.Table("user").
		Where(c).
		Order("created desc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

// SetPassword 设置密码
func (c *CardUser) SetPassword(password string) *CardUser {
	if c.Err != nil {
		return c
	}
	value, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	c.Err = err
	c.Password = string(value)
	return c
}

// UpdatePassword 更新密码
func (c *CardUser) UpdatePassword(newPassword string) *CardUser {
	if c.Err != nil {
		return c
	}

	c.SetPassword(newPassword)
	if c.Err != nil {
		return c
	}

	c.Err = common.SChainDb.Table("user").
		Where(CardUser{Username: c.Username}).
		Update("password", c.Password).Error
	return c
}

// UpdatePhone 更新手机号
func (c *CardUser) UpdatePhone(newPhone string) *CardUser {
	if c.Err != nil {
		return c
	}
	c.Phone = newPhone
	c.Err = common.SChainDb.Table("user").
		Where(CardUser{Username: c.Username}).
		Update("phone", c.Phone).Error
	return c
}

func (c *CardUser) Create() *CardUser {
	if c.Err != nil {
		return c
	}
	c.Err = common.SChainDb.Table("user").Create(c).Error
	if c.Err != nil {
		return c
	}
	c.Err = c.InitCard(c.Username)
	return c
}

// InitCard 初始化名片数据
func (c *CardUser) InitCard(username string) error {
	config := &SysConfig{}
	m := config.Get()

	db := common.SChainDb.Begin()

	essay := &CardEssay{
		Uid:     username,
		Essay:   m.CardEssay,
		Top:     1,
		Updated: common.TimestampSec(),
	}

	card := &Card{
		Uid:      username,
		Title:    m.CardName,
		Essay:    essay.Essay,
		Keywords: m.CardKey,
		Address:  m.CardAddress,
		Created:  essay.Updated,
		Updated:  essay.Updated,
	}

	// 关键词
	if card.Keywords != "" {
		arr := strings.Split(card.Keywords, "$$")
		keys := make([]CardKey, 0, len(arr))
		for _, word := range arr {
			keys = append(keys, CardKey{Uid: username, Key: word})
		}
		if err := db.Create(&keys).Error; err != nil {
			db.Rollback()
			return err
		}
	}

	// 收藏夹
	for _, item := range m.DefaultFav {
		if item.Key == "" {
			continue
		}
		fav1 := &Favorites{
			Uid:     username,
			Key:     item.Key,
			Value:   item.Value,
			Created: common.TimestampSec(),
		}
		if err := db.Create(fav1).Error; err != nil {
			db.Rollback()
			return err
		}
	}

	// 网盘默认内容
	for _, item := range m.DefaultDisk {
		disk := &DiskFile{}
		disk.Get(item.DiskId)
		if disk.Err == nil {
			rel := &DiskRel{
				Uid:          username,
				Parent:       "/public",
				FileName:     item.DiskName,
				FileMd5:      disk.FileMd5,
				FileByteSize: disk.FileByteSize,
				FileType:     disk.FileType,
				Created:      common.TimestampSec(),
			}
			size := &DiskSize{
				Uid:      username,
				DiskSize: 40 * 1024 * 1024,
				UsedSize: disk.FileByteSize,
				Updated:  rel.Created,
			}
			size.Create()
			rel.Create(size)
			disk.AddCount(1)
		}
	}

	if err := db.Create(essay).Error; err != nil {
		db.Rollback()
		return err
	}
	if err := db.Create(card).Error; err != nil {
		db.Rollback()
		return err
	}
	return db.Commit().Error
}
