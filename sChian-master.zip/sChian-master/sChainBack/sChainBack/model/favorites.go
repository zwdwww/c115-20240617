package model

type Favorites struct {
	ID      int
	Uid     string
	Key     string
	Value   string
	Created int64
	Base
}
