package model

// CardKey 名片关键词
type CardKey struct {
	ID  int
	Uid string
	Key string
	Base
}
