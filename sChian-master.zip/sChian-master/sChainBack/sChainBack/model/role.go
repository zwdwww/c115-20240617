package model

import "sChainBack/common"

type Role struct {
	ID          int    `json:"id"`
	RoleName    string `json:"role_name"`
	RoleRouters string `json:"role_routers"`
	Base
}

func (r *Role) Get() *Role {
	if r.Err != nil {
		return r
	}
	r.Err = common.Db.First(r, "role_name = ?", r.RoleName).Error
	return r
}

func (r *Role) All() (items []Role) {
	if r.Err != nil {
		return []Role{}
	}
	r.Err = common.Db.Model(r).Find(&items).Error
	return
}

func (r *Role) Create() *Role {
	if r.Err != nil {
		return r
	}
	r.Err = common.Db.Create(r).Error
	return r
}

func (r *Role) GetById(id int) *Role {
	if r.Err != nil {
		return r
	}
	r.Err = common.Db.First(r, "id = ?", id).Error
	return r
}

func (r *Role) UpdateDataById(id int) *Role {
	if r.Err != nil {
		return r
	}
	r.Err = common.Db.Model(r).Where("id=?", id).Updates(r).Error
	return r
}
