package model

import (
	"golang.org/x/crypto/bcrypt"
	"sChainBack/common"
)

type User struct {
	ID       int    `json:"id"`
	Username string `json:"username"`
	Password string `json:"password"`
	RoleId   int    `json:"role_id"`
	Created  int64  `json:"created"`
	Updated  int64  `json:"updated"`
	Base
}

// Role 角色
func (u *User) Role() *Role {
	return &Role{}
}

func (u *User) Get() *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Where("username=?", u.Username).First(u).Error
	return u
}

func (u *User) GetById(id int) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.First(u, "id = ?", id).Error
	return u
}

func (u *User) GetByRoleId(roleId int) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(u).Where("role_id=?", roleId).First(u).Error
	return u
}

func (u *User) Create() *User {
	if u.Err != nil {
		return u
	}
	u.Created = common.TimestampSec()
	u.Updated = common.TimestampSec()
	u.Err = common.Db.Create(u).Error
	return u
}

func (u *User) Delete(id int) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(User{}).Where("id = ?", id).Delete(u).Error
	return u
}

func (u *User) List(page, limit int) (items []User) {
	if u.Err != nil {
		return []User{}
	}
	u.Err = common.Db.Model(u).
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

// Verify 密码验证
func (u *User) Verify(password string) *User {
	if u.Err != nil {
		return u
	}
	u.Err = bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))
	return u
}

// SetPassword 设置密码
func (u *User) SetPassword(password string) *User {
	if u.Err != nil {
		return u
	}
	value, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	u.Err = err
	u.Password = string(value)
	return u
}

// UpdatePassword 修改密码
func (u *User) UpdatePassword(newPassword string) *User {
	if u.Err != nil {
		return u
	}
	u.SetPassword(newPassword)
	u.Err = common.Db.Model(u).Where(User{Username: u.Username}).Update("password", u.Password).Error
	return u
}

func (u *User) UpdateDataById(id int) *User {
	if u.Err != nil {
		return u
	}
	u.Err = common.Db.Model(u).Where("id=?", id).Updates(u).Error
	return u
}
