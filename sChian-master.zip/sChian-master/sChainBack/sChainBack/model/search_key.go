package model

import "sChainBack/common"

// SearchKey 搜词
type SearchKey struct {
	ID      int
	Word    string
	Group   string
	Created int64
	Base
}

func (s *SearchKey) Create() *SearchKey {
	if s.Err != nil {
		return s
	}
	s.Created = common.TimestampSec()
	s.Err = common.SChainDb.Create(s).Error
	return s
}

func (s *SearchKey) List(page, limit int) (items []SearchKey, count int64) {
	if s.Err != nil {
		return []SearchKey{}, 0
	}

	s.Err = common.SChainDb.Model(s).Count(&count).Error
	if s.Err != nil {
		return []SearchKey{}, 0
	}

	s.Err = common.SChainDb.Model(s).
		Order("`group` asc").
		Offset((page - 1) * limit).
		Limit(limit).
		Find(&items).Error
	return
}

func (s *SearchKey) Delete(id int) *SearchKey {
	if s.Err != nil {
		return s
	}
	s.Err = common.SChainDb.Model(s).Delete(s, "id = ?", id).Error
	return s
}
