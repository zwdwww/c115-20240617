package handle

type Handle struct {
	method      func(ctx *Ctx) (interface{}, error)
	notAuth     bool // 不需要登录权限
	notReadBody bool // handle层不要读取Body内容
}

var HTTPMap = map[string]*Handle{
	"/api/user/login":          {method: userHandle.Login, notAuth: true},
	"/api/user/logout":         {method: userHandle.Logout},
	"/api/user/info":           {method: userHandle.Info},
	"/api/user/add":            {method: userHandle.Add},
	"/api/user/delete":         {method: userHandle.Delete},
	"/api/user/list":           {method: userHandle.List},
	"/api/user/update":         {method: userHandle.Update},
	"/api/user/reset/password": {method: userHandle.ResetPassword},

	"/api/role/list":   {method: roleHandle.List},
	"/api/role/add":    {method: roleHandle.Add},
	"/api/role/delete": {method: roleHandle.Delete},
	"/api/role/update": {method: roleHandle.Update},

	"/api/schain/cardList":            {method: schainHandle.CardList},
	"/api/schain/suggest":             {method: schainHandle.SuggestList},
	"/api/schain/setSuggest":          {method: schainHandle.SetSuggest},
	"/api/schain/diskSize":            {method: schainHandle.DiskSize},
	"/api/schain/disk/preview":        {method: schainHandle.DiskPreview},
	"/api/schain/diskSizeChange":      {method: schainHandle.DiskSizeChange},
	"/api/schain/diskSizeEarlyCreate": {method: schainHandle.DiskSizeEarlyCreate},
	"/api/schain/searchKey/bulk":      {method: schainHandle.SearchKeyBulk},
	"/api/schain/searchKey/list":      {method: schainHandle.SearchKeyList},
	"/api/schain/searchKey/add":       {method: schainHandle.SearchKeyCreate},
	"/api/schain/searchKey/del":       {method: schainHandle.SearchKeyDel},
	"/api/schain/user/list":           {method: schainHandle.UserList},
	"/api/schain/user/create":         {method: schainHandle.UserCreate},
	"/api/schain/user/set/password":   {method: schainHandle.SetPassword},
	"/api/schain/user/set/phone":      {method: schainHandle.SetPhone},
	"/api/schain/sys/config":          {method: schainHandle.SysConfig},
	"/api/schain/sys/config/set":      {method: schainHandle.SysConfigSet},
	"/api/schain/sys/disk/remove":     {method: schainHandle.SysDiskRemove},
	"/api/schain/sys/upload":          {method: schainHandle.SysUpload, notAuth: true, notReadBody: true},
}
