package args

// 请求参数结构

// Page Page-Limit
type Page struct {
	Page  int `json:"page"`
	Limit int `json:"limit"`
}

func (p Page) GetPage() int {
	if p.Page <= 0 {
		return 1
	}
	return p.Page
}

func (p Page) GetLimit() int {
	if p.Limit <= 0 {
		return 10
	}
	if p.Limit > 100 {
		return 100
	}
	return p.Limit
}
