package handle

import (
	"fmt"
	"sChainBack/common"
	"sChainBack/handle/args"
	"sChainBack/model"
	"sChainBack/modules/jwt"
)

var userHandle User

type User struct{}

func (u User) Login(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}

	user := &model.User{Username: req.Username}
	user.Get().Verify(req.Password)
	if user.Err != nil {
		return errSystem, fmt.Errorf("验证失败")
	}
	token, _ := jwt.GenerateToken(user)
	return H{"token": token}, nil
}

func (u User) Logout(_ *Ctx) (interface{}, error) {
	return H{}, nil
}

func (u User) Info(ctx *Ctx) (interface{}, error) {
	user := ctx.User().Get()
	role := ctx.User().Role().GetById(user.RoleId)
	if role.Err != nil {
		return errSystem, fmt.Errorf("角色不存在")
	}
	return H{
		"roles":        []string{role.RoleName},
		"name":         user.Username,
		"routers":      role.RoleRouters,
		"avatar":       "https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif",
		"introduction": "",
	}, nil
}

func (u User) Add(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
		RoleId   string `json:"role_id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	if len(req.Username) < 3 {
		return errSystem, fmt.Errorf("无法使用该用户名")
	}
	if len(req.Password) < 6 {
		return errSystem, fmt.Errorf("密码长度不能小于6位")
	}
	user := &model.User{Username: req.Username}
	if !user.Get().IsMysqlNil() {
		return errSystem, fmt.Errorf("该用户名已存在")
	}

	newUser := &model.User{Username: req.Username, RoleId: common.DefaultInt(req.RoleId)}
	newUser.SetPassword(req.Password)
	newUser.Create()
	return nil, nil
}

func (u User) Delete(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	usr := &model.User{}
	usr.GetById(req.Id)
	if usr.Username == ctx.Username {
		return errSystem, fmt.Errorf("不允许删除当前已登录用户")
	}
	if usr.Username == "admin" {
		return errSystem, fmt.Errorf("不允许删除[admin]管理员")
	}
	usr.Delete(req.Id)
	return nil, nil
}

func (u User) List(ctx *Ctx) (interface{}, error) {
	var req args.Page
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	items := ctx.User().List(req.GetPage(), req.GetLimit())
	return items, nil
}

func (u User) Update(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id       int    `json:"id"`
		Username string `json:"username"`
		RoleId   string `json:"role_id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	if req.Id == 1 {
		return errSystem, fmt.Errorf("无法修改[admin]管理员的数据")
	}
	user := &model.User{Username: req.Username, RoleId: common.DefaultInt(req.RoleId)}
	if user.UpdateDataById(req.Id).Err != nil {
		return errSystem, user.Err
	}
	return nil, nil
}

func (u User) ResetPassword(ctx *Ctx) (interface{}, error) {
	var req struct {
		NewPassword string `json:"new_password"`
		Id          int    `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	if len(req.NewPassword) < 6 {
		return errSystem, fmt.Errorf("密码长度不能小于6位")
	}
	usr := &model.User{}
	usr.GetById(req.Id).UpdatePassword(req.NewPassword)
	return nil, nil
}
