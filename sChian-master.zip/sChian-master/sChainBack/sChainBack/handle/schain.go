package handle

import (
	"fmt"
	"io"
	"sChainBack/common"
	"sChainBack/handle/args"
	"sChainBack/model"
	"strings"
)

var schainHandle SChain

type SChain struct{}

// CardList 全部名片
func (s SChain) CardList(ctx *Ctx) (interface{}, error) {
	var req args.Page
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	card := &model.Card{}
	items, count := card.List(req.GetPage(), req.GetLimit())
	return H{"items": items, "count": count}, nil
}

// SuggestList 推荐名片列表
func (s SChain) SuggestList(_ *Ctx) (interface{}, error) {
	card := &model.Card{}
	return H{"items": card.Suggest()}, nil
}

// SetSuggest 设置推荐名片
func (s SChain) SetSuggest(ctx *Ctx) (interface{}, error) {
	var req struct {
		Order []int    `json:"order"`
		Uid   []string `json:"uid"`
	}

	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}

	card := &model.Card{}
	if card.SetSuggest(req.Order, req.Uid).Err != nil {
		return errSystem, card.Err
	}
	return nil, nil
}

// DiskSize 链盘空间
func (s SChain) DiskSize(ctx *Ctx) (interface{}, error) {
	var req args.Page
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	size := &model.DiskSize{}
	items, count := size.List(req.GetPage(), req.GetLimit())
	return H{"items": items, "count": count}, nil
}

// DiskPreview 文件预览
func (s SChain) DiskPreview(ctx *Ctx) (interface{}, error) {
	var req struct {
		DiskId string `json:"diskId"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}

	df := &model.DiskFile{}
	if df.Get(req.DiskId).Err != nil {
		return errSystem, df.Err
	}

	previewUrl := model.KKFileViewApi.GetShowURL(fmt.Sprintf("%v.%v", df.FileMd5, df.FileType))
	if df.FileType == "docx" || df.FileType == "doc" || df.FileType == "pdf" {
		previewUrl = fmt.Sprintf("%v&officePreviewType=pdf", previewUrl)
	}
	return previewUrl, nil
}

// DiskSizeChange 链盘空间
func (s SChain) DiskSizeChange(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid  string `json:"uid"`
		Size int64  `json:"size"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数错误")
	}

	size := &model.DiskSize{}
	if size.GetByUid(req.Uid).ChangeDiskSize(req.Size).Err != nil {
		return errSystem, fmt.Errorf("修改失败")
	}
	return nil, nil
}

// DiskSizeEarlyCreate 提前分配链盘空间
func (s SChain) DiskSizeEarlyCreate(ctx *Ctx) (interface{}, error) {
	var req struct {
		Uid string `json:"uid"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Uid == "" {
		return errSystem, fmt.Errorf("参数错误")
	}

	card := &model.Card{Uid: req.Uid}
	if card.Get().IsMysqlNil() {
		return errSystem, fmt.Errorf("ID不存在")
	}

	size := &model.DiskSize{
		Uid:      req.Uid,
		DiskSize: 10 * 1024 * 1024,
	}

	if !size.GetByUid(req.Uid).IsMysqlNil() {
		return errSystem, fmt.Errorf("空间已完成分配")
	}

	size.Err = nil
	size.Create()
	return nil, nil
}

// SearchKeyList 搜词列表
func (s SChain) SearchKeyList(ctx *Ctx) (interface{}, error) {
	var req args.Page
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	key := &model.SearchKey{}
	items, count := key.List(req.GetPage(), req.GetLimit())
	return H{"items": items, "count": count}, nil
}

// SearchKeyBulk 搜词批量导入
func (s SChain) SearchKeyBulk(ctx *Ctx) (interface{}, error) {
	var req struct {
		Items []struct {
			Word  string `json:"word"`
			Group string `json:"group"`
		} `json:"items"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}

	var items []*model.SearchKey
	for _, item := range req.Items {
		md := &model.SearchKey{Word: item.Word, Group: strings.ToUpper(item.Group)}
		md.Created = common.TimestampSec()
		items = append(items, md)
	}
	if err := common.SChainDb.Create(items).Error; err != nil {
		return errSystem, err
	}
	return nil, nil
}

// SearchKeyCreate 新增搜词
func (s SChain) SearchKeyCreate(ctx *Ctx) (interface{}, error) {
	var req struct {
		Word  string `json:"word"`
		Group string `json:"group"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Word == "" {
		return errSystem, fmt.Errorf("参数错误")
	}
	key := &model.SearchKey{Word: req.Word, Group: strings.ToUpper(req.Group)}
	key.Create()
	return nil, nil
}

// SearchKeyDel 删除搜词
func (s SChain) SearchKeyDel(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Id == 0 {
		return errSystem, fmt.Errorf("参数错误")
	}
	key := &model.SearchKey{}
	key.Delete(req.Id)
	return nil, nil
}

// UserList 用户列表
func (s SChain) UserList(ctx *Ctx) (interface{}, error) {
	var req struct {
		Page     int
		Limit    int
		Phone    string
		Username string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}
	user := &model.CardUser{Phone: req.Phone, Username: req.Username}
	items, count := user.List(req.Page, req.Limit)
	if user.Err != nil {
		return errSystem, user.Err
	}
	return H{"items": items, "count": count}, nil
}

// UserCreate 用户创建
func (s SChain) UserCreate(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string
		Password string
		Phone    string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || req.Username == "" {
		return errSystem, fmt.Errorf("参数错误")
	}
	unique := &model.CardUser{Username: req.Username}
	if !unique.Get().IsMysqlNil() {
		return errSystem, fmt.Errorf("ID已存在")
	}
	usr := &model.CardUser{
		Username: req.Username,
		Phone:    req.Phone,
		Created:  common.TimestampSec(),
		Updated:  common.TimestampSec(),
	}
	usr.SetPassword(req.Password)
	if usr.Create().Err != nil {
		return errSystem, usr.Err
	}
	return nil, nil
}

// SetPassword 重置用户密码
func (s SChain) SetPassword(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string
		Password string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || len(req.Password) < 6 {
		return errSystem, fmt.Errorf("参数错误")
	}
	user := &model.CardUser{Username: req.Username}
	if user.Get().UpdatePassword(req.Password).Err != nil {
		return errSystem, user.Err
	}
	return nil, nil
}

// SetPhone 重置用户手机号
func (s SChain) SetPhone(ctx *Ctx) (interface{}, error) {
	var req struct {
		Username string
		Phone    string
	}
	if err := ctx.JSONUnmarshal(&req); err != nil || len(req.Phone) != 11 {
		return errSystem, fmt.Errorf("请确认手机号是否正确")
	}

	user := &model.CardUser{Username: req.Username}
	if user.Get().UpdatePhone(req.Phone).Err != nil {
		return errSystem, user.Err
	}
	return nil, nil
}

// SysConfig 获取系统配置
func (s SChain) SysConfig(_ *Ctx) (interface{}, error) {
	config := &model.SysConfig{}
	data := config.Get()
	if config.Err != nil {
		return errSystem, config.Err
	}
	return data, nil
}

// SysConfigSet 更新系统配置
func (s SChain) SysConfigSet(ctx *Ctx) (interface{}, error) {
	var req struct {
		Data model.SysConfigData `json:"data"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return nil, err
	}
	config := &model.SysConfig{}
	config.Update(&req.Data)
	if config.Err != nil {
		return errSystem, config.Err
	}
	return nil, nil
}

// SysDiskRemove 链盘文件删除
func (s SChain) SysDiskRemove(ctx *Ctx) (interface{}, error) {
	var req struct {
		Index int `json:"index"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}

	config := &model.SysConfig{}
	m := config.Get()

	newArr := make([]model.SysConfigDiskItem, 0, len(m.DefaultDisk))
	for i := range m.DefaultDisk {
		if i == req.Index {
			tmp := &model.DiskFile{}
			// 没有被任何人引用,则删除这个文件
			if tmp.Get(m.DefaultDisk[i].DiskId).Err == nil && tmp.Count == 0 {
				if tmp.Remove().Err != nil {
					return errSystem, tmp.Err
				}
			}
			continue
		}
		newArr = append(newArr, m.DefaultDisk[i])
	}
	m.DefaultDisk = newArr
	if config.Update(m).Err != nil {
		return errSystem, config.Err
	}
	return nil, nil
}

type sysUploadFileItem struct {
	File     []byte
	FileName string
	Size     int64
}

var sysUploadFileQueue = make(chan sysUploadFileItem, 8)

// RunEventSysUpload 文件上传事件处理(多个文件同时上传会出现并发修改异常问题, 改用队列处理)
func RunEventSysUpload() {
	for {
		item := <-sysUploadFileQueue
		md5 := common.Md5(item.File)
		config := &model.SysConfig{}
		data := config.Get()

		// 检查上传的文件是否已存在
		diskFile := &model.DiskFile{}
		diskFile.Get(md5)
		if diskFile.Err == nil {
			data.DefaultDisk = append(data.DefaultDisk, model.SysConfigDiskItem{
				DiskId:   diskFile.FileMd5,
				DiskName: item.FileName,
			})
			config.Update(data)
			if config.Err != nil {
				common.Loggers.Errorf("file upload err: %v", config.Err)
			}
			continue
		}

		if !diskFile.IsMysqlNil() {
			common.Loggers.Errorf("file upload err: %v", diskFile.Err)
			continue
		}

		// 新增
		newFile := &model.DiskFile{
			FileMd5:      md5,
			FileByteSize: item.Size,
			FileType:     diskFile.GetFileType(item.FileName),
			Count:        0,
			IsPreview:    1,
			Created:      common.TimestampSec(),
		}
		if newFile.Create(item.File).Err != nil {
			common.Loggers.Errorf("file upload err: %v", config.Err)
			continue
		}
		data.DefaultDisk = append(data.DefaultDisk, model.SysConfigDiskItem{
			DiskId:   md5,
			DiskName: item.FileName,
		})
		if config.Update(data).Err != nil {
			common.Loggers.Errorf("file upload err: %v", config.Err)
			continue
		}
	}
}

// SysUpload 系统配置文件上传
func (s SChain) SysUpload(ctx *Ctx) (interface{}, error) {
	err := ctx.Request.ParseMultipartForm(32 << 20)
	if err != nil {
		return errSystem, fmt.Errorf("上传失败")
	}

	file, handler, err := ctx.Request.FormFile("File")
	if err != nil {
		return errSystem, fmt.Errorf("上传失败")
	}

	if handler.Size == 0 {
		return errSystem, fmt.Errorf("上传文件异常")
	}

	defer func() {
		_ = file.Close()
	}()

	bytes, err := io.ReadAll(file)
	if err != nil {
		return errSystem, err
	}

	sysUploadFileQueue <- sysUploadFileItem{
		File:     bytes,
		FileName: handler.Filename,
		Size:     handler.Size,
	}
	return nil, nil
}
