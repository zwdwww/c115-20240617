package handle

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"sChainBack/model"
	"strings"
)

type Msg struct {
	Code int         `json:"code"`
	Msg  string      `json:"msg"`
	Data interface{} `json:"data"`
}

// Ctx Ctx
type Ctx struct {
	body     []byte
	bodyStr  string
	Request  *http.Request
	Response http.ResponseWriter

	Username string
}

func (c *Ctx) Body() []byte {
	return c.body
}

func (c *Ctx) User() *model.User {
	return &model.User{Username: c.Username}
}

// BodyStr BodyStr
func (c *Ctx) BodyStr() string {
	if c.bodyStr == "" {
		c.bodyStr = string(c.Body())
	}
	return c.bodyStr
}

// IP 获取真实的IP地址
func (c *Ctx) IP() string {
	clientIP := c.Request.Header.Get("X-Forwarded-For")
	if index := strings.IndexByte(clientIP, ','); index >= 0 {
		clientIP = clientIP[0:index]
		//获取最开始的一个 即 1.1.1.1
	}
	clientIP = strings.TrimSpace(clientIP)
	if len(clientIP) > 0 {
		return clientIP
	}
	clientIP = strings.TrimSpace(c.Request.Header.Get("X-Real-Ip"))
	if len(clientIP) > 0 {
		return clientIP
	}

	ip, _, err := net.SplitHostPort(c.Request.RemoteAddr)
	if err != nil {
		return ""
	}

	if net.ParseIP(ip) != nil {
		return ip
	}

	return ""
}

// JSONUnmarshal Json解析
func (c *Ctx) JSONUnmarshal(v interface{}) error {
	err := json.Unmarshal(c.body, v)
	return err
}

// ReadJSON 读取Body为Json
func (c *Ctx) ReadJSON(_ http.ResponseWriter, req *http.Request) bool {
	data, err := ioutil.ReadAll(req.Body)
	if err != nil {
		return false
	}
	defer func() {
		_ = req.Body.Close()
	}()
	c.body = data
	return true
}

// WriteJSON 写入Json
func (c *Ctx) WriteJSON(rw http.ResponseWriter, code int, data interface{}) error {
	r := Msg{Code: code, Msg: fmt.Sprintf("code=%v", code), Data: data}
	b, err := json.Marshal(r)
	if err != nil {
		return err
	}
	_, err = rw.Write(b)
	return err
}

// ClearBody 清空Body
func (c *Ctx) ClearBody() {
	c.body = nil
}
