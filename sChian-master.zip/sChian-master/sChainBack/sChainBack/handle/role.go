package handle

import (
	"fmt"
	"sChainBack/common"
	"sChainBack/model"
)

var roleHandle Role

type Role struct{}

func (r Role) List(ctx *Ctx) (interface{}, error) {
	var req struct {
		Types string `json:"types"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, fmt.Errorf("参数错误")
	}

	role := &model.Role{}
	list := role.All()
	if req.Types == "map" {
		h := map[int]string{}
		for _, v := range list {
			h[v.ID] = v.RoleName
		}
		return H{"data": h}, nil
	}
	return list, nil
}

func (r Role) Add(ctx *Ctx) (interface{}, error) {
	var req struct {
		RoleName    string `json:"role_name"`
		RoleRouters string `json:"role_routers"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	role := &model.Role{RoleName: req.RoleName, RoleRouters: req.RoleRouters}
	if role.Get().Err == nil {
		return errSystem, fmt.Errorf("角色已存在")
	} else {
		role.Err = nil
	}
	if role.Create().Err != nil {
		return errSystem, role.Err
	}
	return nil, nil
}

func (r Role) Delete(ctx *Ctx) (interface{}, error) {
	var req struct {
		Id int `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	user := &model.User{}
	if user.GetByRoleId(req.Id).Err == nil {
		return errSystem, user.Err
	}
	role := &model.Role{}
	role.Err = common.Db.Model(role).Where("id=?", req.Id).Delete(role).Error
	if role.Err != nil {
		return errSystem, role.Err
	}
	return nil, nil
}

func (r Role) Update(ctx *Ctx) (interface{}, error) {
	var req struct {
		RoleName    string `json:"role_name"`
		RoleRouters string `json:"role_routers"`
		Id          int    `json:"id"`
	}
	if err := ctx.JSONUnmarshal(&req); err != nil {
		return errSystem, err
	}
	role := &model.Role{RoleName: req.RoleName, RoleRouters: req.RoleRouters}
	if role.UpdateDataById(req.Id).Err != nil {
		return errSystem, role.Err
	}
	return nil, nil
}
