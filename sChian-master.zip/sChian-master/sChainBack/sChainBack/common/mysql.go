package common

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

func InitMysql() {
	var err error
	Db, err = gorm.Open(mysql.Open(Config.Mysql.Source), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			SingularTable: true,
		},
		DisableForeignKeyConstraintWhenMigrating: true,
	})
	if err != nil {
		panic(fmt.Sprintf("MySQL链接失败: err=%v", err))
	}
	sqlDB, _ := Db.DB()
	sqlDB.SetMaxOpenConns(Config.Mysql.MaxOpenConn)
	sqlDB.SetMaxIdleConns(Config.Mysql.MaxIdleConn)
}

func InitSChainMysql() {
	var err error
	SChainDb, err = gorm.Open(mysql.Open(Config.SChainMysql.Source), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			SingularTable: true,
		},
		DisableForeignKeyConstraintWhenMigrating: true,
	})
	if err != nil {
		panic(fmt.Sprintf("MySQL链接失败: err=%v", err))
	}
	sqlDB, _ := Db.DB()
	sqlDB.SetMaxOpenConns(Config.SChainMysql.MaxOpenConn)
	sqlDB.SetMaxIdleConns(Config.SChainMysql.MaxIdleConn)
}
