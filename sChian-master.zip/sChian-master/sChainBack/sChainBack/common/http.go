package common

import (
	"bytes"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"path/filepath"
	"time"
)

const httpTimeout = time.Second * 60

// UploadFile 上传文件
func UploadFile(uri, keyName, filename string, fileContent []byte) ([]byte, error) {
	var b bytes.Buffer
	w := multipart.NewWriter(&b)

	filePart, err := w.CreateFormFile(keyName, filepath.Base(filename))
	if err != nil {
		return nil, err
	}

	_, err = io.Copy(filePart, bytes.NewBuffer(fileContent))
	if err != nil {
		return nil, err
	}

	if err = w.Close(); err != nil {
		return nil, err
	}

	req, err := http.NewRequest("POST", uri, &b)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", w.FormDataContentType())

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	defer func() {
		_ = resp.Body.Close()
	}()

	return io.ReadAll(resp.Body)
}

func httpGet(url string) (resp *http.Response, err error) {
	client := http.Client{
		Timeout: httpTimeout,
	}
	return client.Get(url)
}

// GetURL 请求URL
func GetURL(URL string) ([]byte, error) {
	resp, err := httpGet(URL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	return ioutil.ReadAll(resp.Body)
}
