package main

import (
	"net/http"
	"sChainBack/common"
	"sChainBack/handle"
	"sChainBack/model"
)

// 创建默认的角色和用户
func initDefaultUsr() {
	role := &model.Role{RoleName: "admin"}
	if role.Get().IsMysqlNil() {
		role.Err = nil
		role.Create()
	}

	user := &model.User{Username: "admin"}
	if user.Get().IsMysqlNil() {
		user.Err = nil
		user.RoleId = role.ID
		user.SetPassword("123456")
		user.Created = common.TimestampSec()
		user.Updated = user.Created
		user.Create()
	}
}

func main() {
	common.InitConfig("config/config.yaml")
	if err := common.InitSnow(1); err != nil {
		panic(err)
	}
	initDefaultUsr()
	go handle.RunEventSysUpload()
	common.Loggers.Infof("ListenAndServe start,:%v", common.Config.Port)
	common.Loggers.Errorf("ListenAndServe,%v",
		http.ListenAndServe(":"+common.Config.Port, handle.Intercept{}),
	)
}
