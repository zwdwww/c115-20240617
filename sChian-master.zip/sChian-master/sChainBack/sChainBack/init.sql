# 用户表
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    `id` int NOT NULL AUTO_INCREMENT,
    `username` varchar(128) NOT NULL,
    `password` varchar(128) not null,
    `role_id`   int not null,
    `created`  int not null,
    `updated`  int not null,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`) using btree
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# 角色表
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
    `id` int NOT NULL AUTO_INCREMENT,
    `role_name` varchar(128) NOT NULL,
    `role_routers` text not null,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
